/**
 * Harmonic Nexus Core (HNC) Framework
 * -----------------------------------
 * Purpose:
 *   The coherence engine that fuses resonance data (Hz),
 *   affective mood (valence/arousal), and narratives (news/emotion tags).
 *
 * Famous.io Note:
 *   This is the main entrypoint for the HNC system. Other workers
 *   (resonanceWorker, emotionWorker, newsWorker, aurisSandbox)
 *   publish into the Nexus; HNC synthesises them.
 */

export type ResonanceSample = { t: number; band: string; power: number };
export type AffectSample = { t: number; v: number; a: number };
export type NarrativeItem = {
  t: number;
  station: string;
  region?: string;
  text: string;
  emotion: string;
  tags: string[];
};

export type HNCDriver = {
  label: string;      // e.g. "conflict/economy"
  weight: number;     // contribution weight (0..1)
  station?: string;   // source attribution
};

export type HNCEdge = {
  from: string;   // region/station
  to: string;     // region/station
  weight: number; // influence strength (0..1)
};

export type HNCRegionTick = {
  region: string;
  score: number;           // coherence score (0–100)
  byBand: Record<string, number>; // band coherence γ²(f)
  drivers: HNCDriver[];
  edges: HNCEdge[];
  updatedAt: number;
};

export interface HNCConfig {
  windowMinutes: number; // analysis window (e.g. 60)
  hopMinutes: number;    // recompute step (e.g. 5)
  bands: string[];       // which resonance bands to watch
}

/**
 * Core Engine Stub
 */
export class HarmonicNexusCore {
  private config: HNCConfig;
  private resonance: ResonanceSample[] = [];
  private affect: AffectSample[] = [];
  private narratives: NarrativeItem[] = [];

  constructor(config?: Partial<HNCConfig>) {
    this.config = {
      windowMinutes: config?.windowMinutes ?? 60,
      hopMinutes: config?.hopMinutes ?? 5,
      bands: config?.bands ?? ["7.83", "14.3", "20.8"],
    };
  }

  /** Ingest streams */
  addResonance(sample: ResonanceSample) {
    this.resonance.push(sample);
  }
  addAffect(sample: AffectSample) {
    this.affect.push(sample);
  }
  addNarrative(item: NarrativeItem) {
    this.narratives.push(item);
  }

  /** Core run (called periodically by worker) */
  run(region: string): HNCRegionTick {
    const now = Date.now();

    // Enhanced coherence calculation with Tonnetz integration
    const recentAffect = this.affect.slice(-10);
    const avgValence = recentAffect.reduce((sum, a) => sum + a.v, 0) / (recentAffect.length || 1);
    const avgArousal = recentAffect.reduce((sum, a) => sum + a.a, 0) / (recentAffect.length || 1);
    
    // Map emotional state to coherence score
    const emotionalCoherence = 50 + (avgValence * 25) + (avgArousal * 25);
    const score = Math.max(0, Math.min(100, Math.round(emotionalCoherence)));
    
    // Band coherence with emotional modulation
    const byBand = Object.fromEntries(
      this.config.bands.map((b, i) => {
        const baseCoherence = 0.3 + (avgArousal * 0.4);
        const harmonicShift = avgValence * 0.2 * (i + 1);
        return [b, Math.max(0, Math.min(1, baseCoherence + harmonicShift))];
      })
    );
    
    const drivers: HNCDriver[] = [
      { label: "economy", weight: 0.4 + avgValence * 0.2, station: "BBC" },
      { label: "conflict", weight: 0.3 + avgArousal * 0.2, station: "Reuters" },
      { label: "weather", weight: 0.2, station: "CNN" },
    ];
    
    const edges: HNCEdge[] = [
      { from: "BBC", to: region, weight: 0.6 + avgValence * 0.2 },
      { from: "Reuters", to: region, weight: 0.4 + avgArousal * 0.3 },
    ];

    return { region, score, byBand, drivers, edges, updatedAt: now };
  }
}