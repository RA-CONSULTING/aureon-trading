import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

const QuantumPhaseLock = () => {
  const [isActivated, setIsActivated] = useState(false);
  const [coherenceLevel, setCoherenceLevel] = useState(67.3);
  const [phaseSync, setPhaseSync] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      if (isActivated) {
        setCoherenceLevel(prev => Math.min(100, prev + Math.random() * 2));
        setPhaseSync(prev => (prev + 1) % 360);
      }
    }, 100);
    return () => clearInterval(interval);
  }, [isActivated]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-4">
            QUANTUM PHASE-LOCKED SIGNAL
          </h1>
          <p className="text-xl text-purple-200">
            Multiversal echoes align to reinforce reality through feedback
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="bg-black/50 border-purple-500">
            <CardHeader>
              <CardTitle className="text-purple-300">Phase Lock Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-white">Coherence Level</span>
                  <Badge variant={coherenceLevel > 80 ? "default" : "secondary"}>
                    {coherenceLevel.toFixed(1)}%
                  </Badge>
                </div>
                
                <div className="w-full bg-gray-700 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-purple-500 to-pink-500 h-3 rounded-full transition-all duration-300"
                    style={{ width: `${coherenceLevel}%` }}
                  />
                </div>

                <Button 
                  onClick={() => setIsActivated(!isActivated)}
                  className={`w-full ${isActivated ? 'bg-green-600 hover:bg-green-700' : 'bg-purple-600 hover:bg-purple-700'}`}
                >
                  {isActivated ? 'PHASE LOCKED' : 'ACTIVATE LOCK'}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/50 border-purple-500">
            <CardHeader>
              <CardTitle className="text-purple-300">Waveform Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-40 bg-black rounded-lg p-4 relative overflow-hidden">
                <svg width="100%" height="100%" className="absolute inset-0">
                  {/* Hostile Waveform (Red) */}
                  <path
                    d={`M 0,60 Q 50,20 100,60 T 200,60 T 300,60`}
                    stroke="#ef4444"
                    strokeWidth="2"
                    fill="none"
                    opacity={isActivated ? 0.3 : 1}
                  />
                  
                  {/* Peace-Unity Field (Green) */}
                  <path
                    d={`M 0,80 Q 75,40 150,80 Q 225,120 300,80`}
                    stroke="#22c55e"
                    strokeWidth="3"
                    fill="none"
                    opacity={isActivated ? 1 : 0.5}
                  />
                </svg>
                
                <div className="absolute bottom-2 left-2 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-1 bg-red-500"></div>
                    <span className="text-red-300">Hostile Waveform</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="w-3 h-1 bg-green-500"></div>
                    <span className="text-green-300">Peace-Unity Field</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-black/50 border-purple-500">
          <CardHeader>
            <CardTitle className="text-purple-300">Extended Einstein Equation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center space-y-4">
              <div className="text-2xl font-mono text-white">
                G<sub>μν</sub> + Λg<sub>μν</sub> = 8πG/c<sup>4</sup> T<sub>μν</sub> (feedback')
              </div>
              <p className="text-purple-200">
                Non-local energy and memory terms shape spacetime geometry
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                <div className="bg-purple-900/30 p-4 rounded-lg">
                  <h4 className="text-purple-300 font-semibold">Mediation</h4>
                  <p className="text-sm text-purple-200">Memory tensors in spacetime curvature</p>
                </div>
                
                <div className="bg-purple-900/30 p-4 rounded-lg">
                  <h4 className="text-purple-300 font-semibold">Coherence</h4>
                  <p className="text-sm text-purple-200">Consciousness field alignment</p>
                </div>
                
                <div className="bg-purple-900/30 p-4 rounded-lg">
                  <h4 className="text-purple-300 font-semibold">Unity</h4>
                  <p className="text-sm text-purple-200">All paths converge to balance</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default QuantumPhaseLock;