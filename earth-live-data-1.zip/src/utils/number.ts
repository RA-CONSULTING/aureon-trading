/**
 * Safe number formatter that never throws
 * Handles undefined, null, NaN, and string inputs gracefully
 */
export function fmt(x: unknown, digits = 2, empty = "—"): string {
  const n = typeof x === "string" ? Number(x) : (x as number);
  return Number.isFinite(n) ? n.toFixed(digits) : empty;
}

/**
 * Safe number coercion with default fallback
 */
export function num(v: any, def = 0): number {
  const n = typeof v === "string" ? Number(v) : v;
  return Number.isFinite(n) ? n : def;
}

/**
 * Safe percentage formatter
 */
export function pct(x: unknown, digits = 1): string {
  const n = typeof x === "string" ? Number(x) : (x as number);
  return Number.isFinite(n) ? `${(n * 100).toFixed(digits)}%` : "—";
}

/**
 * Safe frequency formatter with Hz suffix
 */
export function hz(x: unknown, digits = 2): string {
  const n = typeof x === "string" ? Number(x) : (x as number);
  return Number.isFinite(n) ? `${n.toFixed(digits)} Hz` : "— Hz";
}

/**
 * Legacy alias for fmt() - safe number formatter that never throws
 * @deprecated Use fmt() instead
 */
export const toFixedSafe = fmt;

/**
 * Format population numbers with appropriate suffixes
 */
export function formatPopulation(pop: number): string {
  if (pop >= 1000000000) return `${(pop / 1000000000).toFixed(1)}B`;
  if (pop >= 1000000) return `${(pop / 1000000).toFixed(1)}M`;
  if (pop >= 1000) return `${(pop / 1000).toFixed(0)}K`;
  return pop.toString();
}