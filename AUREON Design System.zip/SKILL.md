# SAMUEL / AUREON Design System — Skill

Design-system package for **SAMUEL** (Samuel Harmonic Trading Entity) inside **AUREON / Aureon Institute** — Gary Leckey, Belfast, Silver Level Innovation Framework. **Triple-register voice:** trader mono (`+2.31%`, `Need 0.180%`), counter-intelligence warfare (*Ghost Dance Protocol*, *Scout → Sniper → Harvester*, predator firms with animal glyphs), and consciousness-engine metaphysics (*Queen AI*, *HNC equation*, *Tree of Light*, *528 Hz Gate*). Dark-first, warm charcoal, amber-gold primary, prism-rainbow accents.

## When to use

Any artifact inside — or adjacent to — SAMUEL / AUREON: operator dashboards, marketing long-scrolls, investor decks, research write-ups, the Institute's academic materials. Triggers include *Terminal Mirror, Cinematic Observatory, Queen AI, Queen Voice, Ghost Dance, Sorynth, Mycelium, HNC, Auris, Tree of Light, Schumann, 528 Hz, Scout/Sniper/Harvester*, the four battlefronts (*Kraken, Binance, Alpaca, Capital*), or R&A Consulting / Aureon Institute.

## How to use

1. Read `README.md` — the **three voices** section is non-negotiable; mixing rules are explicit.
2. Link `colors_and_type.css` for tokens (HSL, Solfeggio, Totems, gradients, radii, type scale).
3. Operator surface → copy patterns from `ui_kits/terminal-mirror/`. Marketing surface → `ui_kits/marketing-landing/`.
4. Match data formatting exactly: signed percentages, tabular mono, ALL-CAPS venue labels, empty states prefixed `No…` or `Waiting for…`. Never replace trader data with mystical copy — metaphysics punctuates, it does not crowd out numbers.
5. Emoji sigils (venues, predator firms, systems, totems, alchemical) are canonical. Never substitute SVG.
6. The nine Archetypes / Auris Totems always render glyph + name together. Never one or the other alone.
7. Proof metrics are always `big serif number + mono-uppercase sub-label`. Units attached to numbers, never labels.
8. Dark is default. Light is accessibility fallback only.

## Artifacts

- `README.md` — triple-register voice, visual foundations, iconography, Solfeggio, Prism, Totems
- `SKILL.md` — this file
- `colors_and_type.css` — all tokens as CSS custom properties
- `preview/` — 25 preview cards (Colors, Type, Spacing, Components, Brand)
- `ui_kits/terminal-mirror/` — operator dashboard
- `ui_kits/marketing-landing/` — evangelical long-scroll
- `assets/` — hero imagery, research renders, favicon
