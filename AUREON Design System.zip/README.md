# SAMUEL / AUREON Design System

Design-system package for **SAMUEL** (Samuel Harmonic Trading Entity / SHTE) — the autonomous, multi-exchange algorithmic trading entity, and its umbrella platform **AUREON** / **Aureon Institute**, founded by Gary Leckey (R&A Consulting, Belfast). Silver Level Innovation Framework recognition (Dr Caoimhe Archibald MLA, Department for the Economy NI).

This is a **triple-register** brand: quantitative-trader mono on top of counter-intelligence warfare vocabulary on top of consciousness-engine metaphysics. The design system must hold all three without flinching — terse `+2.31%` rows, Sun-Tzu-inflected tactical copy, and proper-noun liturgy like *Queen AI*, *Harmonic Nexus Core*, *Ghost Dance Protocol*, *Tree of Light* — on the same screen.

## Sources

- **Marketing site:** `https://trading.aureoninstitute.co.uk` — brand, voice, proof metrics, manifesto copy
- **Managed dashboard:** `https://aureoninstitute.com` — £33/mo hosted product (behind auth)
- **Self-hosted repo:** `RA-CONSULTING/aureon-trading` — `frontend/` (Vite + React 18 + TS + Tailwind + shadcn/ui + Radix + @react-three/fiber), `aureon/` Python core
- **Tokens read from:** `frontend/src/index.css`, `frontend/tailwind.config.ts`
- **Creator:** Gary Leckey · ORCID 0009-0004-2792-4649 · CERN-archived Zenodo dossier · Belfast, Northern Ireland

## Surfaces & products

The brand lives across three distinct surfaces. The design system must serve all three.

1. **Marketing landing** (`trading.aureoninstitute.co.uk`) — evangelical, combative, copy-dense. Opens with *"What if trading wasn't about extraction..."* Leads with proof metrics, manifesto, pricing (£33/mo), government recognition. Long-form — visitors scroll.
2. **Terminal Mirror** (repo `frontend/src/App.tsx`) — the single-screen live monitor for `unified_market_trader.py`. Dense, mono-first, tabular. Exchange cards, live signals, shadow validation, Queen Voice narration. This is what operators watch.
3. **Cinematic Observatory** — `@react-three/fiber` immersive scene entered from the dashboard via a glass-morphism CTA. Prism-shift + rainbow-flow motion. The design system only ships the entry treatment — the scene itself is out of scope.

## Index — what lives where

```
README.md                     ← you are here
SKILL.md                      ← skill manifest
colors_and_type.css           ← all tokens + type scale as CSS vars
assets/                       ← hero imagery, research renders, favicon
preview/                      ← design-system preview cards (Design System tab)
ui_kits/
  terminal-mirror/            ← dashboard UI kit — operator surface
  marketing-landing/          ← marketing surface UI kit — evangelical long-scroll
```

---

## CONTENT FUNDAMENTALS

### The three voices — stacked, not blended

SAMUEL speaks in three registers, **layered** — a single surface can and should carry all three:

**1. Trader register** (mono, tabular, terse).
`Entry $0.4312 · Now $0.4398 · Need 0.180% · Hold 2m 14s`
All-caps venue labels: `KRAKEN · BINANCE · ALPACA · CAPITAL`. Signed percentages always carry their sign: `+2.31%`, `−0.14%`. Currency follows the venue — `$` Kraken/Binance/Alpaca, `£` Capital, `€` unified portfolio. Fallback sentinels: `--:--:--`, `n/a`. Sentence-cased empty states prefixed `No…` or `Waiting for…`: *"No open Kraken positions"*, *"Queen voice is waiting for live intelligence snapshots."*

**2. Counter-intelligence / warfare register** (the middle layer — this is what the marketing site DOMINATES with).
The trader is not a "trader." He is in a war. Vocabulary is drawn from insurgency, sniping, counter-surveillance, and classical military strategy.
- *"$13 trillion institutional capital hunts retail liquidity"*
- *"44,000 bots detected across 37 firms"*
- *"Scout → Sniper → Harvester"* — the tactical tier system for trade execution
- *"Ghost Dance Protocol"* · *"Apache stealth mode"* · *"IRA sniper patience"* · *"Sun Tzu meets market microstructure"*
- Firms are **prey**: 🦈 Jane Street, 🦁 Citadel, 🐺 Two Sigma, 🕷️ Virtu, 🦅 DE Shaw, 🦊 Jump Trading
- *"exit liquidity"*, *"institutional extraction"*, *"hunted"*, *"counter-intelligence"*, *"shadow book"*, *"battlefronts"* (exchanges are battlefronts)
- Short, declarative, militant sentences. *"They hunt. We harvest."* *"The bot army is real. We mapped it."*

**3. Consciousness-engine / metaphysical register** (the top layer — highest ceremony).
Proper-noun, quasi-liturgical. Reserved for system-level narration, feature names, section titles.
- *Queen AI* (12-neuron veto layer) · *Harmonic Nexus Core* (HNC) · *Prime Sentinel* · *Sorynth Protocol* · *Auris Conjecture*
- *Tree of Light* (8-level consciousness ladder) · *Nine Archetypes* / *Auris Totems* · *The Prism* (5 Platonic solids)
- *528 Hz Love* · *432 Hz Clarity* · *7.83 Hz Schumann Lock* · *Harmonic Resonance* · *Coherence*
- Module names: *Mycelium Network*, *Lighthouse Telemetry*, *Ocean Wave Scanner*, *Obsidian Filter*, *Shadow Validation*, *High Score Opportunities*
- The master equation is printed verbatim where ceremony demands it: **HNC(t) = S(t) + O(t) + E(t)** — Sentinel, Oracle, Environment

**Mixing rule:** trader register is always present on operator surfaces; warfare register dominates marketing; metaphysical register appears as **sparse, proper-noun punctuation** on every surface. Never let metaphysics crowd out the numbers. Never let warfare copy replace the trader's actual data.

### Casing & typography of copy

- **Titles:** Title Case — *Live Exchange Metrics · High Score Opportunities · Ghost Dance Protocol*
- **Eyebrows / panel labels:** ALL CAPS mono — `KRAKEN`, `QUEEN VOICE`, `SHADOW VALIDATION`, `BATTLEFRONT`, `TACTICAL TIER`
- **Body copy:** sentence case
- **Status tokens:** ALL CAPS short — `LIVE`, `OFF`, `VALID`, `LONG`, `SHORT`, `BUY`, `SELL`, `CONVERT`, `SCOUTING`, `STALKING`, `STRIKING`, `HARVESTING`
- **Frequencies** are always bare with unit: `528 Hz`, `432 Hz`, `7.83 Hz` (not `528hz`, not `528 Hz Love Frequency`)
- **The equation** `HNC(t) = S(t) + O(t) + E(t)` — always rendered in serif italic, with a thin prism-gradient underline
- **Creator attribution** — *"Gary Leckey · Belfast · ORCID 0009-0004-2792-4649"* — monospace, 10px, 60% opacity

### Person & posture

Third-person product voice on operator surfaces ("Queen voice advises patience"). First-person plural on marketing ("We mapped the bot army"). Never "you" on the dashboard; "you" is permitted in marketing CTAs only (*"Enter the Observatory"*, *"Join the Institute"*).

### Numbers & proof

Marketing leans hard on verifiable-sounding metrics. Always render them as a **proof pair**: big number + mono sub-label. The dashboard instance of this pattern is the top-mover tile; the marketing instance is the hero-proof grid.

- `44,000` / `BOTS DETECTED`
- `37` / `FIRMS MAPPED`
- `1,500` / `COORDINATION LINKS`
- `$33.5T` / `INSTITUTIONAL CAPITAL`
- `1,066` / `NODES ONLINE`
- `823` / `USERS`
- `1,387` / `COMMITS`
- `7.83 Hz` / `SCHUMANN LOCK`

Units always attached to the number, never the label. Commas on thousands. Dollar/pound follows magnitude (`$33.5T`, `£33/mo`).

### Emoji — sigils, not decoration

A small, curated set is canonical. Never substitute an SVG for an emoji; the emoji *is* the mark.

**Venues (battlefronts):** 🦑 Kraken · 🔶 Binance · 🦙 Alpaca · 📈 Capital
**Predator firms (marketing only):** 🦈 Jane Street · 🦁 Citadel · 🐺 Two Sigma · 🕷️ Virtu · 🦅 DE Shaw · 🦊 Jump Trading · 🐻 Bridgewater · 🦂 Renaissance
**Systems:** 🏆 V14 · 🍄 Mycelium · 🦅 Commando · 🔮 Nexus · 🌌 Multiverse · 🧠 MinerBrain · 🌊 Harmonic · 🔱 Omega · 🏮 Lighthouse · 👻 Ghost Dance
**Ceremonial:** ✨ Observatory · 🜂 Fire (Tetrahedron) · 🜃 Earth (Hexahedron) · 🜁 Air (Octahedron) · 🜄 Water (Icosahedron) · ⟐ Ether (Dodecahedron)

Never in headings. Never as bullets. Never in body prose. **Always** in a status chip, venue label, or system tag.

### Tone examples (canonical)

- *"What if trading wasn't about extraction..."* (hero)
- *"$13 trillion institutional capital hunts retail liquidity. We mapped the hunters."* (proof)
- *"Queen voice is waiting for live intelligence snapshots."* (empty state)
- *"Updates: 42 | Last: 14:22:03"* (clock)
- *"Scout acquired. Sniper confirming. Harvester staging."* (tactical narration)
- *"Schumann lock 7.83 Hz · coherence 0.92"* (HNC status)

---

## VISUAL FOUNDATIONS

**Theme.** Dark-first, non-negotiable. `App.tsx` hard-sets `defaultTheme="dark"`. A light palette exists in CSS for accessibility fallback only.

### Palette (dark, runtime default)

| Role            | HSL                | Notes                                        |
| --------------- | ------------------ | -------------------------------------------- |
| Background      | `24 9% 10%`        | near-black warm charcoal                     |
| Card            | `12 6% 15%`        | slightly warmer than bg                      |
| Foreground      | `60 9% 97%`        | off-white cream                              |
| Muted fg        | `60 9% 97%` / 60%  | low-emphasis labels                          |
| Border          | `33 5% 32%`        | almost always used at `border/40`            |
| **Primary**     | `43 96% 56%`       | **SAMUEL amber-gold** — the brand color      |
| Primary fg      | `20 91% 14%`       | deep burnt brown on amber                    |
| Success         | `142 70% 45%`      | **528 Hz Love Green**                        |
| Destructive     | `0 84% 60%`        | **396 Hz Liberation Red**                    |
| Warning         | `43 96% 56%`       | doubles as primary — *432 Hz Clarity Gold*   |
| Info            | `185 100% 50%`     | *Quantum Cyan*                               |
| Unity           | `280 80% 60%`      | *Unity Violet / 963 Hz Divine*               |
| Ring / focus    | `43 96% 56%`       | matches primary                              |

### Solfeggio frequency tokens

Each tonal accent in the palette corresponds to a documented frequency. This is the "Harmonic" system layered on top of the raw CSS.

| Freq        | Meaning               | HSL                | CSS var                   |
| ----------- | --------------------- | ------------------ | ------------------------- |
| **396 Hz**  | Liberation            | `0 84% 60%`        | `--freq-liberation`       |
| **432 Hz**  | Clarity               | `43 96% 56%`       | `--freq-clarity`          |
| **528 Hz**  | Love / Transformation | `142 70% 45%`      | `--freq-love`             |
| **741 Hz**  | Awakening             | `185 100% 50%`     | `--freq-awakening`        |
| **963 Hz**  | Divine Consciousness  | `280 80% 60%`      | `--freq-divine`           |

Use frequencies as **labels**, not replacements — a chip reads `528 Hz · LOVE`, not just `528 Hz`. Mystical register punctuates; trader register carries the data.

### Prism spectrum (6-stop rainbow)

`red 0 85% 55%` → `gold 45 100% 55%` → `green 142 70% 45%` → `cyan 185 100% 50%` → `violet 280 80% 60%` → `magenta 320 80% 55%`.

Used for gradient text on headline moments, ceremonial borders, chart-series rotation, and as the hue stops of `--gradient-rainbow`.

### The Prism — 5 Platonic Solids

The Prism is the product's ontology, not just an accent. Each Platonic solid names a market-behavior regime and gets its own CSS utility.

| Solid          | Element  | Regime                    | Alchemical glyph | CSS class      |
| -------------- | -------- | ------------------------- | ---------------- | -------------- |
| Tetrahedron    | Fire     | Momentum / trend          | 🜂                | `.prism-fire`   |
| Hexahedron     | Earth    | Support / range-bound     | 🜃                | `.prism-earth`  |
| Octahedron     | Air      | Mean-reversion / volatility | 🜁              | `.prism-air`    |
| Icosahedron    | Water    | Liquidity / flow          | 🜄                | `.prism-water`  |
| Dodecahedron   | Ether    | Coherence / HNC-state     | ⟐                | `.prism-ether`  |

These appear as chips on signal cards ("Tetrahedron · Momentum · 87%") and as the five-column ribbon of the Prism Status strip.

### Signature gradients

- `--gradient-rainbow` — 6-stop 135° across the prism spectrum. Headline text + highest ceremony.
- `--gradient-prism` — 3-stop green → cyan → violet. Accent bars and buttons.
- `--gradient-love` — tight green → green. Love-pulse CTAs.
- `--gradient-liberation` — tight red → red. Destructive ceremony.
- `--gradient-void` — radial violet-core → near-black edge. **Fixed body background.** (`background-attachment: fixed`.)
- `--gradient-card` — subtle 135° card sheen, dark-on-dark.

### Typography

- **Sans — Source Sans Pro** (400 / 600 / 700) — UI body, titles, marketing paragraphs
- **Serif — Source Serif Pro** (400 / 600 / 700) — display, ceremony, Queen Voice narration, the master equation
- **Mono — Source Code Pro** (400 / 700) — prices, tickers, trade IDs, eyebrow labels, proof metrics, stats
- **CRT — Share Tech Mono** — HNC terminal mode only (scan-line panels)

Scale is **tight and small** on operator surfaces (default body 14px, metrics 11px, eyebrows 10px uppercase mono, card titles 18–20px). Marketing can go up to **80–120px serif** for hero, but mono labels stay at 10–12px. The contrast between huge serif and tiny mono is the brand's signature type move.

### Backgrounds

- Body uses `--gradient-void` fixed. Hero imagery is never a full-bleed replacement.
- Inner panels use `bg-muted/20` (≈10% warm grey) and `bg-background/60` for sub-containers.
- CRT / HNC panels: near-black with scan-line overlay + horizontal glitch clip.
- Marketing long-scroll alternates void → card → void. Never a pure-white section.

### Shadows / glow

- `--shadow-card` — `0 8px 32px -8px hsla(0,0,0,.5)`. Default card lift.
- `--shadow-glow-love` — green halo. Success pulse, live indicators.
- `--shadow-glow-prism` — cyan→violet dual halo. Accent CTAs.
- `--shadow-glow-rainbow` — triple-color halo. Highest ceremony only.
- Inner shadows not used. Elevation is carried by gradient + glow, not bevels.

### Borders & radii

- `border-border/40` (40% opacity border color) — canonical whisper-thin edge on cards
- Tinted status cells: `border-[color]/30` + `bg-[color]/10`
- `.border-prism` — prism gradient applied as `border-image` for ceremonial frames
- Base radius **1rem (16px)** for cards/buttons. Nested: `md = 14px`, `sm = 12px`. Pills `9999px`. Never sharp corners.

### Animation

Slow, smooth, looping. No bouncy easings.

- `love-pulse` — 2s ease-in-out infinite; scale 1→1.02 + green halo breathe. Live dots.
- `prism-shift` — 8s linear infinite; `hue-rotate(0→360deg)`. Rainbow artwork.
- `rainbow-flow` — 4s ease infinite; background-position pan. Gradient fills.
- `schumann-breathe` — 7.83s ease-in-out infinite; the sacred pulse on ceremonial surfaces.
- `shimmer` — 2s linear infinite; skeleton / loading.
- `fade-in` — 0.4s ease-out, 10px translate-Y.
- `slide-up` — 0.5s ease-out, 20px translate-Y.
- Reduced-motion safe. CSS animations only; no scroll-jacking.

### Hover / active / focus

- Buttons / primary: `hover:bg-primary/90` — 10% darker fill
- Secondary / ghost: `hover:bg-accent hover:text-accent-foreground` — tint shift
- Cards with `.card-hover-glow`: gain `--shadow-glow-love` + `border-color: hsl(primary/0.5)`
- Observatory CTA: `hover:scale-105` + shadow intensifies
- Focus — Radix default: `focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2`. Amber ring, visible on dark.

### Imagery

- **Hero photography** — moody low-key blue/orange trading-floor-adjacent. No people.
- **Research renders** — warm-cool scientific dual-tone (teal/orange on deep navy), feels like an oscilloscope or sky-map. `coherence-evolution.png`, `harmonic-feedback-loop.png`.
- **Spectral hero art** — prism dispersion of white light. `nexus-unity-path.png`, `prism-process-tree.png`.
- **Government / academic** — simple sans-serif text blocks, silver foil on charcoal. Silver Level Innovation badge, ministerial attribution.
- No faces. No stock illustration. No flat-design shapes. No iso-3D. No generic "abstract tech" patterns.

### Layout rules

- Dashboard max width: `max-w-6xl` (1152px)
- Marketing max width: `max-w-5xl` (1024px) for prose, `max-w-7xl` (1280px) for proof grids
- Padding: `p-4` mobile, `md:p-6` desktop
- Grid gap: `gap-4` for cards, `gap-10` for marketing sections
- Fixed elements: only the Observatory CTA (`fixed bottom-4 right-4 z-50`). No sticky sidebars.
- Info density is high on operator surfaces. Marketing is the opposite — generous negative space around huge serif claims.

---

## ICONOGRAPHY

### Primary icon set: `lucide-react` (^0.462.0)

Stroke-based, 1.5px default stroke, 24×24. Sized via Tailwind (`h-4 w-4`, `h-5`, `h-6`) and colored via `text-*` classes. Canonical set observed verbatim in the codebase:

```
Zap · RefreshCw · TrendingUp · TrendingDown · AlertTriangle · CheckCircle2
Activity · Wifi · WifiOff · Brain · Target · Sparkles · Shield · Crosshair · Eye
```

Loaded via CDN in this design-system package:
```html
<script src="https://unpkg.com/lucide@0.462.0/dist/umd/lucide.min.js"></script>
<!-- <i data-lucide="crosshair"></i> + lucide.createIcons() -->
```

### The Nine Archetypes / Auris Totems

The trading entity selects one of **nine named archetypes** per signal. This is not an emoji decision — it is a tactical posture. Each totem has a fixed glyph, color, and behavioral profile.

| Totem    | Glyph | Color (HSL)     | Posture                            |
| -------- | ----- | --------------- | ---------------------------------- |
| Eagle    | 🦅    | `43 96% 56%`    | High-altitude trend capture        |
| Wolf     | 🐺    | `215 20% 70%`   | Pack momentum · coordination       |
| Bear     | 🐻    | `24 40% 50%`    | Deep retracement · patience        |
| Bull     | 🐂    | `0 85% 55%`     | Breakout force · conviction        |
| Fox      | 🦊    | `20 95% 55%`    | Liquidity sniping · stealth        |
| Owl      | 🦉    | `280 80% 60%`   | Overnight · illiquid hours         |
| Serpent  | 🐍    | `142 70% 45%`   | Range coil · mean-reversion        |
| Dolphin  | 🐬    | `185 100% 50%`  | Flow-riding · adaptive             |
| Lion     | 🦁    | `45 100% 55%`   | Dominance · directional            |

Totem glyph + name are **always co-rendered** — never the glyph alone, never the name alone. Example chip: `🐺 WOLF · pack`.

### Firm tracking (marketing surface only)

The marketing site's "44,000 bots · 37 firms" section maps each tracked HFT firm to an animal glyph. These are adversaries, not totems — visually distinguished by a red-tinted chip border (`hsla(0,84%,60%,0.3)`).

🦈 Jane Street · 🦁 Citadel · 🐺 Two Sigma · 🕷️ Virtu · 🦅 DE Shaw · 🦊 Jump Trading · 🐻 Bridgewater · 🦂 Renaissance · 🦑 Hudson River Trading · 🦀 XTX Markets

### Alchemical glyphs — The Prism

🜂 Fire · 🜃 Earth · 🜁 Air · 🜄 Water · ⟐ Ether — one per Platonic solid. Used on signal cards and on the Prism Status strip at the top of the Terminal Mirror.

### SVG logo treatment

No dedicated logo SVG was found in-repo. The functional wordmark is **"AUREON"** (institute) or **"SAMUEL"** (product) in Source Serif Pro 700, letterspace −0.03em, with a 135° prism-gradient `background-clip: text` fill. See `preview/06-logo-wordmark.html` for the canonical treatment. A favicon (`assets/favicon.ico`) is provided but not distinct.

### Unicode as icons

Rare. Em-dash `—`, middle-dot `·`, bullet `•` for copy. Arrows `→` `←` `↑` `↓` for directional flows. Never box-drawing characters, never other Unicode symbols.

### Fonts

No TTF bundled in-repo. Google Fonts CDN loads Source Sans, Source Serif, Source Code, and Share Tech Mono at runtime. This design system mirrors that — see `colors_and_type.css`. If offline capability is later required, add `fonts/*.woff2` and rewrite as `@font-face`.

---

## UI KITS

- **`ui_kits/terminal-mirror/`** — pixel-faithful operator dashboard. Exchange cards, live signals, shadow validation, Queen Voice panel, Observatory CTA. Adds Nine Archetypes and Prism status strip.
- **`ui_kits/marketing-landing/`** — the evangelical long-scroll. Hero with prism-gradient headline, counter-intelligence proof grid (44,000 bots / 37 firms / $33.5T), manifesto body, tactical tier ladder (Scout → Sniper → Harvester), Tree of Light (8-level), pricing (£33/mo), government recognition, creator attribution.

## PREVIEW CARDS

All cards under `preview/` are registered for the Design System tab — Colors, Type, Spacing, Components, Brand.

## CAVEATS

- No dedicated logo SVG was found in the repo; the wordmark is reconstructed from Source Serif + prism gradient.
- The live managed dashboard at `aureoninstitute.com` is behind auth and was not directly observed; treatments here are inferred from the marketing site + self-hosted repo.
- Cinematic Observatory 3D scene uses `@react-three/fiber` at runtime; only the 2D entry CTA is recreated.
- Fonts load from Google Fonts CDN (mirrors product behavior). Add `fonts/*.woff2` if offline delivery is required.
- Proof metrics (44,000 bots, 37 firms, 1,500 links, etc.) are lifted verbatim from the marketing site — these are **living numbers**; treat them as layout placeholders and confirm current values before shipping.
