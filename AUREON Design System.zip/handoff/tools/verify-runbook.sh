#!/usr/bin/env bash
# tools/verify-runbook.sh
#
# Doc-rot sentinel for AUREON.
#
# Verifies that every command, file path, and env var named in /RUNNING.md
# actually exists in the repo, that anti-referenced (deprecated) scripts
# stay deleted, that the ignition script boots cleanly, and that the
# DigitalOcean deploy defaults stay safe.
#
# Run locally:
#     bash tools/verify-runbook.sh
#     bash tools/verify-runbook.sh --skip-boot     # docs-only checks
#     bash tools/verify-runbook.sh --quiet         # CI-friendly
#
# Exit codes:
#     0  all checks passed
#     1  doc rot — RUNNING.md disagrees with the repo
#     2  environment / boot failure (likely infra, not docs)

set -uo pipefail

# ── Args ────────────────────────────────────────────────────────────────────
SKIP_BOOT=0
QUIET=0
for arg in "$@"; do
    case "$arg" in
        --skip-boot) SKIP_BOOT=1 ;;
        --quiet)     QUIET=1 ;;
        -h|--help)
            sed -n '2,18p' "$0"
            exit 0
            ;;
        *) echo "unknown arg: $arg" >&2; exit 2 ;;
    esac
done

# ── Locate repo root ────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "${REPO_ROOT}"

RUNBOOK="${REPO_ROOT}/RUNNING.md"

if [[ ! -f "${RUNBOOK}" ]]; then
    echo "FATAL: RUNNING.md not found at repo root (${RUNBOOK})" >&2
    exit 2
fi

# ── Output helpers ──────────────────────────────────────────────────────────
if [[ -t 1 && "${QUIET}" -eq 0 ]]; then
    C_RESET=$'\e[0m'; C_DIM=$'\e[2m'; C_BOLD=$'\e[1m'
    C_GREEN=$'\e[32m'; C_RED=$'\e[31m'; C_YELLOW=$'\e[33m'; C_CYAN=$'\e[36m'
else
    C_RESET=""; C_DIM=""; C_BOLD=""; C_GREEN=""; C_RED=""; C_YELLOW=""; C_CYAN=""
fi

PASS=0
FAIL=0
SKIP=0
FAIL_MESSAGES=()

section() {
    if [[ "${QUIET}" -eq 0 ]]; then
        echo
        echo "${C_BOLD}${C_CYAN}── $1 ──${C_RESET}"
    fi
}

ok()    { PASS=$((PASS+1)); [[ "${QUIET}" -eq 0 ]] && echo "  ${C_GREEN}✓${C_RESET} $1"; }
fail()  { FAIL=$((FAIL+1)); FAIL_MESSAGES+=("$1"); echo "  ${C_RED}✗${C_RESET} $1" >&2; }
skip()  { SKIP=$((SKIP+1)); [[ "${QUIET}" -eq 0 ]] && echo "  ${C_YELLOW}∘${C_RESET} $1 ${C_DIM}(skipped)${C_RESET}"; }
note()  { [[ "${QUIET}" -eq 0 ]] && echo "    ${C_DIM}$1${C_RESET}"; }

# ────────────────────────────────────────────────────────────────────────────
# 1. Required files exist
# ────────────────────────────────────────────────────────────────────────────
section "1. Required files exist"

REQUIRED_FILES=(
    "scripts/aureon_ignition.py"
    "run_hnc_live.py"
    ".env.example"
    "requirements.txt"
    "docs/LIVE_TRADING_RUNBOOK.md"
    "Dockerfile"
    "app.yaml"
)

for f in "${REQUIRED_FILES[@]}"; do
    if [[ -f "${REPO_ROOT}/${f}" ]]; then
        ok "${f}"
    else
        fail "MISSING: ${f} — RUNNING.md references this file but it doesn't exist"
    fi
done

# ────────────────────────────────────────────────────────────────────────────
# 2. Env-var contract
# ────────────────────────────────────────────────────────────────────────────
section "2. Env-var contract (.env.example + LIVE_TRADING_RUNBOOK.md)"

# Vars RUNNING.md tells users to set. If we mention it in the doc, it
# must appear in at least one official source.
DOCUMENTED_VARS=(
    BINANCE_API_KEY
    BINANCE_API_SECRET
    BINANCE_USE_TESTNET
    BINANCE_DRY_RUN
    BINANCE_RISK_FRACTION
    BINANCE_RISK_MAX_ORDER_USDT
    KRAKEN_API_KEY
    KRAKEN_API_SECRET
    KRAKEN_DRY_RUN
    ALPACA_API_KEY
    ALPACA_SECRET_KEY
    ALPACA_PAPER
    ALPACA_DRY_RUN
    CAPITAL_API_KEY
    CAPITAL_IDENTIFIER
    CAPITAL_PASSWORD
    CAPITAL_DEMO_MODE
    AUREON_LIVE_TRADING
    AUREON_STATE_DIR
    AUREON_REDIS_URL
    REAL_DATA_ONLY
    CONFIRM_LIVE
    LIVE
    COINAPI_KEY
)

ENV_SOURCES=()
[[ -f .env.example ]] && ENV_SOURCES+=(".env.example")
[[ -f docs/LIVE_TRADING_RUNBOOK.md ]] && ENV_SOURCES+=("docs/LIVE_TRADING_RUNBOOK.md")
[[ -f app.yaml ]] && ENV_SOURCES+=("app.yaml")

for v in "${DOCUMENTED_VARS[@]}"; do
    if grep -qE "(^|[^A-Z_])${v}([^A-Z_]|=|$)" "${ENV_SOURCES[@]}" 2>/dev/null; then
        ok "${v}"
    else
        fail "UNDOCUMENTED: ${v} appears in RUNNING.md but not in .env.example, app.yaml, or LIVE_TRADING_RUNBOOK.md"
    fi
done

# ────────────────────────────────────────────────────────────────────────────
# 3. Deprecated commands stay deleted
# ────────────────────────────────────────────────────────────────────────────
section "3. Deprecated entry points stay deleted"

# RUNNING.md §6 explicitly tells users NOT to run these. If any reappear,
# either the doc or the resurrection is wrong — flag it.
DEPRECATED_PATHS=(
    "aureon_full_autonomy.py"
    "aureon_unified_ecosystem.py"
    "aureon_live.py"
    "scripts/paperTradeSimulation.ts"
)

for p in "${DEPRECATED_PATHS[@]}"; do
    if [[ -e "${REPO_ROOT}/${p}" ]]; then
        fail "RESURRECTED: ${p} exists again — RUNNING.md §6 says it shouldn't. Either un-resurrect or update the doc."
    else
        ok "${p} is absent (as documented)"
    fi
done

# ────────────────────────────────────────────────────────────────────────────
# 4. DigitalOcean safety defaults
# ────────────────────────────────────────────────────────────────────────────
section "4. app.yaml DigitalOcean safety defaults"

if [[ -f app.yaml ]]; then
    # Each key MUST default to safe (true / "0"). Match the value on the
    # *next* line after the key, since DO YAML uses key/value pairs.
    check_yaml_default() {
        local key="$1" expected="$2"
        # Pull the value line that follows `key: "$key"`
        local value
        value="$(grep -A1 -E "^[[:space:]]+- key:[[:space:]]+${key}\b" app.yaml \
                  | grep -E "^[[:space:]]+value:" \
                  | head -n1 \
                  | sed -E 's/.*value:[[:space:]]*"?([^"]*)"?.*/\1/' )"
        if [[ "${value}" == "${expected}" ]]; then
            ok "app.yaml ${key} = \"${expected}\""
        elif [[ -z "${value}" ]]; then
            fail "app.yaml: ${key} not found (expected default \"${expected}\")"
        else
            fail "app.yaml: ${key} = \"${value}\" — expected \"${expected}\" (RUNNING.md §7)"
        fi
    }

    check_yaml_default "LIVE"            "0"
    check_yaml_default "KRAKEN_DRY_RUN"  "true"
    check_yaml_default "BINANCE_DRY_RUN" "true"
    check_yaml_default "ALPACA_DRY_RUN"  "true"
else
    skip "app.yaml not present"
fi

# ────────────────────────────────────────────────────────────────────────────
# 5. Boot smoke — does ignition reach IGNITION COMPLETE?
# ────────────────────────────────────────────────────────────────────────────
section "5. Boot smoke — scripts/aureon_ignition.py --no-trade"

if [[ "${SKIP_BOOT}" -eq 1 ]]; then
    skip "boot smoke (--skip-boot)"
elif ! command -v python3 >/dev/null 2>&1; then
    skip "boot smoke (python3 not on PATH)"
elif [[ ! -f scripts/aureon_ignition.py ]]; then
    skip "boot smoke (script missing — already counted in §1)"
else
    LOG="$(mktemp)"
    note "running with 90s timeout, output → ${LOG}"

    # Run, kill on first matching line, fail if banner not seen in 90s.
    set +e
    timeout 90s python3 scripts/aureon_ignition.py --no-trade >"${LOG}" 2>&1 &
    BOOT_PID=$!

    DEADLINE=$((SECONDS + 90))
    SAW_COMPLETE=0
    while (( SECONDS < DEADLINE )); do
        if grep -q "IGNITION COMPLETE" "${LOG}" 2>/dev/null; then
            SAW_COMPLETE=1
            break
        fi
        if ! kill -0 "${BOOT_PID}" 2>/dev/null; then
            break
        fi
        sleep 1
    done

    # Stop the process either way
    kill -TERM "${BOOT_PID}" 2>/dev/null
    wait "${BOOT_PID}" 2>/dev/null
    set -e

    if [[ "${SAW_COMPLETE}" -eq 1 ]]; then
        ok "ignition reached 'IGNITION COMPLETE'"

        if grep -qE "Flight check:[[:space:]]+[0-9]+/[0-9]+[[:space:]]+GO" "${LOG}"; then
            ok "flight check posted"
        else
            fail "ignition booted but no 'Flight check: N/N GO' line"
        fi

        if grep -qE "NO-?GO" "${LOG}"; then
            fail "one or more subsystems reported NO-GO — see ${LOG}"
        else
            ok "no NO-GO subsystems"
        fi
    else
        fail "ignition did not reach 'IGNITION COMPLETE' within 90s — see ${LOG}"
    fi
fi

# ────────────────────────────────────────────────────────────────────────────
# Summary
# ────────────────────────────────────────────────────────────────────────────
echo
echo "${C_BOLD}── Summary ──${C_RESET}"
echo "  ${C_GREEN}pass:${C_RESET} ${PASS}"
echo "  ${C_RED}fail:${C_RESET} ${FAIL}"
echo "  ${C_YELLOW}skip:${C_RESET} ${SKIP}"
echo
echo "VERIFY: pass=${PASS} fail=${FAIL} skip=${SKIP}"

if (( FAIL > 0 )); then
    echo
    echo "${C_RED}${C_BOLD}Doc rot detected.${C_RESET}"
    echo "RUNNING.md disagrees with the repo on ${FAIL} item(s):"
    for m in "${FAIL_MESSAGES[@]}"; do
        echo "  • ${m}"
    done
    echo
    echo "Fix: either update RUNNING.md to match the code, or update the code to match RUNNING.md."
    exit 1
fi

echo "${C_GREEN}${C_BOLD}All checks passed.${C_RESET}"
exit 0
