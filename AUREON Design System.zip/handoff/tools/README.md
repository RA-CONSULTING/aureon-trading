# tools/

Operational tooling. Small scripts, big payoff.

---

## `verify-runbook.sh` — doc-rot sentinel

Verifies that `/RUNNING.md` is still telling the truth.

### What it checks

| § | Check | Why it matters |
|---|---|---|
| 1 | Every script `RUNNING.md` references exists at the path it claims | Catches `aureon_ignition.py` being renamed without a doc update |
| 2 | Every documented env var appears in `.env.example`, `app.yaml`, or `docs/LIVE_TRADING_RUNBOOK.md` | Catches doc-only env vars that aren't actually read |
| 3 | Deprecated entry points stay deleted (the "What not to do" list) | Catches resurrection of `aureon_full_autonomy.py`, `aureon_live.py`, etc. |
| 4 | `app.yaml` defaults to **safe** for `LIVE`, `KRAKEN_DRY_RUN`, `BINANCE_DRY_RUN`, `ALPACA_DRY_RUN` | Cloud deploys never silently ship into live trading |
| 5 | `python scripts/aureon_ignition.py --no-trade` reaches `IGNITION COMPLETE` in ≤90s with no `NO-GO` flight-check items | The boot path still works on a fresh clone |

### Run it

```bash
# Full run (requires Python + deps installed)
bash tools/verify-runbook.sh

# Docs-only (fast — no Python needed)
bash tools/verify-runbook.sh --skip-boot

# CI-friendly (no color, less output)
bash tools/verify-runbook.sh --quiet
```

### Exit codes

| Code | Meaning | What to do |
|---|---|---|
| `0` | All checks passed | Nothing — ship it |
| `1` | **Doc rot** detected — RUNNING.md disagrees with the repo | Update `RUNNING.md` to match the code, or update the code to match `RUNNING.md` |
| `2` | Environment / boot failure (likely infra, not docs) | Check Python install, deps, repo integrity |

### Output format

```
── 1. Required files exist ──
  ✓ scripts/aureon_ignition.py
  ✓ run_hnc_live.py
  ✓ .env.example
  ✗ MISSING: docs/LIVE_TRADING_RUNBOOK.md — RUNNING.md references this file but it doesn't exist

── 2. Env-var contract ──
  ✓ BINANCE_API_KEY
  ✓ BINANCE_USE_TESTNET
  ✗ UNDOCUMENTED: BINANCE_RISK_FRACTION appears in RUNNING.md but not in .env.example…

…

── Summary ──
  pass: 28
  fail: 2
  skip: 0

VERIFY: pass=28 fail=2 skip=0

Doc rot detected.
RUNNING.md disagrees with the repo on 2 item(s):
  • MISSING: docs/LIVE_TRADING_RUNBOOK.md…
  • UNDOCUMENTED: BINANCE_RISK_FRACTION…
```

The final `VERIFY: pass=N fail=N skip=N` line is machine-readable. Pipe it into your monitoring of choice.

---

## CI integration

`.github/workflows/verify-runbook.yml` runs the verifier:

- **On PRs** that touch `RUNNING.md`, `scripts/`, `app.yaml`, `.env.example`, or live-trading runbook
- **On push to `main`** for the same paths
- **Weekly** (Mondays 09:00 UTC) to catch drift from unrelated changes

Two jobs:

1. **`docs-only`** — `--skip-boot`. Runs in ~10s. No Python install needed. Catches 80% of doc rot.
2. **`boot-smoke`** — full run. Installs deps, runs ignition with 90s timeout. Catches the rest.

The docs-only job is a required check on PRs. Boot-smoke is informational on PRs (so a slow Python install doesn't block doc fixes) and required on main + cron.

---

## Adding new checks

Open `tools/verify-runbook.sh` and add a new `section "N. …"` block. The helpers are:

| Helper | Use |
|---|---|
| `ok "msg"` | Check passed |
| `fail "msg"` | Check failed (records the message for the summary) |
| `skip "msg"` | Check skipped (env or arg) |
| `note "msg"` | Dim informational line |

Failures aggregate — the script doesn't fast-exit, so one PR sees every problem at once instead of fixing-rebuilding-failing N times.

### Things worth adding later

- Diff `.env.example` against the actual `os.environ.get(...)` calls under `aureon/` — surfaces vars read by code but never documented (the inverse of what we check today)
- Verify the operator-dashboard frontend can build (`cd frontend && npm run build`) when frontend code changes
- Validate that every link in `RUNNING.md` resolves (other docs, anchor targets)

Don't add checks that don't pull their weight in CI time. The sentinel is only useful if it stays fast.
