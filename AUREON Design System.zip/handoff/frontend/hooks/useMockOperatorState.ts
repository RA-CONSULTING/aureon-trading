/**
 * useMockOperatorState
 *
 * Fake-data hook for the Operator's Seat panels (KillSwitchPanel,
 * RiskEnvelopePanel, DecisionsFeed). Drop-in shape-compatible with
 * useGlobalState — when the real hook exposes these fields, swap the
 * import. Until then, this lets us review the design without booting
 * aureon_frontend_bridge.py or wiring Supabase.
 *
 * Toggle by setting VITE_OPERATOR_MOCK=true in .env.
 *
 * Type definitions live here too so the components can import a single
 * source of truth.
 */

import { useEffect, useRef, useState } from 'react';

// ─────────────────────────────────────────────────────────────────────────────
// Shared types — these are what useGlobalState (eventually) must expose
// ─────────────────────────────────────────────────────────────────────────────

export type ExchangeId = 'binance' | 'kraken' | 'alpaca' | 'capital';

export type Side = 'BUY' | 'SELL';

export interface OpenPosition {
  id: string;
  exchange: ExchangeId;
  symbol: string;
  side: Side;
  quantity: number;
  entryPrice: number;
  markPrice: number;
  notionalUsd: number;
  unrealizedPnl: number;
  ageSeconds: number;
}

export interface RiskState {
  // Daily P&L vs cap
  dailyPnlUsd: number;             // negative = loss
  dailyLossCapUsd: number;         // e.g. -250
  dailyPnlPctOfCap: number;        // 0..1, where 1 = at cap

  // Exposure vs cap (per exchange + total)
  totalExposureUsd: number;
  exposureCapUsd: number;
  exposurePctOfCap: number;        // 0..1

  // Per-trade sizing (mirrors BINANCE_RISK_*)
  riskFraction: number;            // 0.02 = 2% of free quote
  maxOrderUsd: number;             // BINANCE_RISK_MAX_ORDER_USDT
  lastOrderUsd: number;            // most recent order size

  // Throttle state
  throttleState: 'normal' | 'cooling' | 'paused';
  throttleReason: string | null;
  consecutiveLosses: number;

  // Heartbeat
  secondsSinceLastTrade: number;
}

export type DecisionKind =
  | 'TRADE'           // an order was placed
  | 'SKIP'            // signal triggered but blocked (risk, throttle, dupe)
  | 'CLOSE'           // a position was closed
  | 'SIGNAL'          // signal received but didn't act
  | 'RISK'            // risk-manager intervention
  | 'SYSTEM';         // boot, reconnect, halt, restart

export interface Decision {
  id: string;
  ts: number;                      // ms epoch
  kind: DecisionKind;
  exchange: ExchangeId | null;
  symbol: string | null;
  side: Side | null;
  notionalUsd: number | null;
  // Reasoning chain — each entry is a short clause shown indented
  reasons: string[];
  // Provenance
  system: string;                  // 'Lighthouse' | 'Mycelium' | …
  lambda: number | null;           // Λ value at decision time
  aurisNode: string | null;        // dominant archetype
  // Outcome (only for TRADE / CLOSE)
  fillPrice: number | null;
  pnlUsd: number | null;
}

export interface ExchangeHealth {
  id: ExchangeId;
  connected: boolean;
  keysValid: boolean;
  ipWhitelisted: boolean | null;   // null = couldn't verify
  latencyMs: number | null;
  lastHeartbeatTs: number;
  mode: 'live' | 'paper' | 'testnet' | 'demo' | 'dry-run';
}

export interface OperatorState {
  // Read state
  openPositions: OpenPosition[];
  risk: RiskState;
  decisions: Decision[];           // newest first, capped at ~200
  exchanges: ExchangeHealth[];
  isActive: boolean;               // master trading flag
  isFlattening: boolean;           // a flatten is in progress

  // Write actions
  flattenAll: () => Promise<{ closed: number; failed: number }>;
  haltTrading: () => Promise<void>;
  resumeTrading: () => Promise<void>;

  // Diagnostics
  mockMode: boolean;
}

// ─────────────────────────────────────────────────────────────────────────────
// Seed data — realistic-ish so the design review is honest
// ─────────────────────────────────────────────────────────────────────────────

const SYMBOLS = [
  'BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'AVAXUSDT',
  'BTC/USD',  'ETH/USD',  'SOL/USD',
];

const SYSTEMS = ['Lighthouse', 'Mycelium', 'Commando', 'Nexus', 'V14', 'Harmonic'];

const AURIS_NODES = [
  'Sniper', 'Scout', 'Harvester', 'Sentinel', 'Architect',
  'Oracle', 'Trickster', 'Smith', 'Sovereign',
];

const REASON_BANK: Record<DecisionKind, string[]> = {
  TRADE: [
    'Lighthouse signal · Λ above threshold',
    'Auris consensus 7/9 · dominant Sniper',
    'Mycelium pattern match · 4 corroborating exchanges',
    'Order capped at max-per-trade',
    'Volatility expansion · momentum +1.8σ',
    'Harvester opportunistic add · low spread',
  ],
  SKIP: [
    'Throttle active · 3 consecutive losses',
    'Daily loss cap at 78% · risk-manager refused',
    'Duplicate of open position · already long',
    'Spread > 0.3% · skipped',
    'Confidence 0.41 below 0.55 floor',
    'Outside trading hours for venue',
  ],
  CLOSE: [
    'Stop-loss hit · -1.2%',
    'Take-profit reached · +2.4%',
    'Trailing stop ratcheted',
    'Risk-manager forced close · exposure cap',
    'Signal reversal · Λ flipped negative',
  ],
  SIGNAL: [
    'Confidence below action threshold · monitoring',
    'No quote on venue · skipped',
    'Pre-market window · waiting',
  ],
  RISK: [
    'Daily loss approaching 80% · throttling',
    'Exposure cap reached on Binance · pausing new entries',
    'Heartbeat lost · disconnecting venue',
    'Slippage anomaly · halting venue',
  ],
  SYSTEM: [
    'Ignition complete · 100/100 systems online',
    'Binance reconnected · resuming',
    'Reload requested · soft restart',
    'Operator override · manual halt',
  ],
};

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function rid() {
  return Math.random().toString(36).slice(2, 10);
}

function seedPositions(): OpenPosition[] {
  const exchanges: ExchangeId[] = ['binance', 'kraken', 'alpaca'];
  return [
    {
      id: rid(), exchange: 'binance', symbol: 'ETHUSDT', side: 'BUY',
      quantity: 0.42, entryPrice: 3201.40, markPrice: 3247.10,
      notionalUsd: 1363.78, unrealizedPnl: 19.19, ageSeconds: 1840,
    },
    {
      id: rid(), exchange: 'binance', symbol: 'SOLUSDT', side: 'BUY',
      quantity: 8.5, entryPrice: 187.20, markPrice: 184.10,
      notionalUsd: 1564.85, unrealizedPnl: -26.35, ageSeconds: 612,
    },
    {
      id: rid(), exchange: 'kraken', symbol: 'BTC/USD', side: 'BUY',
      quantity: 0.018, entryPrice: 96420.00, markPrice: 96810.00,
      notionalUsd: 1742.58, unrealizedPnl: 7.02, ageSeconds: 4220,
    },
    {
      id: rid(), exchange: 'alpaca', symbol: 'AAPL', side: 'BUY',
      quantity: 12, entryPrice: 224.10, markPrice: 226.40,
      notionalUsd: 2716.80, unrealizedPnl: 27.60, ageSeconds: 8100,
    },
  ].filter(() => Math.random() > 0.05); // keep most every render — tiny variation
}

function seedRisk(positions: OpenPosition[]): RiskState {
  const totalExposure = positions.reduce((s, p) => s + p.notionalUsd, 0);
  const dailyPnl = -127.40; // realistic mid-day drawdown
  const cap = -250;
  return {
    dailyPnlUsd: dailyPnl,
    dailyLossCapUsd: cap,
    dailyPnlPctOfCap: Math.min(1, Math.abs(dailyPnl) / Math.abs(cap)),
    totalExposureUsd: totalExposure,
    exposureCapUsd: 10000,
    exposurePctOfCap: Math.min(1, totalExposure / 10000),
    riskFraction: 0.02,
    maxOrderUsd: 25,
    lastOrderUsd: 24.80,
    throttleState: 'normal',
    throttleReason: null,
    consecutiveLosses: 1,
    secondsSinceLastTrade: 142,
  };
}

function seedDecisions(): Decision[] {
  const now = Date.now();
  const items: Decision[] = [];

  // 18 backfill entries spaced 30–180s apart
  let t = now;
  for (let i = 0; i < 18; i++) {
    t -= 30_000 + Math.random() * 150_000;
    const kind: DecisionKind = pick([
      'TRADE', 'TRADE', 'SIGNAL', 'SKIP', 'CLOSE', 'TRADE', 'RISK', 'TRADE',
    ] as DecisionKind[]);
    const isTrade = kind === 'TRADE' || kind === 'CLOSE';
    const exchange = pick(['binance', 'kraken', 'alpaca'] as ExchangeId[]);
    const symbol = pick(SYMBOLS);
    const side: Side = pick(['BUY', 'SELL'] as Side[]);
    items.push({
      id: rid(),
      ts: t,
      kind,
      exchange: kind === 'SYSTEM' ? null : exchange,
      symbol: kind === 'SYSTEM' ? null : symbol,
      side: isTrade ? side : null,
      notionalUsd: isTrade ? 18 + Math.random() * 8 : null,
      reasons: [pick(REASON_BANK[kind]), pick(REASON_BANK[kind])].filter(
        (v, i, a) => a.indexOf(v) === i,
      ),
      system: pick(SYSTEMS),
      lambda: kind === 'SYSTEM' ? null : 0.4 + Math.random() * 0.5,
      aurisNode: kind === 'SYSTEM' ? null : pick(AURIS_NODES),
      fillPrice: isTrade ? 100 + Math.random() * 50000 : null,
      pnlUsd: kind === 'CLOSE' ? -8 + Math.random() * 22 : null,
    });
  }
  return items;
}

function seedExchanges(): ExchangeHealth[] {
  const now = Date.now();
  return [
    {
      id: 'binance', connected: true, keysValid: true, ipWhitelisted: true,
      latencyMs: 84, lastHeartbeatTs: now - 1200, mode: 'testnet',
    },
    {
      id: 'kraken', connected: true, keysValid: true, ipWhitelisted: true,
      latencyMs: 142, lastHeartbeatTs: now - 800, mode: 'live',
    },
    {
      id: 'alpaca', connected: true, keysValid: true, ipWhitelisted: null,
      latencyMs: 67, lastHeartbeatTs: now - 2100, mode: 'paper',
    },
    {
      id: 'capital', connected: false, keysValid: false, ipWhitelisted: null,
      latencyMs: null, lastHeartbeatTs: now - 47_000, mode: 'demo',
    },
  ];
}

// ─────────────────────────────────────────────────────────────────────────────
// Hook
// ─────────────────────────────────────────────────────────────────────────────

export function useMockOperatorState(): OperatorState {
  const [positions, setPositions] = useState<OpenPosition[]>(() => seedPositions());
  const [risk, setRisk] = useState<RiskState>(() => seedRisk(seedPositions()));
  const [decisions, setDecisions] = useState<Decision[]>(() => seedDecisions());
  const [exchanges, setExchanges] = useState<ExchangeHealth[]>(() => seedExchanges());
  const [isActive, setIsActive] = useState(true);
  const [isFlattening, setIsFlattening] = useState(false);

  const tickRef = useRef(0);

  // Heartbeat — drift mark prices, age positions, occasionally append a decision
  useEffect(() => {
    const interval = setInterval(() => {
      tickRef.current++;

      // Age positions, drift marks
      setPositions(prev =>
        prev.map(p => {
          const drift = (Math.random() - 0.5) * p.markPrice * 0.0008;
          const newMark = p.markPrice + drift;
          const newPnl = p.side === 'BUY'
            ? (newMark - p.entryPrice) * p.quantity
            : (p.entryPrice - newMark) * p.quantity;
          return {
            ...p,
            markPrice: newMark,
            notionalUsd: newMark * p.quantity,
            unrealizedPnl: newPnl,
            ageSeconds: p.ageSeconds + 2,
          };
        })
      );

      // Refresh risk derived state
      setRisk(prev => ({
        ...prev,
        secondsSinceLastTrade: prev.secondsSinceLastTrade + 2,
      }));

      // Occasionally append a new decision
      if (tickRef.current % 4 === 0) {
        const now = Date.now();
        const kind: DecisionKind = pick([
          'TRADE', 'SIGNAL', 'SKIP', 'TRADE', 'SIGNAL',
        ] as DecisionKind[]);
        const isTrade = kind === 'TRADE';
        const exchange = pick(['binance', 'kraken', 'alpaca'] as ExchangeId[]);
        const next: Decision = {
          id: rid(),
          ts: now,
          kind,
          exchange,
          symbol: pick(SYMBOLS),
          side: isTrade ? pick(['BUY', 'SELL'] as Side[]) : null,
          notionalUsd: isTrade ? 18 + Math.random() * 8 : null,
          reasons: [pick(REASON_BANK[kind])],
          system: pick(SYSTEMS),
          lambda: 0.4 + Math.random() * 0.5,
          aurisNode: pick(AURIS_NODES),
          fillPrice: isTrade ? 100 + Math.random() * 50000 : null,
          pnlUsd: null,
        };
        setDecisions(prev => [next, ...prev].slice(0, 200));
      }

      // Occasionally bump exchange latency
      if (tickRef.current % 5 === 0) {
        setExchanges(prev =>
          prev.map(x => ({
            ...x,
            latencyMs: x.connected
              ? Math.max(40, (x.latencyMs ?? 100) + (Math.random() - 0.5) * 20)
              : x.latencyMs,
            lastHeartbeatTs: x.connected ? Date.now() : x.lastHeartbeatTs,
          })),
        );
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  // Actions
  const flattenAll = async () => {
    setIsFlattening(true);
    const closed = positions.length;

    // Simulate per-position close with a realistic small delay each
    for (let i = 0; i < positions.length; i++) {
      await new Promise(r => setTimeout(r, 350));
      setPositions(prev => prev.slice(0, prev.length - 1));
    }

    const now = Date.now();
    setDecisions(prev => [
      {
        id: rid(),
        ts: now,
        kind: 'SYSTEM',
        exchange: null,
        symbol: null,
        side: null,
        notionalUsd: null,
        reasons: [
          'Operator FLATTEN ALL · positions closed',
          `${closed} positions reduced to flat`,
        ],
        system: 'Operator',
        lambda: null,
        aurisNode: null,
        fillPrice: null,
        pnlUsd: null,
      },
      ...prev,
    ].slice(0, 200));

    setIsActive(false);
    setIsFlattening(false);
    return { closed, failed: 0 };
  };

  const haltTrading = async () => { setIsActive(false); };
  const resumeTrading = async () => { setIsActive(true); };

  return {
    openPositions: positions,
    risk,
    decisions,
    exchanges,
    isActive,
    isFlattening,
    flattenAll,
    haltTrading,
    resumeTrading,
    mockMode: true,
  };
}
