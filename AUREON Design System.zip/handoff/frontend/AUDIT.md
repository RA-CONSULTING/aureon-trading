# Frontend Audit + Proposal

**Verified against** `RA-CONSULTING/aureon-trading` `main`, `frontend/src/components/`.
**Date:** the day this PR opens.
**Author:** design system handoff.

---

## TL;DR

You don't need a new operator dashboard. You have **three** already, plus a 12-component panel library on top of them. What you need is **(1) a decision to consolidate, and (2) one missing piece** — a focused **Operator's Seat** for the moment-of-truth actions (kill switch, risk envelope, exchange health) that none of the existing dashboards expose well.

This document proposes the smallest set of changes that produce the largest improvement: **deprecate one dashboard, restyle the survivor with AUREON tokens, add one new surface, ship.**

---

## 1. What exists today

### Three dashboards, one winner

| File | LOC | Data | Verdict |
|---|---:|---|---|
| `AureonDashboard.tsx` | 390 | `useGlobalState` (global manager) + Supabase auth | **Keep — production-grade.** Tab shell, real auth, real systems status, recent trades. |
| `AureonLiveDashboard.tsx` | 461 | `useAureonLiveData` (WebSocket → `aureon_frontend_bridge.py`) | **Deprecate — duplicate purpose.** Card grid showing exchanges/signals/balances. The data shape is a strict subset of what `useGlobalState` already exposes. The real-time WS data should feed *into* `useGlobalState`, not power a parallel UI. |
| `cinema/CinematicObservatory.tsx` | (8 files) | `useGlobalState` + `useHiveState` + `useConsciousnessStream` | **Keep — separate purpose.** This is the cinematic/HUD experience, not the operator's working surface. Don't touch. |

**Recommendation:** delete `AureonLiveDashboard.tsx`. Move its WebSocket connection into `useGlobalState` if it isn't already there (verify with engineer). Update the router to redirect `/live` → `/dashboard`.

### 12 panels — group by purpose

| Group | Components | Status |
|---|---|---|
| **Operator panels** (real, useful) | `LiveTerminalStats`, `BrainStatePanel`, `AurisEngine`, `ExchangeStatusSummary` | Keep |
| **Visualizers** (mystical surface) | `AuraRingVisualizer`, `AkashicFrequencyVisualization`, `AuraNarrativeRenderer`, `CelestialAlignments` | Keep, scope unclear — likely belong on a separate Observatory page, not on the operator dashboard |
| **Cinema HUD primitives** | `HUDTopBar`, `HUDConsciousnessPanel`, `HUDMetricsPanel`, `HUDNarrator`, `HUDQueenVoice`, `HUDTradeStream` | Keep, well-organized in `cinema/` |
| **Tree** | `AureonProcessTree` | Unknown — needs an opener (likely an experimental view) |

No orphans I can see. The `cinema/` folder convention is good. The non-cinema components live flat in `components/` — fine.

### What's missing that operators actually need

The existing `AureonDashboard` shows balances, P&L, signals, and quantum state. It does **not** expose:

1. **A two-step kill switch** — there's a `<Stop>` button that flips `isActive`, but nothing that flattens positions and halts orders system-wide. The runbook (`RUNNING.md` §8) tells operators to "click FLATTEN ALL → type FLATTEN" — that UI doesn't exist.
2. **Per-exchange risk envelope** — daily loss vs cap, max-order vs cap, throttle state. The `BINANCE_RISK_*` env vars exist but their live values aren't surfaced.
3. **Decisions feed with reasons** — `lastSignal` + `lastDecision` are shown, but there's no streaming log of "what just happened, why, and what's next."
4. **Exchange-key health** — `ExchangeStatusSummary` exists but I haven't read it; likely shows connection status only, not key-permission/IP-whitelist sanity.

---

## 2. Proposal — three changes, ranked by ROI

### Change 1 — `<KillSwitchPanel>`  *(highest ROI, smallest scope)*

A new component that drops into `AureonDashboard`'s overview tab and `CinematicObservatory`. Two-step:

1. **Click** "FLATTEN ALL" — opens a modal showing every open position across exchanges, total notional at risk
2. **Type** `FLATTEN` exactly — confirm button activates
3. **Click confirm** — POSTs `/api/risk/flatten`, halts the global trading flag, shows real-time progress as orders close

Optional **5-second held-button** variant for live mode. Tweakable.

**~250 lines of TSX.** Standalone, testable. Mocked data path so design review doesn't need a backend.

### Change 2 — `<RiskEnvelopePanel>`

Surfaces the runtime risk state that's currently invisible:

- Today's realized P&L vs daily-loss cap (progress bar; red at 80%)
- Open exposure vs max-exposure cap (per exchange)
- Per-trade order size vs `BINANCE_RISK_MAX_ORDER_USDT`
- Throttle state — is the system slowed/paused due to consecutive losses?
- Time since last trade

**~180 lines.** Lives on the overview tab next to "Performance."

### Change 3 — `<DecisionsFeed>` *(streaming log)*

Replaces the lonely "Last Signal" card with a scrolling, time-stamped log of what the bots did and why. Each entry:

```
14:32:08  BINANCE  BUY  ETHUSDT  0.012  @ 3,247.10
          ⬑ Lighthouse signal · Λ=0.82 · Auris dominant=Sniper
          ⬑ Risk: 1.4% of free quote · Order capped at 25 USDT ✓
```

Auto-scroll, pause-on-hover, jump-to-now, filter by exchange/system/side. **~220 lines.**

### Change 4 (optional) — Restyle `AureonDashboard` with AUREON tokens

Current dashboard uses generic shadcn. The AUREON design system (gold/black, CRT phosphor accents, Source Serif headers, Source Code mono data) is dramatically more on-brand. **This is a 4-hour styling pass** — find/replace `text-green-400` → `text-success`, swap card borders to gold/black, replace emoji exchange icons with the sigil set already in `assets/`.

I recommend doing this **after** changes 1–3 land — they're additive and safer. Restyling touches every component.

---

## 3. What I will NOT do (and why)

- **Build a fourth dashboard.** You have three. Adding a fourth fragments operator attention. The Operator's Seat lives *inside* `AureonDashboard`.
- **Refactor `useGlobalState`.** It's the single source of truth and the existing components are coupled to its shape. Touch only what's necessary to add the new panels.
- **Touch `cinema/`.** It's well-organized, separate purpose. Out of scope.
- **Replace shadcn primitives.** The `<Card>`, `<Tabs>`, `<Badge>` patterns work. The fix is tokens + composition, not framework swap.
- **Mock the WebSocket bridge.** The mock data lives in a single `useMockGlobalState` hook with the same shape as `useGlobalState`. One swap.

---

## 4. Concrete deliverable for the next PR

```
handoff/frontend/
├── AUDIT.md                                  # this file
├── components/
│   ├── KillSwitchPanel.tsx                   # ~250 lines
│   ├── RiskEnvelopePanel.tsx                 # ~180 lines
│   ├── DecisionsFeed.tsx                     # ~220 lines
│   └── README.md                             # drop-in instructions
├── hooks/
│   └── useMockOperatorState.ts               # fake-data hook for review
└── preview/
    └── operator-seat.html                    # static composed preview
```

Engineer's drop-in step:

```bash
mkdir -p frontend/src/components/operator
cp handoff/frontend/components/*.tsx frontend/src/components/operator/
cp handoff/frontend/hooks/useMockOperatorState.ts frontend/src/hooks/
# Then in AureonDashboard.tsx → overview tab, add three imports + JSX.
```

Each component:
- Reads from `useGlobalState` by default
- Falls back to `useMockOperatorState` if `import.meta.env.VITE_OPERATOR_MOCK === 'true'`
- Uses shadcn primitives (`<Card>`, `<Button>`, `<Dialog>`, `<Input>`)
- Matches AUREON tokens for the panels themselves (gold borders, mono digits, serif heads)

---

## 5. Sign-off

Reply with one of:

- **"Go change 1"** — I build `KillSwitchPanel` only, ship for review.
- **"Go all three"** — I build 1+2+3 in one batch.
- **"Go all four"** — adds the styling pass.
- **"Different scope"** — tell me what.

Building anything before sign-off would be the fourth-dashboard mistake. Holding here.
