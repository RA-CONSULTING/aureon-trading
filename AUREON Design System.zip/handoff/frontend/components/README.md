# Operator Seat — drop-in components

Three TSX components that fill the gaps in `AureonDashboard`: the kill switch, the risk envelope, and the decisions feed. See `../AUDIT.md` for why these and not others.

---

## Files

| File | Lines | Purpose |
|---|---:|---|
| `KillSwitchPanel.tsx` | ~430 | Two-step FLATTEN ALL — modal review → type "FLATTEN" → execute with live progress |
| `RiskEnvelopePanel.tsx` | ~280 | Daily P&L vs cap, exposure vs cap, per-trade sizing, throttle state |
| `DecisionsFeed.tsx` | ~310 | Streaming log of bot decisions with filters, pause, auto-scroll |
| `../hooks/useMockOperatorState.ts` | ~390 | Fake-data hook with the same shape engineer must implement for real data |

---

## Drop-in (engineer)

```bash
# 1. Copy components into the operator/ subfolder
mkdir -p frontend/src/components/operator
cp handoff/frontend/components/KillSwitchPanel.tsx \
   handoff/frontend/components/RiskEnvelopePanel.tsx \
   handoff/frontend/components/DecisionsFeed.tsx \
   frontend/src/components/operator/

# 2. Copy the mock hook (used until real wiring is in place)
cp handoff/frontend/hooks/useMockOperatorState.ts frontend/src/hooks/
```

Then in `frontend/src/components/AureonDashboard.tsx`, in the **Overview** tab:

```tsx
import { KillSwitchPanel }    from '@/components/operator/KillSwitchPanel';
import { RiskEnvelopePanel }  from '@/components/operator/RiskEnvelopePanel';
import { DecisionsFeed }      from '@/components/operator/DecisionsFeed';
import { useOperatorState }   from '@/hooks/useMockOperatorState'; // see §Wiring

// inside the overview tab, replace the lonely "LAST SIGNAL" card:
const operator = useOperatorState();

<div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
  <div className="lg:col-span-4">
    <RiskEnvelopePanel state={operator} />
  </div>
  <div className="lg:col-span-4">
    <KillSwitchPanel
      state={operator}
      onFlatten={async () => {
        const r = await fetch('/api/risk/flatten', { method: 'POST' });
        return r.ok;
      }}
    />
  </div>
  <div className="lg:col-span-4 lg:row-span-2">
    <DecisionsFeed state={operator} />
  </div>
</div>
```

---

## Wiring — mock vs real

Each component reads `OperatorState` from `useMockOperatorState.ts`. The mock exports `useOperatorState` as the hook name, so swapping is a one-line change in your import path.

**Real wiring** — engineer implements `useOperatorState()` against `useGlobalState`:

```ts
// frontend/src/hooks/useOperatorState.ts (real)
import { useGlobalState } from './useGlobalState';
import type { OperatorState } from './useMockOperatorState';

export function useOperatorState(): OperatorState {
  const g = useGlobalState();
  return {
    positions: g.openPositions.map(p => ({ /* map to Position */ })),
    risk:      { /* derive from g */ },
    decisions: g.decisionsLog ?? [],
    flatten:   { state: g.flattenState ?? 'idle', progress: g.flattenProgress },
  };
}
```

The `OperatorState` type is the contract. Match its shape and the components work — no changes to TSX needed.

**Mock by default** — until the real hook lands, the components use `useMockOperatorState`. The mock simulates new decisions every 4–8s, drifting risk values, and a 10-position book.

---

## API contract — what the backend must expose

Two endpoints. Both POST, both auth-gated.

### `POST /api/risk/flatten`

Closes every open position across every exchange, halts the trading flag, returns when all orders are acked or 30s pass.

```jsonc
// Request
{ "confirm": "FLATTEN" }

// Response (200)
{
  "ok": true,
  "closed": [
    { "exchange": "BINANCE", "symbol": "ETHUSDT", "qty": 0.012, "fillPrice": 3247.10 }
  ],
  "failed": [],
  "haltedAt": 1733254800
}
```

`KillSwitchPanel` polls `state.flatten.progress` while waiting — engineer should push progress events via the global state so the modal shows them live.

### Decisions feed source

Components consume `state.decisions: Decision[]`. The list is append-only from the operator's perspective — engineer pushes new entries to global state. Schema:

```ts
{
  id: string;            // unique
  timestamp: number;     // unix seconds
  exchange: 'BINANCE' | 'KRAKEN' | 'ALPACA' | 'CAPITAL';
  side: 'BUY' | 'SELL' | 'FLAT';
  symbol: string;
  quantity: number;
  price: number;
  notional?: number;
  feeUsd?: number;
  status: 'executed' | 'rejected' | 'pending';
  signalSource: string;        // e.g. "Lighthouse · Mycelium"
  lambda: number;              // 0..1
  dominantArchetype: string;   // one of the 9
  riskVerdict: string;         // human-readable
  reasoningTrail: string[];    // 1-3 lines of why
}
```

---

## Design tokens used

The components use shadcn primitives + your existing tokens — no new CSS. They will inherit your dashboard's theme.

If you later want the AUREON gold/black aesthetic (proposal §4), restyle in your `tailwind.config.ts` and the components follow automatically.

---

## What these components don't do

- **Don't** call the real backend. They invoke `props.onFlatten` (kill switch) and read `state.decisions` (feed). Wiring lives elsewhere.
- **Don't** manage authentication. `AureonDashboard` already gates on `isAuthenticated`.
- **Don't** persist filter/pause state across reloads. Add `localStorage` if you want it; we kept the components stateless beyond their own UI.
- **Don't** support keyboard shortcuts on the kill switch. The two-step pattern is mouse-only by design — accidental keystrokes shouldn't get within two clicks of `/api/risk/flatten`.

---

## Preview

A static HTML preview composing all three is at `preview/operator-seat.html` — open it in the design review pane to see the full operator surface without running the frontend.
