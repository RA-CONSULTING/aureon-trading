/**
 * DecisionsFeed
 *
 * Streaming log of what the bots actually did and why. Replaces the lonely
 * "Last Signal" card on the AureonDashboard overview tab.
 *
 * Each entry shows:
 *   - timestamp · exchange · side · symbol · qty · price
 *   - signal source(s) with Λ + Auris dominant archetype
 *   - risk verdict (sized / capped / rejected) with reason
 *
 * Behaviors:
 *   - Auto-scrolls to newest unless user has scrolled up; then sticks
 *   - Filter pills: exchange, side, status (executed / rejected / pending)
 *   - Pause toggle (button), jump-to-now button when paused or scrolled
 *   - Click an entry to expand the full reasoning trail
 *
 * Pure presentational — reads OperatorState.decisions only.
 */

import { useEffect, useMemo, useRef, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ArrowDown, Filter, Pause, Play, Radio } from 'lucide-react';
import { cn } from '@/lib/utils';

import type { OperatorState, Decision } from '@/hooks/useMockOperatorState';

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

function fmtTime(ts: number) {
  const d = new Date(ts * 1000);
  return d.toLocaleTimeString(undefined, { hour12: false });
}

function fmtNum(n: number, digits = 2) {
  return n.toLocaleString(undefined, {
    minimumFractionDigits: digits, maximumFractionDigits: digits,
  });
}

const SIDE_TONE: Record<Decision['side'], string> = {
  BUY:  'text-success border-success/40 bg-success/5',
  SELL: 'text-destructive border-destructive/40 bg-destructive/5',
  FLAT: 'text-muted-foreground border-border bg-muted/40',
};

const STATUS_TONE: Record<Decision['status'], string> = {
  executed: 'text-success',
  rejected: 'text-destructive',
  pending:  'text-amber-500 animate-pulse',
};

// ─────────────────────────────────────────────────────────────────────────────
// Filter pill row
// ─────────────────────────────────────────────────────────────────────────────

type SideFilter = 'all' | 'BUY' | 'SELL';
type StatusFilter = 'all' | Decision['status'];

function FilterPill({
  active, label, onClick,
}: { active: boolean; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'h-6 px-2.5 rounded-full text-[10px] tracking-[0.12em] uppercase font-medium transition-colors',
        'border',
        active
          ? 'bg-primary text-primary-foreground border-primary'
          : 'bg-transparent text-muted-foreground border-border hover:text-foreground hover:border-foreground/40',
      )}
    >
      {label}
    </button>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Single entry
// ─────────────────────────────────────────────────────────────────────────────

function DecisionEntry({
  d, expanded, onToggle,
}: { d: Decision; expanded: boolean; onToggle: () => void }) {
  return (
    <div
      className={cn(
        'group rounded-md border px-3 py-2 transition-colors cursor-pointer',
        'hover:bg-muted/40',
        expanded ? 'bg-muted/40' : 'bg-transparent',
        'border-border/60',
      )}
      onClick={onToggle}
      role="button"
      aria-expanded={expanded}
    >
      {/* Top row */}
      <div className="flex items-center gap-3 text-xs">
        <span className="font-mono tabular-nums text-muted-foreground">
          {fmtTime(d.timestamp)}
        </span>
        <span className="font-mono text-[10px] tracking-[0.12em] uppercase text-muted-foreground w-16">
          {d.exchange}
        </span>
        <Badge
          variant="outline"
          className={cn('text-[10px] font-semibold tracking-[0.12em] px-1.5 py-0', SIDE_TONE[d.side])}
        >
          {d.side}
        </Badge>
        <span className="font-mono font-semibold flex-1 truncate">
          {d.symbol}
        </span>
        <span className="font-mono tabular-nums text-muted-foreground">
          {fmtNum(d.quantity, d.quantity < 1 ? 4 : 2)}
        </span>
        <span className="font-mono tabular-nums">
          @ {fmtNum(d.price, d.price < 10 ? 4 : 2)}
        </span>
        <span className={cn('text-[10px] uppercase tracking-[0.12em] font-semibold w-16 text-right', STATUS_TONE[d.status])}>
          {d.status}
        </span>
      </div>

      {/* Reason summary */}
      <div className="mt-1 pl-[5.25rem] text-[11px] text-muted-foreground font-mono truncate">
        ⬑ {d.signalSource} · Λ={fmtNum(d.lambda, 2)} · {d.dominantArchetype}
      </div>

      {/* Expanded body */}
      {expanded && (
        <div className="mt-2 pl-[5.25rem] space-y-1.5 text-[11px] font-mono text-muted-foreground">
          <div>
            <span className="text-foreground/80">risk:</span> {d.riskVerdict}
          </div>
          {d.reasoningTrail.map((line, i) => (
            <div key={i} className="opacity-90">
              <span className="text-foreground/60">{i === 0 ? '→' : '·'}</span> {line}
            </div>
          ))}
          {d.notional && (
            <div className="text-foreground/70">
              notional ${fmtNum(d.notional, 2)}
              {d.feeUsd != null && ` · fee $${fmtNum(d.feeUsd, 2)}`}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Main panel
// ─────────────────────────────────────────────────────────────────────────────

export interface DecisionsFeedProps {
  state: OperatorState;
  /** Max entries kept in DOM. Default 100. */
  maxEntries?: number;
  className?: string;
}

export function DecisionsFeed({
  state, maxEntries = 100, className,
}: DecisionsFeedProps) {
  const [paused, setPaused] = useState(false);
  const [sideFilter, setSideFilter] = useState<SideFilter>('all');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [exchangeFilter, setExchangeFilter] = useState<string>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const scrollerRef = useRef<HTMLDivElement | null>(null);
  const stickToBottomRef = useRef(true);

  // Available exchange list, derived
  const exchanges = useMemo(() => {
    const s = new Set<string>();
    for (const d of state.decisions) s.add(d.exchange);
    return ['all', ...Array.from(s).sort()];
  }, [state.decisions]);

  // Filtered + capped
  const filtered = useMemo(() => {
    let list = state.decisions;
    if (sideFilter !== 'all')     list = list.filter(d => d.side === sideFilter);
    if (statusFilter !== 'all')   list = list.filter(d => d.status === statusFilter);
    if (exchangeFilter !== 'all') list = list.filter(d => d.exchange === exchangeFilter);
    // Show oldest→newest top-to-bottom so auto-scroll-to-bottom = newest
    return list.slice(-maxEntries);
  }, [state.decisions, sideFilter, statusFilter, exchangeFilter, maxEntries]);

  // Detect manual scroll-up to disable stick-to-bottom
  useEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;
    const onScroll = () => {
      const distFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
      stickToBottomRef.current = distFromBottom < 40;
    };
    el.addEventListener('scroll', onScroll, { passive: true });
    return () => el.removeEventListener('scroll', onScroll);
  }, []);

  // Auto-scroll to bottom on new decisions, unless paused or user scrolled up
  useEffect(() => {
    if (paused) return;
    if (!stickToBottomRef.current) return;
    const el = scrollerRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [filtered.length, paused]);

  const jumpToNow = () => {
    const el = scrollerRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
    stickToBottomRef.current = true;
    setPaused(false);
  };

  const showJumpToNow = paused || !stickToBottomRef.current;

  return (
    <Card className={cn('border-border/60 flex flex-col', className)}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <CardTitle className="text-xs font-medium text-muted-foreground tracking-[0.16em] uppercase flex items-center gap-2">
            <Radio className={cn('h-3 w-3', !paused && 'text-success animate-pulse')} />
            Decisions Feed
            <span className="font-mono normal-case tracking-normal text-[10px] opacity-60">
              {filtered.length}{state.decisions.length > maxEntries ? ` / ${state.decisions.length}` : ''}
            </span>
          </CardTitle>

          <div className="flex items-center gap-1.5">
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-6 px-2 text-[10px] tracking-[0.12em] uppercase gap-1"
              onClick={() => setPaused(p => !p)}
            >
              {paused ? <><Play className="h-3 w-3" /> Resume</> : <><Pause className="h-3 w-3" /> Pause</>}
            </Button>
          </div>
        </div>

        {/* Filter row */}
        <div className="mt-3 flex items-center gap-2 flex-wrap">
          <Filter className="h-3 w-3 text-muted-foreground" />
          <FilterPill active={sideFilter === 'all'}  label="All"  onClick={() => setSideFilter('all')} />
          <FilterPill active={sideFilter === 'BUY'}  label="Buy"  onClick={() => setSideFilter('BUY')} />
          <FilterPill active={sideFilter === 'SELL'} label="Sell" onClick={() => setSideFilter('SELL')} />
          <span className="w-px h-4 bg-border mx-1" />
          <FilterPill active={statusFilter === 'all'}      label="Any"      onClick={() => setStatusFilter('all')} />
          <FilterPill active={statusFilter === 'executed'} label="Executed" onClick={() => setStatusFilter('executed')} />
          <FilterPill active={statusFilter === 'rejected'} label="Rejected" onClick={() => setStatusFilter('rejected')} />
          <FilterPill active={statusFilter === 'pending'}  label="Pending"  onClick={() => setStatusFilter('pending')} />
          {exchanges.length > 2 && (
            <>
              <span className="w-px h-4 bg-border mx-1" />
              {exchanges.map(ex => (
                <FilterPill
                  key={ex}
                  active={exchangeFilter === ex}
                  label={ex === 'all' ? 'All exchanges' : ex}
                  onClick={() => setExchangeFilter(ex)}
                />
              ))}
            </>
          )}
        </div>
      </CardHeader>

      <CardContent className="relative p-0">
        <div
          ref={scrollerRef}
          className="max-h-[420px] overflow-y-auto px-4 pb-4 space-y-1"
          aria-live={paused ? 'off' : 'polite'}
        >
          {filtered.length === 0 ? (
            <div className="py-10 text-center text-xs text-muted-foreground font-mono">
              No decisions match the current filters.
            </div>
          ) : (
            filtered.map(d => (
              <DecisionEntry
                key={d.id}
                d={d}
                expanded={expandedId === d.id}
                onToggle={() => setExpandedId(id => id === d.id ? null : d.id)}
              />
            ))
          )}
        </div>

        {/* Jump-to-now button (floats over scroller) */}
        {showJumpToNow && filtered.length > 0 && (
          <button
            type="button"
            onClick={jumpToNow}
            className={cn(
              'absolute right-4 bottom-4',
              'h-8 px-3 rounded-full',
              'bg-primary text-primary-foreground',
              'text-[10px] tracking-[0.16em] uppercase font-semibold',
              'shadow-lg shadow-primary/20',
              'flex items-center gap-1.5',
              'hover:bg-primary/90 transition-colors',
            )}
          >
            <ArrowDown className="h-3 w-3" />
            Jump to now
          </button>
        )}
      </CardContent>
    </Card>
  );
}

export default DecisionsFeed;
