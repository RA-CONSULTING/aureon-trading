/**
 * KillSwitchPanel
 *
 * The operator's last-resort control. Two-step FLATTEN ALL with the
 * safety pattern documented in /RUNNING.md §8:
 *
 *   1. Click "FLATTEN ALL" → opens review modal showing every open
 *      position, total notional at risk, expected close cost.
 *   2. Type the literal word "FLATTEN" into the confirmation field.
 *      Confirm button stays disabled until input matches exactly.
 *   3. Click confirm → calls flattenAll(), shows real-time progress
 *      (positions remaining, errors), halts trading on success.
 *
 * Designed to be friction-RICH at the moment that matters and
 * friction-FREE the rest of the time. The panel itself is a single
 * card you can drop into AureonDashboard's overview tab.
 *
 * Props:
 *   - state: OperatorState — from useGlobalState OR useMockOperatorState
 *   - className?: string
 *
 * Tokens used (Tailwind config already exposes these via tailwind.config.ts):
 *   - destructive (red), border, muted-foreground, foreground
 *   - font-mono (Source Code Pro), font-serif (Source Serif Pro)
 */

import { useEffect, useMemo, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Square, Loader2, CheckCircle2, XCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

import type { OperatorState, OpenPosition } from '@/hooks/useMockOperatorState';

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

const CONFIRM_PHRASE = 'FLATTEN';

function fmtUsd(n: number, opts: { signed?: boolean } = {}) {
  const v = `$${Math.abs(n).toLocaleString(undefined, {
    minimumFractionDigits: 2, maximumFractionDigits: 2,
  })}`;
  if (!opts.signed) return v;
  return n >= 0 ? `+${v}` : `−${v}`;
}

function fmtAge(s: number) {
  if (s < 60) return `${s}s`;
  if (s < 3600) return `${Math.floor(s / 60)}m`;
  return `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m`;
}

const EXCHANGE_LABEL: Record<string, string> = {
  binance: 'BINANCE',
  kraken: 'KRAKEN',
  alpaca: 'ALPACA',
  capital: 'CAPITAL',
};

// ─────────────────────────────────────────────────────────────────────────────
// Position row inside the review modal
// ─────────────────────────────────────────────────────────────────────────────

function PositionRow({ p }: { p: OpenPosition }) {
  const pnlPositive = p.unrealizedPnl >= 0;
  return (
    <div className="grid grid-cols-[80px_1fr_70px_110px_90px_70px] items-center gap-3 py-2 border-b border-border/40 last:border-0 text-sm">
      <Badge variant="outline" className="font-mono text-[10px] tracking-wider justify-center">
        {EXCHANGE_LABEL[p.exchange] || p.exchange.toUpperCase()}
      </Badge>
      <span className="font-mono font-semibold tabular-nums truncate">{p.symbol}</span>
      <Badge
        variant={p.side === 'BUY' ? 'default' : 'secondary'}
        className="text-[10px] tracking-wider justify-center"
      >
        {p.side}
      </Badge>
      <span className="font-mono tabular-nums text-right">{fmtUsd(p.notionalUsd)}</span>
      <span className={cn(
        'font-mono tabular-nums text-right',
        pnlPositive ? 'text-success' : 'text-destructive',
      )}>
        {fmtUsd(p.unrealizedPnl, { signed: true })}
      </span>
      <span className="font-mono text-xs text-muted-foreground text-right">
        {fmtAge(p.ageSeconds)}
      </span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Main panel
// ─────────────────────────────────────────────────────────────────────────────

export interface KillSwitchPanelProps {
  state: OperatorState;
  className?: string;
}

export function KillSwitchPanel({ state, className }: KillSwitchPanelProps) {
  const { openPositions, isActive, isFlattening, flattenAll } = state;

  // Modal lifecycle
  type Phase = 'closed' | 'review' | 'confirming' | 'in-progress' | 'done';
  const [phase, setPhase] = useState<Phase>('closed');
  const [confirmInput, setConfirmInput] = useState('');
  const [result, setResult] = useState<{ closed: number; failed: number } | null>(null);

  // Reset confirm input when modal re-opens
  useEffect(() => {
    if (phase === 'closed') {
      setConfirmInput('');
      setResult(null);
    }
  }, [phase]);

  // Track in-progress phase live
  useEffect(() => {
    if (isFlattening && phase !== 'in-progress') setPhase('in-progress');
  }, [isFlattening, phase]);

  // Aggregates for the review screen
  const totals = useMemo(() => {
    const notional = openPositions.reduce((s, p) => s + p.notionalUsd, 0);
    const pnl = openPositions.reduce((s, p) => s + p.unrealizedPnl, 0);
    const byExchange = openPositions.reduce<Record<string, number>>((acc, p) => {
      acc[p.exchange] = (acc[p.exchange] ?? 0) + 1;
      return acc;
    }, {});
    return { notional, pnl, byExchange, count: openPositions.length };
  }, [openPositions]);

  const confirmReady = confirmInput.trim().toUpperCase() === CONFIRM_PHRASE;
  const hasPositions = totals.count > 0;

  const onClickFlatten = () => {
    setPhase('review');
  };

  const onClickConfirm = async () => {
    if (!confirmReady) return;
    setPhase('confirming');
    const r = await flattenAll();
    setResult(r);
    setPhase('done');
  };

  const onClose = () => {
    if (phase === 'in-progress' || phase === 'confirming') return; // can't close mid-flatten
    setPhase('closed');
  };

  // ──────────────────────────────────────────────────────────────────────────
  // Render
  // ──────────────────────────────────────────────────────────────────────────

  return (
    <>
      <Card
        className={cn(
          'border-destructive/40 bg-gradient-to-b from-destructive/5 to-transparent',
          className,
        )}
      >
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-xs font-medium text-muted-foreground tracking-[0.16em] uppercase flex items-center gap-2">
              <AlertTriangle className="h-3 w-3 text-destructive" />
              Kill Switch
            </CardTitle>
            <Badge
              variant={isActive ? 'default' : 'outline'}
              className="text-[10px] tracking-wider"
            >
              {isActive ? 'ARMED' : 'HALTED'}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-3 gap-3 pb-2">
            <Stat label="Open" value={totals.count.toString()} />
            <Stat label="Notional" value={fmtUsd(totals.notional)} />
            <Stat
              label="Unrealized"
              value={fmtUsd(totals.pnl, { signed: true })}
              tone={totals.pnl >= 0 ? 'success' : 'destructive'}
            />
          </div>

          <Button
            onClick={onClickFlatten}
            disabled={!hasPositions || isFlattening}
            variant="destructive"
            size="lg"
            className="w-full font-mono tracking-[0.16em] text-sm font-semibold"
          >
            {isFlattening ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                FLATTENING…
              </>
            ) : (
              <>
                <Square className="h-4 w-4 mr-2" />
                FLATTEN ALL
              </>
            )}
          </Button>

          {!hasPositions && (
            <p className="text-xs text-muted-foreground text-center">
              No open positions. Nothing to flatten.
            </p>
          )}
        </CardContent>
      </Card>

      <Dialog open={phase !== 'closed'} onOpenChange={onClose}>
        <DialogContent className="max-w-2xl border-destructive/30">
          {(phase === 'review' || phase === 'confirming') && (
            <ReviewStep
              positions={openPositions}
              totals={totals}
              confirmInput={confirmInput}
              setConfirmInput={setConfirmInput}
              confirmReady={confirmReady}
              busy={phase === 'confirming'}
              onConfirm={onClickConfirm}
              onCancel={onClose}
            />
          )}

          {phase === 'in-progress' && (
            <ProgressStep
              remaining={openPositions.length}
              total={totals.count + (result?.closed ?? 0)}
            />
          )}

          {phase === 'done' && result && (
            <DoneStep
              closed={result.closed}
              failed={result.failed}
              onDismiss={() => setPhase('closed')}
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Subcomponents
// ─────────────────────────────────────────────────────────────────────────────

function Stat({
  label, value, tone,
}: {
  label: string;
  value: string;
  tone?: 'success' | 'destructive';
}) {
  return (
    <div>
      <div className="text-[10px] text-muted-foreground uppercase tracking-wider">
        {label}
      </div>
      <div className={cn(
        'font-mono font-semibold tabular-nums text-sm mt-0.5',
        tone === 'success' && 'text-success',
        tone === 'destructive' && 'text-destructive',
      )}>
        {value}
      </div>
    </div>
  );
}

function ReviewStep({
  positions, totals, confirmInput, setConfirmInput, confirmReady, busy,
  onConfirm, onCancel,
}: {
  positions: OpenPosition[];
  totals: { count: number; notional: number; pnl: number; byExchange: Record<string, number> };
  confirmInput: string;
  setConfirmInput: (v: string) => void;
  confirmReady: boolean;
  busy: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <>
      <DialogHeader>
        <DialogTitle className="font-serif text-2xl flex items-center gap-3">
          <AlertTriangle className="h-6 w-6 text-destructive" />
          Flatten all positions
        </DialogTitle>
        <DialogDescription className="text-sm leading-relaxed">
          You are about to close <b className="text-foreground">{totals.count}</b>{' '}
          {totals.count === 1 ? 'position' : 'positions'} across{' '}
          <b className="text-foreground">{Object.keys(totals.byExchange).length}</b>{' '}
          {Object.keys(totals.byExchange).length === 1 ? 'venue' : 'venues'} and halt all trading.
          This action is <b className="text-destructive">irreversible</b>.
        </DialogDescription>
      </DialogHeader>

      {/* Position list */}
      <div className="border border-border/60 rounded-md overflow-hidden">
        <div className="grid grid-cols-[80px_1fr_70px_110px_90px_70px] gap-3 px-3 py-2 bg-muted/40 text-[10px] uppercase tracking-wider text-muted-foreground font-mono">
          <span>Venue</span>
          <span>Symbol</span>
          <span className="text-center">Side</span>
          <span className="text-right">Notional</span>
          <span className="text-right">Unrealized</span>
          <span className="text-right">Age</span>
        </div>
        <div className="px-3 max-h-[260px] overflow-y-auto">
          {positions.map(p => (
            <PositionRow key={p.id} p={p} />
          ))}
        </div>
      </div>

      {/* Aggregate strip */}
      <div className="grid grid-cols-3 gap-4 py-3 border-y border-border/40 text-sm">
        <div>
          <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Total notional</div>
          <div className="font-mono font-semibold tabular-nums">{fmtUsd(totals.notional)}</div>
        </div>
        <div>
          <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Net unrealized</div>
          <div className={cn(
            'font-mono font-semibold tabular-nums',
            totals.pnl >= 0 ? 'text-success' : 'text-destructive',
          )}>
            {fmtUsd(totals.pnl, { signed: true })}
          </div>
        </div>
        <div>
          <div className="text-[10px] text-muted-foreground uppercase tracking-wider">After flatten</div>
          <div className="font-mono font-semibold tabular-nums">FLAT · HALTED</div>
        </div>
      </div>

      {/* Confirmation */}
      <div className="space-y-2">
        <label className="text-xs text-muted-foreground">
          Type <code className="font-mono font-semibold text-foreground bg-muted px-1.5 py-0.5 rounded">
            {CONFIRM_PHRASE}
          </code> to confirm.
        </label>
        <Input
          value={confirmInput}
          onChange={e => setConfirmInput(e.target.value)}
          placeholder=""
          autoFocus
          disabled={busy}
          className={cn(
            'font-mono uppercase tracking-[0.2em] text-base h-11',
            confirmReady && 'border-destructive ring-1 ring-destructive/40',
          )}
          aria-label={`Type ${CONFIRM_PHRASE} to confirm`}
        />
      </div>

      <DialogFooter>
        <Button variant="outline" onClick={onCancel} disabled={busy}>
          Cancel
        </Button>
        <Button
          variant="destructive"
          onClick={onConfirm}
          disabled={!confirmReady || busy}
          className="font-mono tracking-[0.16em] font-semibold"
        >
          {busy ? (
            <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> EXECUTING…</>
          ) : (
            <><Square className="h-4 w-4 mr-2" /> CONFIRM FLATTEN</>
          )}
        </Button>
      </DialogFooter>
    </>
  );
}

function ProgressStep({ remaining, total }: { remaining: number; total: number }) {
  const closed = total - remaining;
  const pct = total === 0 ? 100 : (closed / total) * 100;
  return (
    <>
      <DialogHeader>
        <DialogTitle className="font-serif text-2xl flex items-center gap-3">
          <Loader2 className="h-6 w-6 text-destructive animate-spin" />
          Flattening positions
        </DialogTitle>
        <DialogDescription>
          Closing {total} {total === 1 ? 'position' : 'positions'}. Do not refresh.
        </DialogDescription>
      </DialogHeader>

      <div className="py-6 space-y-4">
        <div className="flex justify-between items-baseline">
          <span className="font-mono text-sm text-muted-foreground tracking-wider">PROGRESS</span>
          <span className="font-mono text-2xl font-semibold tabular-nums">
            {closed}<span className="text-muted-foreground">/{total}</span>
          </span>
        </div>
        <div className="h-2 rounded-full bg-muted overflow-hidden">
          <div
            className="h-full bg-destructive transition-all duration-300"
            style={{ width: `${pct}%` }}
            role="progressbar"
            aria-valuenow={closed}
            aria-valuemin={0}
            aria-valuemax={total}
          />
        </div>
        <div className="text-xs text-muted-foreground font-mono text-center">
          {remaining > 0 ? `${remaining} remaining` : 'Finalizing…'}
        </div>
      </div>
    </>
  );
}

function DoneStep({
  closed, failed, onDismiss,
}: {
  closed: number;
  failed: number;
  onDismiss: () => void;
}) {
  const allOk = failed === 0;
  return (
    <>
      <DialogHeader>
        <DialogTitle className="font-serif text-2xl flex items-center gap-3">
          {allOk ? (
            <CheckCircle2 className="h-6 w-6 text-success" />
          ) : (
            <XCircle className="h-6 w-6 text-destructive" />
          )}
          {allOk ? 'Flat. Halted.' : 'Flatten incomplete'}
        </DialogTitle>
        <DialogDescription>
          {allOk
            ? `All ${closed} positions closed. Trading is halted until you resume manually.`
            : `${closed} closed, ${failed} failed. Investigate before resuming.`}
        </DialogDescription>
      </DialogHeader>

      <div className="grid grid-cols-2 gap-4 py-4">
        <div>
          <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Closed</div>
          <div className="font-mono font-semibold text-success text-2xl tabular-nums">{closed}</div>
        </div>
        <div>
          <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Failed</div>
          <div className={cn(
            'font-mono font-semibold text-2xl tabular-nums',
            failed === 0 ? 'text-muted-foreground' : 'text-destructive',
          )}>
            {failed}
          </div>
        </div>
      </div>

      <DialogFooter>
        <Button onClick={onDismiss} className="font-mono tracking-[0.16em]">
          DISMISS
        </Button>
      </DialogFooter>
    </>
  );
}

export default KillSwitchPanel;
