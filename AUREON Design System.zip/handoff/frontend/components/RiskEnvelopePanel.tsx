/**
 * RiskEnvelopePanel
 *
 * Surfaces the runtime risk state that's currently invisible in
 * AureonDashboard. Mirrors the BINANCE_RISK_* env vars from .env.example
 * and the risk-manager state from the runbook (RUNNING.md §3D, §7).
 *
 * Five sections, top→bottom by urgency:
 *   1. Daily P&L vs daily-loss cap (progress bar; cap line)
 *   2. Open exposure vs exposure cap
 *   3. Per-trade sizing — riskFraction · maxOrderUsd · lastOrderUsd
 *   4. Throttle state — normal / cooling / paused with reason
 *   5. Heartbeat — seconds since last trade
 *
 * Tones:
 *   - normal           → muted
 *   - warn (>= 60%)    → amber
 *   - critical (>= 80%)→ destructive
 *   - paused           → destructive
 *
 * Pure presentational — reads OperatorState.risk only. No actions.
 */

import { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Activity, Clock, Gauge, ShieldAlert, Zap } from 'lucide-react';
import { cn } from '@/lib/utils';

import type { OperatorState, RiskState } from '@/hooks/useMockOperatorState';

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

function fmtUsd(n: number, opts: { signed?: boolean } = {}) {
  const v = `$${Math.abs(n).toLocaleString(undefined, {
    minimumFractionDigits: 2, maximumFractionDigits: 2,
  })}`;
  if (!opts.signed) return v;
  return n >= 0 ? `+${v}` : `−${v}`;
}

function fmtPct(p: number, digits = 0) {
  return `${(p * 100).toFixed(digits)}%`;
}

function fmtDuration(s: number) {
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ${s % 60}s`;
  const h = Math.floor(m / 60);
  return `${h}h ${m % 60}m`;
}

// 0..1 → 'normal' | 'warn' | 'critical'
function pctTone(p: number): 'normal' | 'warn' | 'critical' {
  if (p >= 0.8) return 'critical';
  if (p >= 0.6) return 'warn';
  return 'normal';
}

const TONE_BAR: Record<'normal' | 'warn' | 'critical', string> = {
  normal: 'bg-foreground/60',
  warn: 'bg-amber-500',
  critical: 'bg-destructive',
};

const TONE_TEXT: Record<'normal' | 'warn' | 'critical', string> = {
  normal: 'text-foreground',
  warn: 'text-amber-500',
  critical: 'text-destructive',
};

// ─────────────────────────────────────────────────────────────────────────────
// Throttle pill
// ─────────────────────────────────────────────────────────────────────────────

function ThrottlePill({ state }: { state: RiskState['throttleState'] }) {
  const cfg = {
    normal:  { label: 'NORMAL',  variant: 'outline' as const,     dot: 'bg-success' },
    cooling: { label: 'COOLING', variant: 'secondary' as const,   dot: 'bg-amber-500 animate-pulse' },
    paused:  { label: 'PAUSED',  variant: 'destructive' as const, dot: 'bg-destructive animate-pulse' },
  }[state];
  return (
    <Badge variant={cfg.variant} className="text-[10px] tracking-[0.16em] gap-1.5">
      <span className={cn('h-1.5 w-1.5 rounded-full', cfg.dot)} />
      {cfg.label}
    </Badge>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Capped bar — value vs cap with right-aligned cap line
// ─────────────────────────────────────────────────────────────────────────────

function CapBar({
  pct, tone, ariaLabel,
}: {
  pct: number;
  tone: 'normal' | 'warn' | 'critical';
  ariaLabel: string;
}) {
  const clamped = Math.max(0, Math.min(1, pct));
  return (
    <div
      className="relative h-2 rounded-full bg-muted overflow-hidden"
      role="progressbar"
      aria-label={ariaLabel}
      aria-valuenow={Math.round(clamped * 100)}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <div
        className={cn('h-full transition-all duration-500', TONE_BAR[tone])}
        style={{ width: `${clamped * 100}%` }}
      />
      {/* 80% threshold tick */}
      <div
        className="absolute top-0 bottom-0 w-px bg-foreground/40"
        style={{ left: '80%' }}
        aria-hidden
      />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Section row
// ─────────────────────────────────────────────────────────────────────────────

function Section({
  icon: Icon, label, value, sub, children,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
  sub?: React.ReactNode;
  children?: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
          <Icon className="h-3 w-3" />
          {label}
        </div>
        <div className="font-mono text-sm font-semibold tabular-nums">{value}</div>
      </div>
      {children}
      {sub && (
        <div className="text-[11px] text-muted-foreground font-mono flex justify-between">
          {sub}
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Main panel
// ─────────────────────────────────────────────────────────────────────────────

export interface RiskEnvelopePanelProps {
  state: OperatorState;
  className?: string;
}

export function RiskEnvelopePanel({ state, className }: RiskEnvelopePanelProps) {
  const { risk } = state;

  const lossPctTone = pctTone(risk.dailyPnlPctOfCap);
  const exposurePctTone = pctTone(risk.exposurePctOfCap);

  // Per-trade utilization — last order vs cap
  const lastOrderPct = risk.maxOrderUsd > 0
    ? risk.lastOrderUsd / risk.maxOrderUsd
    : 0;

  // Outermost panel tone reflects worst-of
  const overallTone = useMemo<'normal' | 'warn' | 'critical' | 'paused'>(() => {
    if (risk.throttleState === 'paused') return 'paused';
    const a = pctTone(risk.dailyPnlPctOfCap);
    const b = pctTone(risk.exposurePctOfCap);
    if (a === 'critical' || b === 'critical') return 'critical';
    if (a === 'warn' || b === 'warn' || risk.throttleState === 'cooling') return 'warn';
    return 'normal';
  }, [risk]);

  const borderClass = {
    normal: 'border-border/60',
    warn: 'border-amber-500/40',
    critical: 'border-destructive/50',
    paused: 'border-destructive/70',
  }[overallTone];

  return (
    <Card className={cn(borderClass, className)}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xs font-medium text-muted-foreground tracking-[0.16em] uppercase flex items-center gap-2">
            <ShieldAlert className="h-3 w-3" />
            Risk Envelope
          </CardTitle>
          <ThrottlePill state={risk.throttleState} />
        </div>
      </CardHeader>

      <CardContent className="space-y-5">

        {/* 1. Daily P&L vs cap */}
        <Section
          icon={Activity}
          label="Daily P&L vs cap"
          value={fmtUsd(risk.dailyPnlUsd, { signed: true })}
        >
          <CapBar
            pct={risk.dailyPnlPctOfCap}
            tone={lossPctTone}
            ariaLabel="Daily loss vs cap"
          />
          <div className="text-[11px] text-muted-foreground font-mono flex justify-between">
            <span>cap {fmtUsd(risk.dailyLossCapUsd)}</span>
            <span className={TONE_TEXT[lossPctTone]}>
              {fmtPct(risk.dailyPnlPctOfCap, 0)} used
            </span>
          </div>
        </Section>

        {/* 2. Exposure vs cap */}
        <Section
          icon={Gauge}
          label="Open exposure"
          value={fmtUsd(risk.totalExposureUsd)}
        >
          <CapBar
            pct={risk.exposurePctOfCap}
            tone={exposurePctTone}
            ariaLabel="Open exposure vs cap"
          />
          <div className="text-[11px] text-muted-foreground font-mono flex justify-between">
            <span>cap {fmtUsd(risk.exposureCapUsd)}</span>
            <span className={TONE_TEXT[exposurePctTone]}>
              {fmtPct(risk.exposurePctOfCap, 0)} used
            </span>
          </div>
        </Section>

        {/* 3. Per-trade sizing */}
        <Section
          icon={Zap}
          label="Per-trade sizing"
          value={fmtUsd(risk.lastOrderUsd)}
        >
          <CapBar
            pct={lastOrderPct}
            tone={pctTone(lastOrderPct)}
            ariaLabel="Last order vs max-per-order"
          />
          <div className="text-[11px] text-muted-foreground font-mono flex justify-between">
            <span>
              risk {fmtPct(risk.riskFraction, 1)} ·
              max {fmtUsd(risk.maxOrderUsd)}
            </span>
            <span>last {fmtUsd(risk.lastOrderUsd)}</span>
          </div>
        </Section>

        {/* 4. Throttle state — only shows extra info if not normal */}
        {risk.throttleState !== 'normal' && (
          <div className={cn(
            'rounded-md px-3 py-2.5 border text-xs font-mono',
            risk.throttleState === 'paused'
              ? 'border-destructive/40 bg-destructive/5 text-destructive'
              : 'border-amber-500/40 bg-amber-500/5 text-amber-500',
          )}>
            <div className="flex items-center justify-between gap-3">
              <span className="font-semibold tracking-wider uppercase">
                {risk.throttleState === 'paused' ? 'Trading paused' : 'Cooling'}
              </span>
              {risk.consecutiveLosses > 0 && (
                <span className="text-[10px] opacity-80">
                  {risk.consecutiveLosses} consecutive {risk.consecutiveLosses === 1 ? 'loss' : 'losses'}
                </span>
              )}
            </div>
            {risk.throttleReason && (
              <div className="mt-1 opacity-80">{risk.throttleReason}</div>
            )}
          </div>
        )}

        {/* 5. Heartbeat */}
        <div className="flex items-center justify-between pt-1 border-t border-border/40">
          <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
            <Clock className="h-3 w-3" />
            Last trade
          </div>
          <div className="font-mono text-xs tabular-nums text-muted-foreground">
            {fmtDuration(risk.secondsSinceLastTrade)} ago
          </div>
        </div>

      </CardContent>
    </Card>
  );
}

export default RiskEnvelopePanel;
