# Documentation Patches — Final, Ready-to-Commit

This file contains the exact edits to apply to the live `main` branch of `RA-CONSULTING/aureon-trading`. Every command, file path, and env var below has been verified against the repo at `main @ 686b6ea`.

**Apply order:** patches 1–3 fix broken commands. Patch 4 stubs the deprecated home-PC guide. Patch 5 fixes the DigitalOcean safety default.

**Files this PR touches:**

```
A  RUNNING.md                                    (new — copy from handoff/RUNNING.md)
M  README.md                                     (insert "How to run" block, fix line ~288)
M  docs/LIVE_TRADING_RUNBOOK.md                  (replace 3 commands)
M  docs/runbooks/SETUP_HOME_PC.md                (replace contents with deprecation stub)
M  app.yaml                                      (flip dry-run defaults to safe)
```

> **Note:** the original plan referenced a `QUICK_START.md` at repo root. **That file does not exist on `main`** — removed from this patch set.

---

## Patch 1 — `README.md`

### 1a. Insert a "How to run" block near the top of the file

**Place:** immediately after the `## 🧭 What is this?` section (just before `## 📊 GROWTH STATS`), insert:

```markdown
## 🚀 How to run this system

**See [`RUNNING.md`](RUNNING.md) for complete, current setup and run instructions.**

Quick paths:

- Test it (safe, no money): `python scripts/aureon_ignition.py`
- Boot all systems, no trades: `python scripts/aureon_ignition.py --no-trade`
- Live trade (real money): read [`RUNNING.md`](RUNNING.md) safety section **first**

Older guides reference scripts that no longer exist (`aureon_full_autonomy.py`,
`aureon_unified_ecosystem.py`, `aureon_live.py`, `npm run paper-trade`).
**Trust `RUNNING.md`.**

---
```

### 1b. Fix the broken beta-tester command (around line 288, in the "How to Become a Beta Tester" block)

```diff
 # 4. Run in dry-run mode — zero API keys required
-python aureon_full_autonomy.py --dry-run
+python scripts/aureon_ignition.py        # default = dry-run, see RUNNING.md
```

---

## Patch 2 — `docs/LIVE_TRADING_RUNBOOK.md`

This file currently uses three different `aureon_live.py --stage N` invocations. Replace them all.

### 2a. Stage 0 (around line 16)

```diff
-python aureon_live.py --stage 0 --symbol BTCUSDT --trades 1
+# Stage 0: dry-run on Binance testnet (no real orders, log-only)
+#   .env: BINANCE_USE_TESTNET=true, BINANCE_DRY_RUN=true
+python scripts/aureon_ignition.py --live
```

### 2b. Stage 1 (around line 38)

```diff
-# Switch to real testnet orders
-export BINANCE_DRY_RUN=false
-
-# Run Stage 1 (still on testnet)
-python aureon_live.py --stage 1 --symbol BTCUSDT --trades 3
+# Stage 1: real orders on Binance testnet
+#   .env: BINANCE_USE_TESTNET=true, BINANCE_DRY_RUN=false
+python scripts/aureon_ignition.py --live
```

### 2c. Stage 2 (around line 67)

```diff
-# Switch to mainnet
-export BINANCE_USE_TESTNET=false
-
-# Enable live confirmation
-export CONFIRM_LIVE=yes
-
-# Run Stage 2 with conservative trade count
-python aureon_live.py --stage 2 --symbol BTCUSDT --trades 1
+# Stage 2: live mainnet trading — REAL MONEY AT RISK
+#   .env: BINANCE_USE_TESTNET=false, BINANCE_DRY_RUN=false,
+#         CONFIRM_LIVE=yes, BINANCE_RISK_MAX_ORDER_USDT=25
+python scripts/aureon_ignition.py --live
```

### 2d. Add a banner at the top of the file (above `## ⚡ Quick Start`)

```markdown
> **Pre-requisite reading:** [`/RUNNING.md`](../RUNNING.md) sections 1–3.
> This runbook assumes you have already validated dry-run, --no-trade, and
> a paper/testnet session per RUNNING.md before reaching Stage 0 below.
```

---

## Patch 3 — *(removed)*

The original plan targeted `QUICK_START.md` — that file does not exist on `main`. No edit needed.

---

## Patch 4 — `docs/runbooks/SETUP_HOME_PC.md`

Replace the **entire contents** of this file with the stub below. The home-PC path is no longer separate — it's identical to the standard setup in `RUNNING.md`. Stub-and-redirect is cleaner than fixing inline (the existing file references `aureon_unified_ecosystem.py` and Codespaces secrets in three places).

**New file contents:**

```markdown
# DEPRECATED — see [`/RUNNING.md`](../../RUNNING.md)

The home-PC setup is no longer a separate code path. Follow `RUNNING.md`
sections 1–2 for setup; section 3 covers all run modes including 24/7
operation via tmux/systemd/launchd/Task Scheduler.

This file is kept as a stub so external links don't break. It will be
removed in a future cleanup.

## Quick redirect

| Old guidance here                                | Where it lives now                |
|---------------------------------------------------|-----------------------------------|
| `python3 aureon_unified_ecosystem.py`             | `python scripts/aureon_ignition.py` (RUNNING.md §3A) |
| Run 24/7 via tmux                                 | RUNNING.md §3 + your OS's service manager |
| Auto-start on boot (systemd/launchd/Task Sched.)  | Same recipes apply — just swap the script path to `scripts/aureon_ignition.py` |
```

---

## Patch 5 — `app.yaml` (DigitalOcean safety)

The current `app.yaml` boots every fresh DigitalOcean deploy into live trading. Flip the defaults to safe and force a deliberate flip.

```diff
+      # ─────────────────────────────────────────────────────────────
+      # ⚠  TRADING MODE — REAL MONEY IF FLIPPED TO LIVE
+      # Default ships SAFE: dry-run on every exchange.
+      # Flip to live ONLY after:
+      #   1. Local paper-trading validation per /RUNNING.md
+      #   2. Risk limits configured (BINANCE_RISK_MAX_ORDER_USDT etc.)
+      #   3. Operator dashboard kill switch tested
+      # ─────────────────────────────────────────────────────────────
       # Trading mode
       - key: LIVE
         scope: RUN_TIME
-        value: "1"
+        value: "0"
       - key: REAL_DATA_ONLY
         scope: RUN_TIME
         value: "1"
       - key: KRAKEN_DRY_RUN
         scope: RUN_TIME
-        value: "false"
+        value: "true"
       - key: BINANCE_DRY_RUN
         scope: RUN_TIME
-        value: "false"
+        value: "true"
       - key: ALPACA_DRY_RUN
         scope: RUN_TIME
-        value: "false"
+        value: "true"
```

---

## Verification — run on a fresh clone

```bash
git clone https://github.com/RA-CONSULTING/aureon-trading
cd aureon-trading
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env

# A: dry-run
python scripts/aureon_ignition.py
# Expected: banner → phase output → "IGNITION COMPLETE" within ~30s
# Ctrl+C

# B: full boot, no trade
python scripts/aureon_ignition.py --no-trade
# Expected: "Flight check: N/N GO" — every line should say GO
# Ctrl+C
```

If both succeed, the patches are correct. New users go from `git clone` → running paper trade in under 10 minutes.

---

## Commit message (suggested)

```
docs: single source of truth for run instructions; safe DO defaults

- Add RUNNING.md (root) — verified decision tree A–H, .env reference,
  stage 0/1/2 progression, common issues, kill paths.
- README.md: insert "How to run" block; fix beta-tester command
  (aureon_full_autonomy.py → scripts/aureon_ignition.py).
- docs/LIVE_TRADING_RUNBOOK.md: replace aureon_live.py --stage N
  invocations with scripts/aureon_ignition.py --live + env-var stages.
- docs/runbooks/SETUP_HOME_PC.md: stub + redirect to RUNNING.md.
- app.yaml: flip dry-run defaults to "true"; LIVE → "0".
  Cloud deploys no longer ship into live trading by default.

Closes the documentation gap that broke first-run UX.
```
