# RUNNING.md

**The single source of truth for booting the Aureon trading system.**

Other run guides in this repo are outdated. If a command in another doc disagrees with this file, **trust this file.**

Last verified against `scripts/aureon_ignition.py`, `.env.example`, `docs/LIVE_TRADING_RUNBOOK.md`, and `app.yaml` on `main @ 686b6ea`.

---

## ⚠️ Read this first — Money Safety

This system can place trades with **real money** on Binance, Kraken, Capital.com, and Alpaca.

**The progression is non-negotiable:**

1. **Dry-run** (default — no exchange calls) → confirms code paths boot
2. **Boot-only** (`--no-trade`) → confirms all 100+ subsystems wire up
3. **Paper / testnet** (Alpaca paper, Capital demo, Binance testnet) → real exchange API, fake money
4. **Live, capped** (small risk limits, real money) → *only* after the first three pass for 24h+

**Never skip a step.** If you don't understand a section, **do not run `--live`.** Ask first.

---

## 1. Prerequisites

- [ ] **Python 3.11+** — `python3 --version`
- [ ] **git**
- [ ] **4 GB RAM** minimum, 8 GB recommended
- [ ] **Disk:** 2 GB free
- [ ] *(optional)* **Docker** for production deployment
- [ ] **API keys** for exchanges you'll use:
  - Binance — https://www.binance.com/en/my/settings/api-management *(testnet: https://testnet.binance.vision/)*
  - Kraken — https://www.kraken.com/u/security/api
  - Alpaca — https://app.alpaca.markets/paper/dashboard/overview *(paper)* or live
  - Capital.com — Settings → API integrations

---

## 2. Setup (5 minutes)

```bash
git clone https://github.com/RA-CONSULTING/aureon-trading
cd aureon-trading

python3 -m venv .venv
source .venv/bin/activate          # Linux / macOS
# .venv\Scripts\activate            # Windows

pip install -r requirements.txt

cp .env.example .env
# Edit .env — fill in keys for the exchanges you'll use; leave others blank.
```

**The `.env` keys recognized today** (verified against `.env.example`):

```
BINANCE_API_KEY=
BINANCE_API_SECRET=
KRAKEN_API_KEY=
KRAKEN_API_SECRET=
ALPACA_API_KEY=
ALPACA_SECRET_KEY=
ALPACA_PAPER=false               # true = paper trading on Alpaca
CAPITAL_API_KEY=
CAPITAL_IDENTIFIER=
CAPITAL_PASSWORD=
CAPITAL_DEMO_MODE=false          # true = Capital.com demo account
COINAPI_KEY=                     # optional, cross-exchange history
```

**Additional flags read by the runtime** (verified against `LIVE_TRADING_RUNBOOK.md` and `app.yaml`):

```
# Trading mode
AUREON_LIVE_TRADING=1            # alternative to --live flag
LIVE=1                           # used by app.yaml / Docker
REAL_DATA_ONLY=1                 # disables synthetic feeds

# Per-exchange dry-run override
KRAKEN_DRY_RUN=true|false
BINANCE_DRY_RUN=true|false
ALPACA_DRY_RUN=true|false

# Binance-specific
BINANCE_USE_TESTNET=true         # route to https://testnet.binance.vision
BINANCE_RISK_FRACTION=0.02       # risk 2% of free quote per trade
BINANCE_RISK_MAX_ORDER_USDT=25   # cap each order at 25 USDT
CONFIRM_LIVE=yes                 # required for Stage 2 mainnet trading

# State
AUREON_STATE_DIR=/path/to/state
AUREON_REDIS_URL=redis://...     # optional thought bus
```

---

## 3. What do you want to do? — Decision tree

### A) Just verify the code runs *(no money, no exchange calls)*

```bash
python scripts/aureon_ignition.py
```

Default = dry-run. Use this to verify the boot sequence after a fresh clone or `pip install`.

You should see the banner, then phase output ending in:

```
================================================================================
  IGNITION COMPLETE
  Systems: NN/NN ONLINE
  Flight check: NN/NN GO
  Boot time: ~Xs
  Mode: DRY-RUN
================================================================================
```

`Ctrl+C` to stop.

---

### B) Boot every subsystem but don't run the trading loop

```bash
python scripts/aureon_ignition.py --no-trade
```

All ~100 subsystems initialize and hold. Heartbeat once a minute. Use this before a long session.

For live wiring without trades (exchange clients connect, no orders fire):

```bash
python scripts/aureon_ignition.py --live --no-trade
```

⚠️ This connects to exchanges with your keys. Only do this with paper / testnet keys until you've validated the full flow.

---

### C) Trade with **fake money on a real exchange** *(paper / testnet / demo)*

The recommended last step before going live.

**Alpaca paper** — edit `.env`:

```
ALPACA_API_KEY=<paper-key>
ALPACA_SECRET_KEY=<paper-secret>
ALPACA_PAPER=true
```

**Capital.com demo** — edit `.env`:

```
CAPITAL_API_KEY=<demo-key>
CAPITAL_IDENTIFIER=<demo-username>
CAPITAL_PASSWORD=<demo-password>
CAPITAL_DEMO_MODE=true
```

**Binance testnet** — get keys at https://testnet.binance.vision/:

```
BINANCE_API_KEY=<testnet-key>
BINANCE_API_SECRET=<testnet-secret>
BINANCE_USE_TESTNET=true
BINANCE_DRY_RUN=true             # Stage 0: log only, no real orders
```

Run:

```bash
python scripts/aureon_ignition.py --live
```

Let it run **at least 24 hours** of paper trading before moving to D.

For finer-grained Binance testnet stages (per `docs/LIVE_TRADING_RUNBOOK.md`):

- **Stage 0** — testnet + `BINANCE_DRY_RUN=true` (log-only, no orders)
- **Stage 1** — testnet + `BINANCE_DRY_RUN=false` (real testnet orders)

---

### D) Live trade with **real money** ⚠️

**Stage 2** in the live runbook. **Do not start here.** Complete A→B→C first.

```bash
# 1. Edit .env:
#      ALPACA_PAPER=false
#      CAPITAL_DEMO_MODE=false
#      BINANCE_USE_TESTNET=false
#      BINANCE_DRY_RUN=false
#      BINANCE_RISK_MAX_ORDER_USDT=25       # cap order size
#      BINANCE_RISK_FRACTION=0.02           # risk 2% per trade
#      CONFIRM_LIVE=yes                     # explicit live confirmation

# 2. Verify exchange API keys are restricted:
#    - SPOT trading only
#    - NO withdrawals
#    - IP whitelisted

# 3. Read docs/LIVE_TRADING_RUNBOOK.md cover to cover.

# 4. Then:
python scripts/aureon_ignition.py --live
```

**You are now risking real funds.** Watch the first hour live. Have the kill switch ready (`Ctrl+C` from terminal, or operator dashboard kill button if deployed).

---

### E) Run the HNC interactive terminal

```bash
python run_hnc_live.py
```

Queen / HNC cognition loop — interactive, no trading.

---

### F) Production deployment via Docker

```bash
docker build -t aureon-trading .
docker run --env-file .env aureon-trading
```

Container runs `supervisord` — dashboard on `:8080` plus the trading service. **Verify your `.env` has the right `*_DRY_RUN` flags before this command.** See *DigitalOcean safety* below.

---

### G) Nexus Command Server *(WebSocket gateway for the dashboard)*

```bash
npm install
npm run command-server          # default port 8790
```

Starts the gateway at `ws://localhost:8790/command-stream` plus REST endpoints under `/api/command-center/*`. The frontend operator dashboard talks to this. Override port with `NEXUS_COMMAND_PORT`.

---

### H) Windows GUI launcher

```bash
python aureon_launcher/launcher.py
```

Windows-only. Wraps the same ignition script with a tray UI.

---

## 4. Verify your setup is healthy

```bash
# Smoke test
python -m pytest tests/ -k smoke

# Or boot every subsystem without trading
python scripts/aureon_ignition.py --no-trade
# Look for "IGNITION COMPLETE" and "Flight check: N/N GO"
# Ctrl+C
```

If any system reports `NO-GO` in the flight check, **fix it before going live.** The flight check covers: queen online, queen control, trading enabled, labyrinth, thought bus, cortex, source-law, mycelium-mind, metacognition, sentient-loop, intelligence engine, Auris throne.

---

## 5. Common issues

| Symptom | Cause | Fix |
|---|---|---|
| `ModuleNotFoundError` for `aureon_*` | venv not activated | `source .venv/bin/activate`, re-run `pip install -r requirements.txt` |
| `Invalid API-key, IP, or permissions` | wrong env keys, or live keys against testnet | Re-issue keys for the correct environment |
| `Connection refused` to exchange | exchange down, regional block, VPN | Check exchange status; try a different network |
| Boot stalls at "Phase 0: Booting Queen Layer" | a subsystem is hanging on init | Run with `--verbose` |
| Trades aren't executing in `--live` | balance below min order size, or `*_DRY_RUN=true` still set | Check `.env`, exchange balance |
| Boot finishes but `trading_enabled: False` | Risk manager refused to enable | Check logs |

---

## 6. What **not** to do

These commands appear in older docs (`README.md`, `SETUP_HOME_PC.md`, `LIVE_TRADING_RUNBOOK.md`) and **do not work** as of this writing:

- ❌ `python aureon_full_autonomy.py --dry-run` — file does not exist
- ❌ `npm run paper-trade` — no `package.json` at root
- ❌ `python3 scripts/paperTradeSimulation.ts` — file does not exist
- ❌ `python3 aureon_unified_ecosystem.py` — file does not exist
- ❌ `python aureon_live.py --stage N` — renamed; use `scripts/aureon_ignition.py --live`

Open a PR fixing any guide that contradicts this file (see `handoff/patches.md`).

---

## 7. DigitalOcean safety ⚠️

`app.yaml` on `main` ships with these defaults:

```yaml
- key: LIVE
  value: "1"
- key: KRAKEN_DRY_RUN
  value: "false"
- key: BINANCE_DRY_RUN
  value: "false"
- key: ALPACA_DRY_RUN
  value: "false"
```

A fresh DigitalOcean deploy boots into live trading the moment exchange API secrets are populated in App Platform — no further confirmation.

**Before deploying:**

1. Change `app.yaml` defaults to `"true"` for all three `*_DRY_RUN` keys
2. Flip them to `"false"` only after a full local paper-trading validation
3. Add a comment block warning future deployers

A patched `app.yaml` is in `handoff/patches.md`.

---

## 8. Stop the system

- **Foreground:** `Ctrl+C` once. Aureon attempts graceful shutdown. `Ctrl+C` twice to force quit.
- **Docker:** `docker stop <container>` (SIGTERM cascades through supervisord).
- **App Platform:** Pause the component or scale to 0 instances.
- **Operator dashboard kill switch:** click "FLATTEN ALL" → type `FLATTEN` → confirm.

---

## 9. Where to go next

- `docs/LIVE_TRADING_RUNBOOK.md` — pre-flight checklist for live deploys (Stage 0/1/2 detail)
- `CLAUDE.md` — repo-wide rules for AI agents touching this code
- `aureon/queen/` — the Queen layer (read this before disabling anything)
- `frontend/` — Vite + React operator dashboard

---

*Maintainer note: when you change an entry-point file or rename a script, **update this doc in the same PR.** A broken `RUNNING.md` is worse than no `RUNNING.md`.*
