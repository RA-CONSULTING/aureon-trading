# Marketing Landing — UI Kit

Evangelical long-scroll marketing page for **SAMUEL / Aureon Institute**. Mirrors the voice and structure of `https://trading.aureoninstitute.co.uk` while staying inside the brand's token system.

## Sections, top to bottom

1. **Sticky nav** — prism-wordmark "AUREON · SAMUEL", mono nav links, amber CTA
2. **Hero** — `"What if trading wasn't about extraction?"` + prism-gradient word, serif subhead, 3 CTAs (primary / ghost / Observatory glass)
3. **Proof Grid** — 8-tile `44,000 / 37 / 1,500 / $33.5T / 1,066 / 823 / 1,387 / 7.83 Hz` with red-tinted predators (hunters) + green-tinted assets (network) + rainbow-tinted capital
4. **Predator Firms** — 10 HFT firms with animal glyphs + bot counts, all red-tinted
5. **Manifesto** — serif-body, *"They hunt. We harvest."*
6. **Prism Strip** — 5 Platonic solids as market regimes
7. **Tactical Tiers** — Scout → Sniper → Harvester, 3-column
8. **Master Equation** — centered `Λ(t) = S(t) + O(t) + E(t)` with prism underline
9. **Tree of Light** — 8-level ladder with the 528 Hz gate marked
10. **Pricing** — Self-Host £0 · Managed £33/mo (rainbow border on the feature plan)
11. **Government Recognition** — Silver Level badge + ministerial attribution
12. **Footer** — Gary Leckey · Belfast · ORCID · CERN

## Voice rules applied

- Hero uses serif display with one prism-gradient word ("extraction")
- Proof numbers are always `big serif + mono-uppercase label` pairs
- Predator firms use adversary glyphs (🦈 🦁 🐺) in red-tinted chips
- Tactical tiers mix warfare (`IRA sniper patience`) + metaphysics (`Queen AI 12-neuron veto`) + trader data (`Shadow book validates against Need threshold`) in a single sentence
- Pricing copy reads `£33 / month · cancel anytime` (mono sublabel pattern)
- Government section is the only place where the brand plays it straight — no gradients, silver-foil badge, formal attribution
