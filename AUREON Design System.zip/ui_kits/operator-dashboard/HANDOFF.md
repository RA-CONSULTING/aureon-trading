# Operator Dashboard — Engineer Handoff

This is a **drop-in replacement / merge target** for `frontend/src/components/AureonLiveDashboard.tsx`. The HTML prototype in `index.html` is a 1:1 visual spec — every section maps to a component file your engineer creates under `frontend/src/components/operator/`.

---

## File map (what to create in `frontend/src/`)

```
frontend/src/
├── pages/
│   └── Operator.tsx                       ← new route, replaces App.tsx terminal block
└── components/operator/
    ├── OperatorShell.tsx                  ← topbar + nav + main + rail + footer grid
    ├── LambdaHero.tsx                     ← Λ(t) value, β, Γ, Φ, U, 𝓘, prism pip, sparkline
    ├── AurisConsensus.tsx                 ← 9-node grid + consensus ring (4th-pass verdict)
    ├── ExchangeBalances.tsx               ← Kraken / Capital / Alpaca / Binance tiles
    ├── ActivePositions.tsx                ← positions table with archetype tags
    ├── TemporalGround.tsx                 ← ZPE floor / hash / forks / ψ⟩ / governor / Φ rung
    ├── SystemHealth.tsx                   ← 24-domain module list with latency
    ├── DecisionsFeed.tsx                  ← right-rail Queen action feed
    └── KillSwitch.tsx                     ← top-right red button + confirmation dialog
```

---

## Data wiring — already in your repo

Use what's already there. Do not invent new services.

### 1. `Λ(t)` stream — `services/websocketService.ts`

Already returns `StreamPayload { aureon: AureonDataPoint, nexus: CoherenceDataPoint }` over `ws://localhost:8790/command-stream` at 150ms cadence.

```tsx
import { connectWebSocket, StreamPayload } from "@/services/websocketService";

const [lastTick, setLastTick] = useState<StreamPayload | null>(null);

useEffect(() => {
  const conn = connectWebSocket({
    onOpen: () => {},
    onMessage: setLastTick,
    onError: (e) => toast.error(e.message),
    onClose: () => {},
  });
  return () => conn.close();
}, []);
```

**Field mapping** (from `frontend/src/types.ts`):

| Dashboard slot       | Field                                              |
|----------------------|----------------------------------------------------|
| Λ value              | derive from `aureon.coherenceIndex` or compute via `LambdaEngine` endpoint |
| Γ Coherence          | `aureon.crystalCoherence`                          |
| Φ Drift              | `aureon.choeranceDrift`                            |
| Unity U              | `aureon.unityIndex`                                |
| Inercha 𝓘            | `aureon.inerchaVector`                             |
| Prism pip            | `aureon.prismStatus` ('Blue' \| 'Gold' \| 'Red')   |
| Sparkline ring       | local circular buffer of last 240 ticks            |

### 2. Auris 9-node — derive from existing flags on `AureonDataPoint`

The fields are already there: `tigerCut`, `hummingbirdLocked`, `falconSurge`, `surgeMagnitude`, `deerAlert`, `dolphinSong`, `clownfishBond`, `pandaHeart`. Map them to vote/confidence:

```ts
const nodes = [
  { name: "Tiger",       vote: pt.tigerCut ? "BUY" : "HOLD",   conf: pt.surgeMagnitude ?? 0.5 },
  { name: "Falcon",      vote: pt.falconSurge ? "BUY" : "HOLD", conf: pt.surgeMagnitude ?? 0.5 },
  { name: "Hummingbird", vote: pt.hummingbirdLocked ? "BUY" : "HOLD", conf: 0.8 },
  { name: "Dolphin",     vote: pt.dolphinSong ? "BUY" : "HOLD",  conf: 0.75 },
  { name: "Deer",        vote: pt.deerAlert === "SENSITIVE" ? "SELL" : "HOLD", conf: 0.6 },
  // … add Owl, Panda, CargoShip, Clownfish (need backend to expose flags)
];
```

**Action item for backend:** the four missing flags (`owlVeto`, `pandaHeart`, `cargoShipLoad`, `clownfishBond`) need to come through on `AureonDataPoint`. Add them to `aureon/intelligence/auris_*.py` emitters.

### 3. Exchange balances + positions — new endpoints needed

There are services for Kraken/Capital/Alpaca/Binance status (`AlpacaStatusPanel`, `CapitalStatusPanel`, `BinanceConnectionStatus`) but no unified balance/positions API. Add:

```python
# api/operator.py (new)
@router.get("/api/operator/balances")     # → { kraken: {usd, pnl_today}, capital: {...}, ... }
@router.get("/api/operator/positions")    # → ActivePosition[]
@router.get("/api/operator/decisions")    # → TradingDecision[] (last 50)
@router.get("/api/operator/health")       # → SystemHealth (already in types.ts)
```

`ActivePosition` shape (mirrors what dashboard needs):

```ts
interface ActivePosition {
  id: string;
  symbol: string;            // "ETH/USD"
  side: "long" | "short";
  size: number;
  entry: number;
  mark: number;
  pnl_usd: number;
  lambda_at_entry: number;
  archetype: string;         // "Falcon surge" | "Hummingbird lock" | …
  exchange: "kraken" | "capital" | "alpaca" | "binance";
  opened_at: string;
}
```

### 4. Decisions feed — already typed in `types.ts` as `TradingDecision`

Use existing `TradingDecision` from `types.ts`. Add a `kind` field to differentiate:

```ts
type DecisionKind =
  | "execute_long" | "execute_short" | "execute_close"
  | "hold_wait"   | "alert"          | "queen_skill_written";
```

`queen_skill_written` is the new one — emit from `aureon/queen/self_enhancement_engine.py` whenever a skill registers.

### 5. Temporal Ground — new endpoint

```python
# aureon/queen/temporal_ground.py — already exists
@router.get("/api/operator/temporal-ground")
def get_temporal_state():
    return {
        "lambda_zpe": gs.zpe_floor,           # 0.161
        "hash_chain_tip": gs.last_hash[:8],   # "a4f291c0"
        "open_forks": gs.fork_count,
        "psi_norm": gs.superposition_norm,
        "governor": gs.state.value,           # "STABLE" | "DRIFTING" | "CORRECTING" | "RESET"
        "phi_bridge_rung": gs.current_rung,   # "crown · 528 Hz"
    }
```

### 6. System health — already typed

`HealthCheckResponse` and `SystemHealth` from `types.ts` cover this. Wire `GET /api/health` (already exists) to `SystemHealth.tsx`.

### 7. Kill switch — destructive endpoint, requires confirmation

```python
# api/operator.py
@router.post("/api/operator/kill")
def kill_switch(payload: KillRequest):
    """
    payload.confirm must equal "FLATTEN"
    payload.scope: "all" | "exchange:kraken" | "symbol:BTC/USD"
    """
    # 1. Pause LambdaEngine ticks
    # 2. Cancel all open orders
    # 3. Close all positions at market (or LIMIT if scope == "soft")
    # 4. Disable Auris auto-execute
    # 5. Log to audit_log/
    # 6. Notify on Discord webhook
```

UI: text-confirm dialog (`type FLATTEN to confirm`) → fires POST → toast on success/error.

---

## Visual contract — design tokens

All colors, fonts, spacing live in `colors_and_type.css` (project root). The frontend already uses these via `frontend/src/index.css` + Tailwind config.

Use Tailwind classes that map to existing CSS vars:
- `bg-background` `text-foreground` `border-border`
- `text-primary` (gold/amber)
- `text-success` (528 Hz green)
- `text-destructive` (kill / sell)
- Custom: `text-prism-gold` `text-prism-cyan` `text-totem-falcon` (need to be added to `tailwind.config.ts`'s `theme.extend.colors`)

---

## State management

Use `useGlobalState()` (already in repo) + `@tanstack/react-query` (already a dependency) for everything except the Λ stream:

```tsx
const { data: balances } = useQuery({ queryKey: ["balances"], queryFn: () => fetch("/api/operator/balances").then(r => r.json()), refetchInterval: 5000 });
const { data: positions } = useQuery({ queryKey: ["positions"], queryFn: ..., refetchInterval: 2000 });
const { data: decisions } = useQuery({ queryKey: ["decisions"], queryFn: ..., refetchInterval: 1000 });
const { data: health }    = useQuery({ queryKey: ["health"],    queryFn: ..., refetchInterval: 10000 });
```

---

## Routing — replace `App.tsx`

Current `App.tsx` only switches `terminal | observatory`. Add `operator`:

```tsx
const [view, setView] = useState<'operator' | 'terminal' | 'observatory'>('operator');
// route to <Operator /> when view === 'operator'
```

Or — better — introduce `react-router-dom` (already a dep, unused):

```tsx
<Routes>
  <Route path="/" element={<Operator />} />
  <Route path="/terminal" element={<TerminalMirrorApp />} />
  <Route path="/observatory" element={<CinematicObservatory />} />
  <Route path="/war-room" element={<WarRoom />} />
  <Route path="/systems" element={<Systems />} />
</Routes>
```

---

## What's missing that I made up (flag for design review)

These exist in the prototype but don't yet have a backend:
1. **β regime indicator** ("β = 0.847 · stable regime") — needs `LambdaEngine.current_beta()` exposed
2. **Phase-lock detection feed** — `bots_intelligence` has detectors but no streaming endpoint
3. **Queen-wrote-skill events** — `SelfEnhancementEngine` registers skills but doesn't emit to the WS
4. **Φ Bridge rung** — `phi_bridge.py` knows the rung but doesn't expose it
5. **Audit log** — referenced in nav, no backend yet

Owner should triage these into 'in scope for v1' vs 'v2'.

---

## Ship order (suggested)

**Day 1** — `OperatorShell` + `LambdaHero` wired to existing `websocketService`. Everything else mocked. Deploy to staging.
**Day 2** — `ExchangeBalances` + `ActivePositions` + new `/api/operator/balances`, `/api/operator/positions`.
**Day 3** — `AurisConsensus` (with the 4 missing backend flags added).
**Day 4** — `DecisionsFeed` + `TemporalGround` + `SystemHealth`.
**Day 5** — `KillSwitch` + audit log + confirmation flow + Discord webhook.

After day 5 you have a real operator console.
