# Terminal Mirror — UI Kit

Pixel-faithful recreation of the **Terminal Mirror** dashboard from `frontend/src/App.tsx` + `components/LiveTerminalStats.tsx` + `components/AureonLiveDashboard.tsx`.

Open `index.html` to see the full dashboard. All components are defined in `components.jsx` and pull tokens from `../../colors_and_type.css`.

## Component inventory

- `<ExchangeCard exchange status value tickers assets />` — Kraken/Binance/Alpaca/Capital tile
- `<MetricRow label value delta />` — key-value row, tabular mono
- `<PositionLine symbol side venue entry now pnl id />` — open-position row (colored by P&L sign)
- `<ShadowValidationLine ... />` — shadow trade row with `Need` target + age
- `<SignalCard signal symbol confidence score system />` — BUY/SELL/HOLD signal tile
- `<TopMoverTile symbol change price />` — 5-column top-movers grid item
- `<QueenVoicePanel narration lastUpdate />` — narration panel w/ prism border
- `<ObservatoryCTA />` — fixed glass-morphism CTA
- `<Badge variant>` — LIVE / OFF / BUY / SELL / HOLD / CONVERT / exchange / system
- `<Button variant>` — primary / outline / destructive / ghost / observatory

## Tokens used

All HSL triplets pulled from `frontend/src/index.css` — see `../../colors_and_type.css` for the complete map.

## Not included

- 3D Observatory scene (`@react-three/fiber`) — out of scope for a design system package; only the entry CTA is recreated.
