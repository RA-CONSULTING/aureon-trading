/* components used by the Terminal Mirror UI kit */

const { useState, useEffect } = React;

// ---------- primitives ----------

const Badge = ({ variant = 'outline', children, style = {} }) => {
  const variants = {
    live: { bg: 'hsla(142,70%,45%,0.2)', fg: 'hsl(142 70% 75%)', bd: 'hsla(142,70%,45%,0.3)' },
    off:  { bg: 'hsla(0,84%,60%,0.2)',   fg: 'hsl(0 84% 80%)',   bd: 'hsla(0,84%,60%,0.3)' },
    hold: { bg: 'hsla(43,96%,56%,0.2)',  fg: 'hsl(43 96% 75%)',  bd: 'hsla(43,96%,56%,0.3)' },
    info: { bg: 'hsla(185,100%,50%,0.15)',fg: 'hsl(185 100% 75%)',bd: 'hsla(185,100%,50%,0.3)' },
    primary: { bg: 'hsl(43 96% 56%)', fg: 'hsl(20 91% 14%)', bd: 'transparent' },
    outline: { bg: 'transparent', fg: 'hsl(60 9% 97%)', bd: 'hsl(33 5% 32%)' },
  };
  const v = variants[variant] || variants.outline;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '3px 10px', borderRadius: 9999,
      fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 700,
      letterSpacing: '0.04em', textTransform: 'uppercase',
      background: v.bg, color: v.fg, border: `1px solid ${v.bd}`, ...style
    }}>{children}</span>
  );
};

const Pulse = () => <span style={{
  width: 6, height: 6, borderRadius: 9999,
  background: 'hsl(142 70% 55%)',
  boxShadow: '0 0 8px hsl(142 70% 55%)',
  animation: 'love-pulse 2s ease-in-out infinite', display: 'inline-block'
}} />;

const Button = ({ variant = 'outline', children, icon, style = {}, ...rest }) => {
  const variants = {
    primary:     { background: 'hsl(43 96% 56%)', color: 'hsl(20 91% 14%)', border: '1px solid transparent' },
    outline:     { background: 'transparent', color: 'hsl(60 9% 97%)', border: '1px solid hsl(33 5% 32%)' },
    destructive: { background: 'hsl(0 84% 60%)', color: 'hsl(0 85% 97%)', border: '1px solid transparent' },
    ghost:       { background: 'transparent', color: 'hsl(60 9% 97%)', border: '1px solid transparent' },
  };
  return (
    <button {...rest} style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '0 14px', height: 34, borderRadius: 10,
      fontFamily: 'var(--font-sans)', fontWeight: 500, fontSize: 12,
      cursor: 'pointer', whiteSpace: 'nowrap', transition: 'all .2s',
      ...variants[variant], ...style
    }}>
      {icon && <span style={{ fontSize: 13 }}>{icon}</span>}
      {children}
    </button>
  );
};

const Card = ({ children, glow, style = {}, title, eyebrow, actions }) => {
  const shadows = {
    love:    '0 8px 32px -8px hsla(0,0%,0%,.5), 0 0 40px hsla(142,70%,45%,0.25)',
    prism:   '0 8px 32px -8px hsla(0,0%,0%,.5), 0 0 40px hsla(185,100%,50%,0.25), 0 0 80px hsla(280,80%,60%,0.15)',
    rainbow: '0 8px 32px -8px hsla(0,0%,0%,.5), 0 0 30px hsla(0,85%,55%,0.2), 0 0 60px hsla(142,70%,45%,0.2), 0 0 90px hsla(280,80%,60%,0.2)',
    default: '0 8px 32px -8px hsla(0,0%,0%,.5)',
  };
  return (
    <div style={{
      background: 'hsl(12 6% 15%)',
      border: '1px solid hsla(60,9%,97%,0.1)',
      borderRadius: 16,
      padding: 16,
      boxShadow: shadows[glow || 'default'],
      display: 'flex', flexDirection: 'column', gap: 12,
      ...style
    }}>
      {(title || eyebrow || actions) && (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2, minWidth: 0, flex: 1 }}>
            {eyebrow && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'hsla(60,9%,97%,0.55)', lineHeight: 1.2 }}>{eyebrow}</span>}
            {title && <span style={{ fontSize: 15, fontWeight: 600, lineHeight: 1.3 }}>{title}</span>}
          </div>
          {actions}
        </div>
      )}
      {children}
    </div>
  );
};

// ---------- domain components ----------

const EXCHANGE_META = {
  KRAKEN:  { emoji: '🦑', color: 'hsl(270 80% 75%)' },
  BINANCE: { emoji: '🔶', color: 'hsl(43 96% 65%)' },
  ALPACA:  { emoji: '🦙', color: 'hsl(142 70% 65%)' },
  CAPITAL: { emoji: '📈', color: 'hsl(215 80% 70%)' },
};

const ExchangeCard = ({ exchange, status, value, tickers, assets }) => {
  const m = EXCHANGE_META[exchange] || { emoji: '•', color: '#fff' };
  const on = status === 'LIVE';
  return (
    <div style={{
      padding: '12px 14px', borderRadius: 12,
      background: on ? 'hsla(142,70%,45%,0.08)' : 'hsla(0,84%,60%,0.08)',
      border: `1px solid ${on ? 'hsla(142,70%,45%,0.3)' : 'hsla(0,84%,60%,0.3)'}`,
      display: 'flex', flexDirection: 'column', gap: 8,
      minHeight: 66,
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, lineHeight: 1.2 }}>
        <span style={{ fontFamily: 'var(--font-sans)', fontWeight: 700, fontSize: 13, letterSpacing: '0.05em', color: m.color, whiteSpace: 'nowrap' }}>
          {m.emoji} {exchange}
        </span>
        <Badge variant={on ? 'live' : 'off'}>{on && <Pulse />}{status}</Badge>
      </div>
      <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap', fontFamily: 'var(--font-mono)', fontSize: 11, color: 'hsla(60,9%,97%,0.55)', lineHeight: 1.2 }}>
        <span>Value <b style={{ color: '#f6f5f3', fontWeight: 600 }}>{value}</b></span>
        <span>Tickers <b style={{ color: '#f6f5f3', fontWeight: 600 }}>{tickers}</b></span>
        <span>Assets <b style={{ color: '#f6f5f3', fontWeight: 600 }}>{assets}</b></span>
      </div>
    </div>
  );
};

const MetricRow = ({ label, value, delta }) => (
  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: '3px 0', fontFamily: 'var(--font-mono)' }}>
    <span style={{ fontSize: 11, color: 'hsla(60,9%,97%,0.55)', textTransform: 'uppercase', letterSpacing: '0.03em' }}>{label}</span>
    <span style={{ display: 'flex', gap: 8, alignItems: 'baseline' }}>
      <span style={{ fontSize: 12, fontWeight: 600, color: '#f6f5f3', fontVariantNumeric: 'tabular-nums' }}>{value}</span>
      {delta && (
        <span style={{ fontSize: 10, fontWeight: 700, color: delta.startsWith('-') || delta.startsWith('−') ? 'hsl(0 84% 72%)' : 'hsl(142 70% 65%)', fontVariantNumeric: 'tabular-nums' }}>{delta}</span>
      )}
    </span>
  </div>
);

const PositionLine = ({ symbol, side, venue, entry, now, pnl, id }) => {
  const neg = pnl.startsWith('-') || pnl.startsWith('−');
  const bg = neg ? 'hsla(0,84%,60%,0.1)' : 'hsla(142,70%,45%,0.1)';
  const bd = neg ? 'hsla(0,84%,60%,0.3)' : 'hsla(142,70%,45%,0.3)';
  const sideCol = side === 'LONG' ? 'hsl(142 70% 65%)' : 'hsl(0 84% 78%)';
  const pnlCol = neg ? 'hsl(0 84% 78%)' : 'hsl(142 70% 65%)';
  return (
    <div style={{ background: bg, border: `1px solid ${bd}`, borderRadius: 10, padding: '8px 12px', fontFamily: 'var(--font-mono)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <span style={{ fontWeight: 700, fontSize: 12 }}>{symbol}</span>
          <span style={{ color: sideCol, fontSize: 10, fontWeight: 700 }}>{side}</span>
          <span style={{ color: 'hsla(60,9%,97%,0.45)', fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{venue}</span>
        </div>
        <span style={{ color: pnlCol, fontSize: 12, fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>{pnl}</span>
      </div>
      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', fontSize: 10, color: 'hsla(60,9%,97%,0.55)' }}>
        <span>Entry {entry}</span>
        <span>Now {now}</span>
        <span>ID {id}</span>
      </div>
    </div>
  );
};

const ShadowValidationLine = ({ symbol, side, venue, entry, now, pnl, need, age, status }) => (
  <div style={{ background: 'hsla(43,96%,56%,0.08)', border: '1px solid hsla(43,96%,56%,0.3)', borderRadius: 10, padding: '8px 12px', fontFamily: 'var(--font-mono)' }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        <span style={{ fontWeight: 700, fontSize: 12 }}>{symbol}</span>
        <span style={{ color: 'hsl(142 70% 65%)', fontSize: 10, fontWeight: 700 }}>{side}</span>
        <span style={{ color: 'hsla(60,9%,97%,0.45)', fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{venue}</span>
        <span style={{ color: 'hsl(43 96% 72%)', fontSize: 9, fontWeight: 700 }}>{status}</span>
      </div>
      <span style={{ color: 'hsl(142 70% 65%)', fontSize: 12, fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>{pnl}</span>
    </div>
    <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', fontSize: 10, color: 'hsla(60,9%,97%,0.55)' }}>
      <span>Entry {entry}</span>
      <span>Now {now}</span>
      <span>Need {need}</span>
      <span>Age {age}</span>
    </div>
  </div>
);

const SignalCard = ({ signal, symbol, confidence, score, system }) => {
  const sigCol = { BUY: 'hsl(142 70% 65%)', SELL: 'hsl(0 84% 78%)', HOLD: 'hsl(43 96% 72%)' }[signal] || '#fff';
  const bg = { BUY: 'hsla(142,70%,45%,0.1)', SELL: 'hsla(0,84%,60%,0.1)', HOLD: 'hsla(43,96%,56%,0.1)' }[signal];
  const bd = { BUY: 'hsla(142,70%,45%,0.3)', SELL: 'hsla(0,84%,60%,0.3)', HOLD: 'hsla(43,96%,56%,0.3)' }[signal];
  return (
    <div style={{ background: bg, border: `1px solid ${bd}`, borderRadius: 10, padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: 6, fontFamily: 'var(--font-mono)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontWeight: 700, fontSize: 12 }}>{symbol}</span>
        <span style={{ color: sigCol, fontWeight: 700, fontSize: 11 }}>{signal}</span>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, color: 'hsla(60,9%,97%,0.6)' }}>
        <span>{confidence}% conf</span>
        <span>Score {score}/10</span>
        <span>{system}</span>
      </div>
    </div>
  );
};

const TopMoverTile = ({ symbol, change, price }) => {
  const neg = change.startsWith('-') || change.startsWith('−');
  return (
    <div style={{
      background: neg ? 'hsla(0,84%,60%,0.08)' : 'hsla(142,70%,45%,0.08)',
      border: `1px solid ${neg ? 'hsla(0,84%,60%,0.3)' : 'hsla(142,70%,45%,0.3)'}`,
      borderRadius: 10, padding: '8px 10px',
      display: 'flex', flexDirection: 'column', gap: 2,
      fontFamily: 'var(--font-mono)',
    }}>
      <span style={{ fontSize: 11, fontWeight: 700 }}>{symbol}</span>
      <span style={{ fontSize: 10, color: neg ? 'hsl(0 84% 78%)' : 'hsl(142 70% 65%)', fontWeight: 700 }}>{change}</span>
      <span style={{ fontSize: 9, color: 'hsla(60,9%,97%,0.55)', fontVariantNumeric: 'tabular-nums' }}>{price}</span>
    </div>
  );
};

const QueenVoicePanel = ({ narration, lastUpdate }) => (
  <div style={{
    position: 'relative',
    background: 'hsl(12 6% 15%)',
    borderRadius: 16,
    padding: 2,
    backgroundImage: 'linear-gradient(hsl(12 6% 15%), hsl(12 6% 15%)), linear-gradient(135deg, hsl(0 85% 55%), hsl(45 100% 55%), hsl(142 70% 45%), hsl(185 100% 50%), hsl(280 80% 60%), hsl(320 80% 55%))',
    backgroundOrigin: 'border-box',
    backgroundClip: 'padding-box, border-box',
    border: '1px solid transparent',
    boxShadow: '0 8px 32px -8px hsla(0,0%,0%,.5), 0 0 40px hsla(185,100%,50%,0.15), 0 0 80px hsla(280,80%,60%,0.1)',
  }}>
    <div style={{ padding: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'hsla(60,9%,97%,0.75)' }}>🔮 Queen Voice</span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'hsla(60,9%,97%,0.45)' }}>{lastUpdate}</span>
      </div>
      <p style={{ margin: 0, fontFamily: 'var(--font-serif)', fontSize: 14, lineHeight: 1.5, color: 'hsla(60,9%,97%,0.85)' }}>
        {narration}
      </p>
    </div>
  </div>
);

const ObservatoryCTA = () => (
  <button style={{
    position: 'fixed', bottom: 16, right: 16, zIndex: 50,
    height: 44, padding: '0 20px', borderRadius: 12,
    background: 'linear-gradient(to right, hsla(239,84%,67%,0.8), hsla(271,81%,56%,0.8))',
    color: '#fff', border: '1px solid hsla(0,0%,100%,0.1)',
    backdropFilter: 'blur(20px)', cursor: 'pointer',
    fontFamily: 'var(--font-sans)', fontWeight: 500, fontSize: 13,
    boxShadow: '0 4px 20px hsla(239,84%,67%,0.3)',
    display: 'inline-flex', alignItems: 'center', gap: 8,
  }}>
    <span>✨</span> Enter Observatory
  </button>
);

Object.assign(window, {
  Badge, Pulse, Button, Card,
  ExchangeCard, MetricRow, PositionLine, ShadowValidationLine,
  SignalCard, TopMoverTile, QueenVoicePanel, ObservatoryCTA,
});
