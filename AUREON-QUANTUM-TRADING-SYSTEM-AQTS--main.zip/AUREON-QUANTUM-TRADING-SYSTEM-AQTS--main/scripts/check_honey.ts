
import { honeyPot } from '../core/honeyPot';

honeyPot.displayStatus();
