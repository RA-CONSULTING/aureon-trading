"""Epicenter package for multi-symbol, multi-strategy spot trading."""
