import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, CheckCircle, AlertTriangle, Lock } from 'lucide-react';
import type { ComplianceReport } from '@/src/engine/compliance';

interface ComplianceReportDisplayProps {
  report: ComplianceReport;
}

export function ComplianceReportDisplay({ report }: ComplianceReportDisplayProps) {
  const getStatusColor = () => {
    if (report.reroute_detected && !report.repaired) return 'destructive';
    if (report.reroute_detected && report.repaired) return 'secondary';
    return 'default';
  };

  const getStatusIcon = () => {
    if (report.reroute_detected && !report.repaired) return <AlertTriangle className="h-4 w-4" />;
    if (report.reroute_detected && report.repaired) return <Shield className="h-4 w-4" />;
    return <CheckCircle className="h-4 w-4" />;
  };

  return (
    <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-indigo-50">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-blue-900">
          <Lock className="h-5 w-5" />
          Source Law {report.source_law} Compliance Report
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{report.enumerated_outcomes}</div>
            <div className="text-xs text-gray-600">Outcomes</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">{report.harmonics_axes}</div>
            <div className="text-xs text-gray-600">Harmonics</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">1</div>
            <div className="text-xs text-gray-600">Prime</div>
          </div>
          <div className="text-center">
            <Badge variant={report.zpe_intent_applied ? 'default' : 'secondary'} className="text-xs">
              {report.zpe_intent_applied ? 'ZPE Applied' : 'No Intent'}
            </Badge>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Badge variant={report.peace_joy ? 'default' : 'destructive'}>
            Peace & Joy: {report.peace_joy ? '✓' : '✗'}
          </Badge>
          <Badge variant={report.tlid_present ? 'default' : 'secondary'}>
            TLID: {report.tlid_present ? '✓' : '✗'}
          </Badge>
          <Badge variant={getStatusColor()} className="flex items-center gap-1">
            {getStatusIcon()}
            {report.reroute_detected ? 
              (report.repaired ? 'Auto-Repaired' : 'Reroute Detected') : 
              'Compliant'
            }
          </Badge>
        </div>

        {report.message.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-gray-700">Compliance Notes:</h4>
            <ul className="text-xs text-gray-600 space-y-1">
              {report.message.map((msg, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-blue-500 mt-0.5">•</span>
                  {msg}
                </li>
              ))}
            </ul>
          </div>
        )}

        {report.signature && (
          <div className="pt-2 border-t">
            <div className="text-xs text-gray-500 font-mono break-all">
              Signature: {report.signature.slice(0, 20)}...
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}