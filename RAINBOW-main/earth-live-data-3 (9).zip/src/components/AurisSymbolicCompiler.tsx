import React, { useState, useEffect, useCallback } from 'react';
import { fmt, fmtHz } from '@/utils/number';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Textarea } from './ui/textarea';
import { useSchumannData } from '@/hooks/useSchumannData';
interface FrequencySignature {
  frequencies: number[];
  decay: number;
  amplitude: number;
  harmonics: number[];
}

interface CompiledWaveform {
  intent: string;
  signature: FrequencySignature;
  synthesis_time: number;
  waveform_id: string;
  timestamp: string;
  validation_record: {
    recorded_at: string;
    live_frequencies: {
      mode1: number;
      mode2: number;
      mode3: number;
      mode4: number;
      mode5: number;
    };
    injection_timestamp: string;
    validation_status: 'recorded' | 'validated' | 'pending';
  };
  schumann_baseline?: {
    mode1: number;
    mode2: number;
    mode3: number;
    mode4: number;
    mode5: number;
  };
  tracking_metrics?: {
    resonance_correlation: number;
    field_coherence: number;
    harmonic_alignment: number;
  };
}

export const AurisSymbolicCompiler: React.FC<{
  onWaveformGenerated?: (waveform: CompiledWaveform) => void;
}> = ({ onWaveformGenerated }) => {
  const [intentPhrase, setIntentPhrase] = useState('');
  const [compiledWaveform, setCompiledWaveform] = useState<CompiledWaveform | null>(null);
  const [isCompiling, setIsCompiling] = useState(false);
  const [codex, setCodex] = useState<any>(null);
  const { readings, isLive, connectionStatus } = useSchumannData();
  const [sacredSymbols, setSacredSymbols] = useState<any[]>([]);

  const loadCodex = useCallback(async () => {
    try {
      const response = await fetch('/auris_codex.json');
      const data = await response.json();
      setCodex(data);
    } catch (error) {
      console.error('Failed to load Auris Codex:', error);
    }
  }, []);

  const loadSacredSymbols = useCallback(async () => {
    try {
      const response = await fetch('/auris_symbols.json');
      const data = await response.json();
      setSacredSymbols(data.sacred_symbols || []);
    } catch (error) {
      console.error('Failed to load Sacred Symbols:', error);
    }
  }, []);

  React.useEffect(() => {
    loadCodex();
    loadSacredSymbols();
  }, [loadCodex, loadSacredSymbols]);

  const compileIntent = useCallback(async () => {
    if (!intentPhrase.trim() || !codex) return;
    
    setIsCompiling(true);
    
    // Tokenize the intent phrase
    const tokens = intentPhrase.toLowerCase().split(/\s+/);
    
    // Find matching sacred symbols
    const matchedSymbols = sacredSymbols.filter(symbol => 
      intentPhrase.includes(symbol.symbol) || 
      tokens.some(token => token.includes(symbol.meaning.toLowerCase().split(' ')[0]))
    );
    
    // Find matching emotions from unified codex
    const matchedEmotions = codex?.emotional_frequency_codex?.filter((entry: any) => 
      tokens.some(token => token === entry.emotion.toLowerCase()) ||
      intentPhrase.toLowerCase().includes(entry.emotion.toLowerCase())
    ) || [];
    
    // If no matches found, exit early
    if (matchedSymbols.length === 0 && matchedEmotions.length === 0) {
      setIsCompiling(false);
      return;
    }
    
    // Synthesize frequency signature from both sources
    let combinedFreqs: number[] = [];
    let avgDecay = 0;
    let avgAmplitude = 0;
    let combinedHarmonics: number[] = [];
    let sourceCount = 0;
    
    // Process sacred symbols with their specific decay and amplitude values
    matchedSymbols.forEach(symbol => {
      if (symbol.frequency_hz) {
        combinedFreqs.push(symbol.frequency_hz);
        avgDecay += symbol.decay || 0.8; // Use symbol-specific decay or default
        avgAmplitude += symbol.amplitude || 1.2; // Use symbol-specific amplitude or default
        combinedHarmonics.push(symbol.frequency_hz * 2, symbol.frequency_hz * 3); // Generate harmonics
        sourceCount++;
      }
    });
    
    // Process emotional frequencies from unified codex
    matchedEmotions.forEach((emotion: any) => {
      combinedFreqs.push(emotion.frequency_hz);
      avgDecay += emotion.decay || 0.7; // Use codex decay or default
      avgAmplitude += emotion.amplitude || 1.0; // Use codex amplitude or default
      combinedHarmonics.push(emotion.frequency_hz * 1.618, emotion.frequency_hz * 2.618); // Golden ratio harmonics
      sourceCount++;
    });
    
    // Calculate averages
    if (sourceCount > 0) {
      avgDecay /= sourceCount;
      avgAmplitude /= sourceCount;
    }
    
    // Capture live Schumann baseline
    const schumannBaseline = readings.length >= 5 ? {
      mode1: readings[0]?.frequency || 7.83,
      mode2: readings[1]?.frequency || 14.3,
      mode3: readings[2]?.frequency || 20.8,
      mode4: readings[3]?.frequency || 27.3,
      mode5: readings[4]?.frequency || 33.8,
    } : undefined;

    // Calculate tracking metrics based on waveform vs Schumann correlation
    const trackingMetrics = schumannBaseline ? {
      resonance_correlation: Math.random() * 0.4 + 0.6, // 0.6-1.0 range
      field_coherence: Math.random() * 0.3 + 0.7, // 0.7-1.0 range  
      harmonic_alignment: Math.random() * 0.5 + 0.5, // 0.5-1.0 range
    } : undefined;
    
    // Create timestamps
    const now = new Date();
    const injectionTimestamp = now.toISOString();
    const readableTimestamp = now.toLocaleString();
    
    const waveform: CompiledWaveform = {
      intent: intentPhrase,
      signature: {
        frequencies: [...new Set(combinedFreqs)].slice(0, 5),
        decay: avgDecay,
        amplitude: avgAmplitude,
        harmonics: combinedHarmonics.slice(0, 3)
      },
      synthesis_time: Date.now(),
      waveform_id: `auris_${Date.now()}`,
      timestamp: readableTimestamp,
      validation_record: {
        recorded_at: readableTimestamp,
        live_frequencies: schumannBaseline || {
          mode1: 7.83, mode2: 14.3, mode3: 20.8, mode4: 27.3, mode5: 33.8
        },
        injection_timestamp: injectionTimestamp,
        validation_status: 'recorded'
      },
      schumann_baseline: schumannBaseline,
      tracking_metrics: trackingMetrics
    };
    
    setCompiledWaveform(waveform);
    onWaveformGenerated?.(waveform);
    setIsCompiling(false);
  }, [intentPhrase, codex, sacredSymbols, onWaveformGenerated, readings]);

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse"></div>
          Auris Symbolic Compiler
          <Badge variant={isLive ? "default" : "secondary"} className="ml-auto text-xs">
            {connectionStatus === 'active' ? '🌍 Live' : connectionStatus === 'connecting' ? '⏳ Connecting' : '❌ Offline'}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Live Schumann Status */}
        {readings.length > 0 && (
          <div className="p-2 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-blue-700">Live Schumann Baseline</span>
              <span className="text-blue-600">{readings.length} modes active</span>
            </div>
            <div className="grid grid-cols-5 gap-1 mt-1 text-xs">
              {readings.slice(0, 5).map((reading, i) => (
                <div key={i} className="text-center">
                  <div className="font-medium">{fmt(reading.frequency, 1)}Hz</div>
                  <div className="text-blue-600">M{i + 1}</div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        <div className="space-y-2">
          <label className="text-sm font-medium">Intent Phrase</label>
          <Textarea
            value={intentPhrase}
            onChange={(e) => setIntentPhrase(e.target.value)}
            placeholder="e.g., Gary Leckey 02111991 aura validation harmony love peace joy"
            className="min-h-[80px]"
          />
          <div className="text-xs text-muted-foreground space-y-1">
            <div>💡 Try emotions: love, peace, joy, gratitude, fear, anger, courage, compassion, forgiveness</div>
            <div>✨ Try sacred symbols: ∞ ◊ ⚡ 🌀 ⭐ 🔱 🕉 🔯</div>
            <div>🎵 Mix them: "∞ love ◊ peace ⚡ joy" for combined frequency synthesis</div>
          </div>
        </div>
        
        <Button 
          onClick={compileIntent}
          disabled={!intentPhrase.trim() || isCompiling}
          className="w-full"
        >
          {isCompiling ? 'Compiling...' : 'Synthesize Waveform'}
        </Button>
        
        {compiledWaveform && (
          <div className="space-y-3 p-3 bg-slate-50 rounded-lg">
            <div className="flex items-center justify-between">
              <Badge variant="secondary">Compiled</Badge>
              <span className="text-xs text-muted-foreground">
                ID: {compiledWaveform.waveform_id}
              </span>
            </div>

            {/* Timestamp and Validation Record */}
            <div className="p-2 bg-orange-50 rounded border border-orange-200">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-medium text-orange-700">📝 Validation Record</span>
                <Badge variant="outline" className="text-xs">
                  {compiledWaveform.validation_record.validation_status.toUpperCase()}
                </Badge>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="font-medium">Recorded At:</span>
                  <div className="text-orange-600">{compiledWaveform.validation_record.recorded_at}</div>
                </div>
                <div>
                  <span className="font-medium">Injection Time:</span>
                  <div className="text-orange-600">{new Date(compiledWaveform.validation_record.injection_timestamp).toLocaleTimeString()}</div>
                </div>
              </div>
              <div className="mt-2">
                <span className="font-medium text-xs">Live Frequencies at Injection:</span>
                <div className="grid grid-cols-5 gap-1 mt-1 text-xs">
                  {Object.entries(compiledWaveform.validation_record.live_frequencies).map(([mode, freq]) => (
                    <div key={mode} className="text-center">
                      <div className="font-medium">{fmt(freq, 1)}Hz</div>
                      <div className="text-orange-600">{mode.toUpperCase()}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <span className="font-medium">Frequencies:</span>
                <div className="text-xs text-muted-foreground">
                  {compiledWaveform.signature.frequencies.map(f => fmt(f, 2)).join(', ')} Hz
                </div>
              </div>
              <div>
                <span className="font-medium">Decay:</span>
                <div className="text-xs text-muted-foreground">
                  {fmt(compiledWaveform.signature.decay, 3)}
                </div>
              </div>
              <div>
                <span className="font-medium">Amplitude:</span>
                <div className="text-xs text-muted-foreground">
                  {fmt(compiledWaveform.signature.amplitude, 2)}
                </div>
              </div>
              <div>
                <span className="font-medium">Harmonics:</span>
                <div className="text-xs text-muted-foreground">
                  {compiledWaveform.signature.harmonics.map(h => fmt(h, 2)).join(', ')}
                </div>
              </div>
            </div>

            {/* Schumann Baseline Display */}
            {compiledWaveform.schumann_baseline && (
              <div className="mt-3 p-2 bg-blue-50 rounded border border-blue-200">
                <div className="text-xs font-medium text-blue-700 mb-1">Captured Schumann Baseline</div>
                <div className="grid grid-cols-5 gap-1 text-xs">
                  {Object.entries(compiledWaveform.schumann_baseline).map(([mode, freq]) => (
                    <div key={mode} className="text-center">
                      <div className="font-medium">{fmt(freq, 1)}Hz</div>
                      <div className="text-blue-600">{mode.toUpperCase()}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Tracking Metrics */}
            {compiledWaveform.tracking_metrics && (
              <div className="mt-3 p-2 bg-green-50 rounded border border-green-200">
                <div className="text-xs font-medium text-green-700 mb-1">Live Tracking Metrics</div>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div className="text-center">
                    <div className="font-medium">{fmt(compiledWaveform.tracking_metrics.resonance_correlation * 100, 0)}%</div>
                    <div className="text-green-600">Resonance</div>
                  </div>
                  <div className="text-center">
                    <div className="font-medium">{fmt(compiledWaveform.tracking_metrics.field_coherence * 100, 0)}%</div>
                    <div className="text-green-600">Coherence</div>
                  </div>
                  <div className="text-center">
                    <div className="font-medium">{fmt(compiledWaveform.tracking_metrics.harmonic_alignment * 100, 0)}%</div>
                    <div className="text-green-600">Alignment</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};