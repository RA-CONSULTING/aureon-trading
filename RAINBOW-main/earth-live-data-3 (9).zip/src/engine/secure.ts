// src/engine/secure.ts
import { createHmac, createHash } from "crypto";

// Mission lock: sign a config blob so weights can't be silently rerouted
export function signConfig(config: object, secret: string) {
  const payload = JSON.stringify(config);
  return createHmac("sha256", secret).update(payload).digest("base64url");
}

export function verifyConfig(config: object, secret: string, signature: string) {
  try {
    const check = signConfig(config, secret);
    return check === signature;
  } catch { 
    return false; 
  }
}

// Deterministic RNG (HMAC-DRBG-style) without external deps.
export function makeDeterministicRng(seedStr: string) {
  let counter = 0;
  return () => {
    const buf = createHmac("sha256", "NX-PRIME").update(seedStr + ":" + (counter++)).digest();
    // convert first 6 bytes to a float in [0,1)
    const n = buf.readUIntBE(0, 6) / 2 ** 48;
    return n;
  };
}

// Stable seed from profile + date (ties to TLID ingredients)
export function defaultSeed(name: string, dob: string, isoDate: string) {
  return createHash("sha256")
    .update(`${name}|${dob}|${isoDate}|nexus:10-9-1|peace+joy`)
    .digest("hex");
}

// Generate cryptographically secure mission key
export function generateMissionKey() {
  return createHash("sha256")
    .update(Math.random().toString() + Date.now().toString())
    .digest("hex");
}