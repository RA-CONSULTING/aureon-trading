/**
 * Harmonic Nexus Core (HNC) - Central Resonance Orchestrator
 * ----------------------------------------------------------
 * The heart of the entire Harmonic Nexus system that unifies all streams:
 * - Biofield input (aura, emotional resonance)
 * - Schumann resonances (7.83 Hz and harmonics)
 * - Prime lattice calculations
 * - Planetary harmonics
 * - Intent compilation from auris_codex.json
 * 
 * Functions as the central conductor that keeps phase, frequency, 
 * and amplitude aligned across all modules.
 */

import { stampNow, type HighResStamp } from '@/lib/HighResClock';

export type ResonanceSample = { 
  t: number; 
  t_micros?: number;
  band: string; 
  power: number;
  phase?: number;
  amplitude?: number;
};

export type AffectSample = { 
  t: number; 
  t_micros?: number;
  v: number; 
  a: number;
  coherence?: number;
};

export type NarrativeItem = {
  t: number;
  t_micros?: number;
  station: string;
  region?: string;
  text: string;
  emotion: string;
  tags: string[];
  resonance_freq?: number;
};

export type PrimeRatio = {
  numerator: number;
  denominator: number;
  frequency: number;
  stability: number;
};

export type SurgeEvent = {
  t: number;
  t_micros: number;
  type: 'constructive' | 'destructive' | 'prime_lock';
  amplitude: number;
  frequency: number;
  prime_ratios: PrimeRatio[];
};

export type HNCDriver = {
  label: string;
  weight: number;
  station?: string;
  frequency?: number;
  prime_factor?: number;
};

export type HNCEdge = {
  from: string;
  to: string;
  weight: number;
  phase_diff: number;
  coherence: number;
};

export type HNCRegionTick = {
  region: string;
  score: number;
  byBand: Record<string, number>;
  drivers: HNCDriver[];
  edges: HNCEdge[];
  updatedAt: number;
  updatedAtMicros: number;
  schumann_lock: number;
  prime_coherence: number;
  surge_events: SurgeEvent[];
};

export interface HNCConfig {
  windowMinutes: number;
  hopMinutes: number;
  bands: string[];
  schumann_base: number;
  prime_ratios: number[];
  surge_threshold: number;
}

/**
 * Central Harmonic Nexus Core Engine
 * Orchestrates all resonance streams into unified harmonic field
 */
export class HarmonicNexusCore {
  private config: HNCConfig;
  private resonance: ResonanceSample[] = [];
  private affect: AffectSample[] = [];
  private narratives: NarrativeItem[] = [];
  private surgeEvents: SurgeEvent[] = [];
  private lastTick: HighResStamp;

  constructor(config?: Partial<HNCConfig>) {
    this.config = {
      windowMinutes: config?.windowMinutes ?? 60,
      hopMinutes: config?.hopMinutes ?? 5,
      bands: config?.bands ?? ["7.83", "14.3", "20.8", "27.3", "33.8"],
      schumann_base: config?.schumann_base ?? 7.83,
      prime_ratios: config?.prime_ratios ?? [2, 3, 5, 7, 11, 13, 17, 19],
      surge_threshold: config?.surge_threshold ?? 0.8,
    };
    this.lastTick = stampNow();
  }

  /** Central Stream Ingestion */
  addResonance(sample: ResonanceSample) {
    const stamped = { ...sample, t_micros: sample.t_micros || stampNow().epochMicros };
    this.resonance.push(stamped);
    this.detectSurgeEvents(stamped);
  }

  addAffect(sample: AffectSample) {
    const stamped = { ...sample, t_micros: sample.t_micros || stampNow().epochMicros };
    this.affect.push(stamped);
  }

  addNarrative(item: NarrativeItem) {
    const stamped = { ...item, t_micros: item.t_micros || stampNow().epochMicros };
    this.narratives.push(stamped);
  }

  /** Surge Detection & Prime Control */
  private detectSurgeEvents(sample: ResonanceSample) {
    if (sample.power > this.config.surge_threshold) {
      const primeRatios = this.calculatePrimeRatios(sample.band);
      const surge: SurgeEvent = {
        t: sample.t,
        t_micros: sample.t_micros || stampNow().epochMicros,
        type: this.classifySurgeType(sample, primeRatios),
        amplitude: sample.power,
        frequency: parseFloat(sample.band),
        prime_ratios: primeRatios
      };
      this.surgeEvents.push(surge);
    }
  }

  private calculatePrimeRatios(band: string): PrimeRatio[] {
    const freq = parseFloat(band);
    return this.config.prime_ratios.map(prime => ({
      numerator: prime,
      denominator: 1,
      frequency: freq * prime,
      stability: this.calculateStability(freq, prime)
    }));
  }

  private classifySurgeType(sample: ResonanceSample, ratios: PrimeRatio[]): SurgeEvent['type'] {
    const maxStability = Math.max(...ratios.map(r => r.stability));
    if (maxStability > 0.9) return 'prime_lock';
    if (sample.power > this.config.surge_threshold * 1.5) return 'constructive';
    return 'destructive';
  }

  private calculateStability(freq: number, prime: number): number {
    const ratio = freq / this.config.schumann_base;
    const primeDistance = Math.abs(ratio - prime);
    return Math.exp(-primeDistance * 2); // Exponential decay from prime
  }

  /** Core Orchestration Engine */
  run(region: string): HNCRegionTick {
    const tick = stampNow();
    
    // Phase & Frequency Alignment
    const recentResonance = this.resonance.slice(-50);
    const recentAffect = this.affect.slice(-10);
    const recentNarratives = this.narratives.slice(-20);
    
    // Schumann Lock Calculation
    const schumann_lock = this.calculateSchumannLock(recentResonance);
    
    // Prime Coherence
    const prime_coherence = this.calculatePrimeCoherence(recentResonance);
    
    // Unified Harmonic Field
    const avgValence = recentAffect.reduce((sum, a) => sum + a.v, 0) / (recentAffect.length || 1);
    const avgArousal = recentAffect.reduce((sum, a) => sum + a.a, 0) / (recentAffect.length || 1);
    
    // Central Coherence Score (0-100)
    const emotionalCoherence = 50 + (avgValence * 25) + (avgArousal * 25);
    const schumannBonus = schumann_lock * 20;
    const primeBonus = prime_coherence * 15;
    const score = Math.max(0, Math.min(100, 
      Math.round(emotionalCoherence + schumannBonus + primeBonus)
    ));
    
    // Band Coherence with Prime Modulation
    const byBand = Object.fromEntries(
      this.config.bands.map((b, i) => {
        const baseCoherence = 0.3 + (avgArousal * 0.4);
        const harmonicShift = avgValence * 0.2 * (i + 1);
        const primeModulation = prime_coherence * 0.3;
        const schumannSync = schumann_lock * 0.2;
        return [b, Math.max(0, Math.min(1, 
          baseCoherence + harmonicShift + primeModulation + schumannSync
        ))];
      })
    );
    
    // Enhanced Drivers with Frequency Mapping
    const drivers: HNCDriver[] = [
      { 
        label: "schumann_resonance", 
        weight: schumann_lock, 
        station: "Earth", 
        frequency: this.config.schumann_base,
        prime_factor: 1
      },
      { 
        label: "emotional_field", 
        weight: 0.4 + avgValence * 0.2, 
        station: "Biofield",
        frequency: 40 + (avgArousal * 20), // Beta/Gamma range
        prime_factor: 3
      },
      { 
        label: "narrative_coherence", 
        weight: 0.3 + (recentNarratives.length * 0.05), 
        station: "Collective",
        frequency: 10 + (avgValence * 5), // Alpha range
        prime_factor: 2
      },
    ];
    
    // Phase-Locked Edges
    const edges: HNCEdge[] = [
      { 
        from: "Earth", 
        to: region, 
        weight: schumann_lock,
        phase_diff: 0,
        coherence: schumann_lock
      },
      { 
        from: "Biofield", 
        to: region, 
        weight: 0.6 + avgValence * 0.2,
        phase_diff: avgArousal * Math.PI / 4,
        coherence: prime_coherence
      },
    ];

    // Recent Surge Events
    const recentSurges = this.surgeEvents.filter(s => 
      tick.epochMicros - s.t_micros < 60000000 // Last minute
    );

    this.lastTick = tick;

    return { 
      region, 
      score, 
      byBand, 
      drivers, 
      edges, 
      updatedAt: tick.epochMillis,
      updatedAtMicros: tick.epochMicros,
      schumann_lock,
      prime_coherence,
      surge_events: recentSurges
    };
  }

  private calculateSchumannLock(samples: ResonanceSample[]): number {
    const schumannSamples = samples.filter(s => 
      Math.abs(parseFloat(s.band) - this.config.schumann_base) < 0.5
    );
    if (schumannSamples.length === 0) return 0;
    
    const avgPower = schumannSamples.reduce((sum, s) => sum + s.power, 0) / schumannSamples.length;
    return Math.min(1, avgPower);
  }

  private calculatePrimeCoherence(samples: ResonanceSample[]): number {
    let coherenceSum = 0;
    let count = 0;
    
    for (const sample of samples) {
      const freq = parseFloat(sample.band);
      for (const prime of this.config.prime_ratios) {
        const expectedFreq = this.config.schumann_base * prime;
        const deviation = Math.abs(freq - expectedFreq) / expectedFreq;
        if (deviation < 0.1) { // Within 10%
          coherenceSum += sample.power * (1 - deviation * 10);
          count++;
        }
      }
    }
    
    return count > 0 ? Math.min(1, coherenceSum / count) : 0;
  }

  /** Codex Gateway Functions */
  mapIntentToFrequency(intent: string, codex: Record<string, any>): number {
    const keywords = intent.toLowerCase().split(' ');
    let totalFreq = this.config.schumann_base;
    let count = 1;
    
    for (const keyword of keywords) {
      if (codex[keyword]?.frequency) {
        totalFreq += codex[keyword].frequency;
        count++;
      }
    }
    
    return totalFreq / count;
  }

  /** Multiversal Echo Layer (Optional) */
  generateEchoHarmonics(baseFreq: number, depth: number = 3): number[] {
    const echoes: number[] = [];
    
    for (let i = 1; i <= depth; i++) {
      for (const prime of this.config.prime_ratios.slice(0, 5)) {
        // Generate interference patterns using prime folding
        const echo = baseFreq * (prime / (prime + i));
        echoes.push(echo);
      }
    }
    
    return echoes.sort((a, b) => a - b);
  }
}