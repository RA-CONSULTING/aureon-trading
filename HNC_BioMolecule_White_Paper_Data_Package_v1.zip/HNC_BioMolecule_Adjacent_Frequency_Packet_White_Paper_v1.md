# A Falsifiable HNC Biomolecule-to-Frequency Packet Hypothesis

This Markdown source mirrors the DOCX white paper at a high level. See DOCX/PDF for formatted tables and figures.

## Core packet frequencies

1012.1 Hz, 1259.9 Hz, 1367.2 Hz, 1380.3 Hz, 1390.8 Hz, 1398.6 Hz, 1402.1 Hz, 1417.0 Hz, 1423.9 Hz, 1439.6 Hz, 1577.1 Hz, 1652.5 Hz, 1817.7 Hz

## Primary hypothesis

Arm H must outperform molecule-only, carrier-only, random-packet and molecule-plus-random-packet controls on pre-specified DNA-damage endpoints without being explained by cell death, heating or batch artifacts.

## References

[1] Rhayem L, et al. Bioactive Compounds from Dandelion (Taraxacum officinale). Foods. 2026;15(4):782. https://www.mdpi.com/2304-8158/15/4/782
[2] Tanasa MV, et al. Bioactive Compounds from Vegetal Organs of Taraxacum officinale. International Journal of Molecular Sciences. 2025;26(2):450. https://www.mdpi.com/1422-0067/26/2/450
[3] Masciulli F, et al. Phytochemical composition and bioactivity of edible Taraxacum officinale: potential as an ingredient in brain health-oriented functional foods. Food & Function. 2025. https://pubs.rsc.org/en/content/articlehtml/2025/fo/d5fo02646f
[4] Vershinina Y, et al. Raman and IR spectroscopy as a promising approach to rapid and non-destructive monitoring of chlorogenic acid in protein matrices. Frontiers in Chemistry. 2025;13:1543663. doi:10.3389/fchem.2025.1543663.
[5] Lee J, Scagel CF. Chicoric acid: chemistry, distribution, and production. Frontiers in Chemistry. 2013;1:40. doi:10.3389/fchem.2013.00040.
[6] Zheng Y, et al. Density Functional Theory Analysis of Luteolin Molecular Structure and Spectral Properties. 2026. https://pmc.ncbi.nlm.nih.gov/articles/PMC12878360/
[7] de Freitas LF, Hamblin MR. Proposed mechanisms of photobiomodulation or low-level light therapy. IEEE Journal of Selected Topics in Quantum Electronics. 2016;22(3). https://pmc.ncbi.nlm.nih.gov/articles/PMC5215870/
[8] Kim YJ, et al. A protective mechanism of visible red light in normal human dermal fibroblasts: enhancement of GADD45A-mediated DNA repair activity. Journal of Investigative Dermatology. 2017. https://pubmed.ncbi.nlm.nih.gov/27729279/
[9] Feng Y, et al. Photobiomodulation inhibits ischemia-induced brain endothelial senescence via endothelial nitric oxide synthase. Antioxidants. 2024;13:633. https://www.mdpi.com/2076-3921/13/6/633
[10] Broad Institute. DepMap Portal. Open access cancer dependency and cell-line characterization resource. https://depmap.org/
[11] Bioconductor. depmap: Cancer Dependency Map Data Package. Version 1.26.0, July 2026. https://www.bioconductor.org/packages/release/data/experiment/html/depmap.html
[12] AWS Open Data Registry. DepMap Cancer Cell Line Encyclopedia Omics Dataset. https://registry.opendata.aws/depmap-omics-ccle/
[13] Wellcome Sanger Institute. Cancer Dependency Map and Cell Model Passports datasets. https://depmap.sanger.ac.uk/documentation/datasets/
[14] Gong M, et al. Loss-of-function mutations in KEAP1 drive lung cancer progression via KEAP1/NRF2 pathway activation. Cell Communication and Signaling. 2020. https://pmc.ncbi.nlm.nih.gov/articles/PMC7310414/
[15] Vikhanskaya F, et al. Cooperation between p53 and hMLH1 in a human colon cancer cell line HCT116. Clinical Cancer Research. 1999. https://pubmed.ncbi.nlm.nih.gov/10213232/
[16] Tian T, et al. MCF-7 cells lack the expression of caspase-3. 2023. https://pubmed.ncbi.nlm.nih.gov/36690238/
[17] Goodwin EC, DiMaio D. Repression of human papillomavirus oncogenes in HeLa cervical carcinoma cells. Proceedings of the National Academy of Sciences. 2000. https://pmc.ncbi.nlm.nih.gov/articles/PMC18795/
[18] Whitaker AM, Schaich MA, Smith MR, Flynn TS, Freudenthal BD. Base excision repair of oxidative DNA damage. DNA Repair. 2017. https://pmc.ncbi.nlm.nih.gov/articles/PMC5567671/
[19] David SS, OShea VL, Kundu S. Base-excision repair of oxidative DNA damage. Nature. 2007. https://pmc.ncbi.nlm.nih.gov/articles/PMC2896554/
[20] Kim YJ, Wilson DM. Overview of base excision repair biochemistry. Current Molecular Pharmacology. 2012. https://pmc.ncbi.nlm.nih.gov/articles/PMC3459583/
[21] Kinner A, Wu W, Staudt C, Iliakis G. gamma-H2AX in recognition and signaling of DNA double-strand breaks. Nucleic Acids Research. 2008;36(17):5678-5694.
[22] Oizumi T, et al. Repair kinetics of DNA double-strand breaks induced by radiation in cancer and normal cells. 2020. https://pmc.ncbi.nlm.nih.gov/articles/PMC7763067/
[23] Cho E, Allemang A, Audebert M, et al. OECD Series on Adverse Outcome Pathways No. 29: Oxidative DNA damage leading to chromosomal aberrations and mutations. OECD. 2023. https://www.oecd.org/en/publications/oxidative-dna-damage-leading-to-chromosomal-aberrations-and-mutations_399d2c34-en.html
[24] Smith CC, ODonovan MR, Martin EA. hOGG1 recognizes oxidative damage using the comet assay with greater specificity than FPG or ENDOIII. Mutagenesis. 2006;21(3):185-190.
[25] Tsherniak A, et al. Defining a cancer dependency map. Cell. 2017;170(3):564-576.
[26] Ghandi M, et al. Next-generation characterization of the Cancer Cell Line Encyclopedia. Nature. 2019;569:503-508.
