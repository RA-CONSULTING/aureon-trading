import os, json, csv, math, shutil, zipfile, textwrap
from datetime import date
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION, WD_ORIENT
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.style import WD_STYLE_TYPE

OUT = Path('/mnt/data')
FIG = OUT / 'hnc_whitepaper_figures'
FIG.mkdir(exist_ok=True)

# Load existing artifacts
conv = pd.read_csv(OUT/'hnc_cancer_conversion_table_v03.csv')
cell = pd.read_csv(OUT/'hnc_cancer_cell_model_matrix_v03.csv')
control = pd.read_csv(OUT/'hnc_cancer_control_matrix_v03.csv')
with open(OUT/'hnc_cancer_packet_spec_v03.json') as f:
    spec = json.load(f)
base = spec.get('base_packet', {})
freqs = base.get('modulation_frequencies_hz', [])
nodes = base.get('coherence_nodes_hz', [])

# ------------------ Figures ------------------
# Figure 1: pipeline flow
plt.figure(figsize=(10, 3.2))
ax = plt.gca()
ax.axis('off')
steps = [
    'Open plant\nspectral peaks',
    'Frequency\nconversion',
    'Octave\ndownconversion',
    'Adjacent\nsidebands',
    '660 nm physical\ncarrier',
    'Cell stress\nassays',
    'Falsify or\nadvance claim'
]
xs = [0.02, 0.16, 0.30, 0.44, 0.58, 0.72, 0.86]
for i, (x, label) in enumerate(zip(xs, steps)):
    box = FancyBboxPatch((x, 0.42), 0.12, 0.24, boxstyle='round,pad=0.02', linewidth=1.3, facecolor='white', edgecolor='black')
    ax.add_patch(box)
    ax.text(x+0.06, 0.54, label, ha='center', va='center', fontsize=9)
    if i < len(xs)-1:
        ax.text((x+0.13 + xs[i+1]-0.01)/2, 0.54, '->', ha='center', va='center', fontsize=11)
ax.text(0.5, 0.18, 'Computational spectral packet design becomes biological only after delivery through a controlled physical carrier.', ha='center', fontsize=9)
plt.tight_layout()
fig1 = FIG/'figure1_pipeline.png'
plt.savefig(fig1, dpi=220, bbox_inches='tight')
plt.close()

# Figure 2: frequency cluster plot
plt.figure(figsize=(10, 3.4))
ax = plt.gca()
# keep default colors only
for _, row in conv.iterrows():
    x = row['modulation_frequency_hz']
    ax.axvline(x, ymin=0.15, ymax=0.85, linewidth=1)
    label = row['molecule'].split()[0][:5] + f"\n{int(row['peak_value'])}{row['unit'].replace('^-1','-1')}"
    ax.text(x, 0.88, label, rotation=90, va='bottom', ha='center', fontsize=6.5)
for node in nodes[:3]:
    lo, hi = node.get('low_hz'), node.get('high_hz')
    if lo and hi:
        ax.axvspan(lo, hi, alpha=0.12)
ax.set_xlim(950, 1880)
ax.set_ylim(0, 1.08)
ax.set_yticks([])
ax.set_xlabel('HNC packet modulation frequency after octave downconversion (Hz)')
ax.set_title('Phenolic coherence packet: converted dandelion biomolecule peaks')
plt.tight_layout()
fig2 = FIG/'figure2_frequency_cluster.png'
plt.savefig(fig2, dpi=220, bbox_inches='tight')
plt.close()

# Figure 3: experimental arms simplified
plt.figure(figsize=(10, 3.6))
ax=plt.gca(); ax.axis('off')
text = "Baseline -> Stressor -> Molecule / Carrier / Random packet / HNC packet -> DNA damage and repair endpoints\n\nDecisive test: Arm H (stressor + dandelion molecules + HNC packet) must outperform Arm C, D, E, and G without being explained by cell death, heating, or random/scrambled modulation."
ax.text(0.5,0.65,text,ha='center',va='center',fontsize=10,bbox=dict(boxstyle='round,pad=0.5', facecolor='white', edgecolor='black'))
plt.tight_layout()
fig3=FIG/'figure3_decisive_test.png'
plt.savefig(fig3, dpi=220, bbox_inches='tight')
plt.close()

# ------------------ Document helpers ------------------
def set_cell_shading(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), fill)
    tcPr.append(shd)

def set_cell_text(cell, text, bold=False, font_size=8):
    cell.text = ''
    p = cell.paragraphs[0]
    run = p.add_run(str(text))
    run.bold = bold
    run.font.size = Pt(font_size)

def set_table_borders(table):
    tbl = table._tbl
    tblPr = tbl.tblPr
    borders = OxmlElement('w:tblBorders')
    for edge in ('top','left','bottom','right','insideH','insideV'):
        tag = 'w:' + edge
        element = OxmlElement(tag)
        element.set(qn('w:val'), 'single')
        element.set(qn('w:sz'), '4')
        element.set(qn('w:space'), '0')
        element.set(qn('w:color'), 'BFBFBF')
        borders.append(element)
    tblPr.append(borders)

def add_table(doc, headers, rows, caption=None, font_size=8, header_fill='D9EAF7'):
    if caption:
        p = doc.add_paragraph()
        p.style = 'Caption'
        p.add_run(caption)
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = 'Table Grid'
    hdr = table.rows[0].cells
    for i,h in enumerate(headers):
        set_cell_text(hdr[i], h, bold=True, font_size=font_size)
        set_cell_shading(hdr[i], header_fill)
        hdr[i].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    for row in rows:
        cells = table.add_row().cells
        for i,val in enumerate(row):
            set_cell_text(cells[i], val, font_size=font_size)
            cells[i].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
    set_table_borders(table)
    for row in table.rows:
        for cell in row.cells:
            for p in cell.paragraphs:
                p.paragraph_format.space_after = Pt(0)
    return table

def add_bullet(doc, text, level=0):
    p = doc.add_paragraph(style='List Bullet' if level==0 else 'List Bullet 2')
    p.add_run(text)
    return p

def add_number(doc, text, level=0):
    p = doc.add_paragraph(style='List Number' if level==0 else 'List Number 2')
    p.add_run(text)
    return p

def add_code_block(doc, text):
    p = doc.add_paragraph()
    p.style = 'CodeBlock'
    run = p.add_run(text)
    run.font.name = 'Consolas'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Consolas')
    return p

# ------------------ Build document ------------------
doc = Document()
sec = doc.sections[0]
sec.top_margin = Inches(0.7)
sec.bottom_margin = Inches(0.65)
sec.left_margin = Inches(0.7)
sec.right_margin = Inches(0.7)

styles = doc.styles
styles['Normal'].font.name = 'Arial'
styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), 'Arial')
styles['Normal'].font.size = Pt(10)
for s in ['Heading 1','Heading 2','Heading 3','Title','Subtitle']:
    styles[s].font.name = 'Arial'
    styles[s]._element.rPr.rFonts.set(qn('w:eastAsia'), 'Arial')
try:
    code_style = styles.add_style('CodeBlock', WD_STYLE_TYPE.PARAGRAPH)
    code_style.font.name = 'Consolas'
    code_style._element.rPr.rFonts.set(qn('w:eastAsia'), 'Consolas')
    code_style.font.size = Pt(8)
    code_style.paragraph_format.left_indent = Inches(0.2)
    code_style.paragraph_format.space_before = Pt(3)
    code_style.paragraph_format.space_after = Pt(3)
except Exception:
    pass
styles['Caption'].font.name = 'Arial'
styles['Caption'].font.size = Pt(8)
styles['Caption'].font.italic = True

# Footer page number fields
footer = sec.footer.paragraphs[0]
footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
footer.add_run('HNC BioMolecule Packet White Paper v1.0 - Page ')
run = footer.add_run()
fldChar1 = OxmlElement('w:fldChar'); fldChar1.set(qn('w:fldCharType'), 'begin')
instrText = OxmlElement('w:instrText'); instrText.set(qn('xml:space'), 'preserve'); instrText.text = 'PAGE'
fldChar2 = OxmlElement('w:fldChar'); fldChar2.set(qn('w:fldCharType'), 'end')
run._r.append(fldChar1); run._r.append(instrText); run._r.append(fldChar2)

# Title page
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('A Falsifiable HNC Biomolecule-to-Frequency Packet Hypothesis\n')
r.bold = True; r.font.size = Pt(20)
r2 = p.add_run('for Modulating Oxidative DNA-Damage Markers in Normal and Cancer Cell Models')
r2.bold = True; r2.font.size = Pt(16)

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('White Paper / Pre-Experimental Validation Protocol')
r.italic=True; r.font.size=Pt(12)

for text in [
    'Framework: HNC BioMolecule -> Adjacent Frequency Packet Blueprint',
    'Working Version: v1.0 white paper compiled from v0.2 biomolecule packet and v0.3 cancer open-data layer',
    'Prepared for: R&A Consulting and Brokerage Services Ltd / Aureon Institute',
    'HNC Certificate: HNC-VER-2025-0407-001',
    'Date: 7 July 2026',
]:
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.add_run(text)

doc.add_paragraph()
p=doc.add_paragraph()
p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('Claim boundary')
r.bold=True
p=doc.add_paragraph()
p.alignment=WD_ALIGN_PARAGRAPH.CENTER
p.add_run('This paper reports a computationally reproducible spectral-packet design and a falsifiable in-vitro testing plan. It does not report completed wet-lab results, does not make a clinical claim, and does not claim DNA sequence rebuilding unless future sequencing confirms restoration of a defined allele after treatment.')

doc.add_page_break()

# Abstract
h=doc.add_heading('Abstract', level=1)
abstract = (
    'This white paper formalizes the HNC BioMolecule -> Adjacent Frequency Packet framework as a testable hypothesis rather than a therapeutic claim. '
    'The framework maps published spectral features of dandelion-associated phenolics - chlorogenic acid, chicoric acid and luteolin - into a reproducible modulation-frequency packet through physical frequency conversion, octave downconversion and adjacent sideband generation. '
    'The computational discovery is a 13-tone phenolic coherence packet spanning 1012.1-1817.7 Hz, with densest convergence in the 1367.2-1439.6 Hz region, generated from independent FTIR/Raman/UV-visible peaks. '
    'The proposed biological test uses a 660 nm red-light carrier with amplitude modulation and a 10-arm control structure to determine whether the HNC packet adds signal specificity beyond phytochemistry, carrier effects and randomized/scrambled modulation. '
    'Primary endpoints are ROS, 8-oxodG, alkaline and enzyme-modified comet assay, gamma-H2AX/53BP1 kinetics, and base-excision-repair markers including OGG1, APE1/APEX1 and XRCC1. '
    'The cancer open-data layer selects A549, HCT116 and MCF-7 as priority transformed models, with HeLa reserved as an HPV/p53-rewired context, using DepMap/CCLE/Sanger resources for baseline molecular annotation. '
    'The hypothesis is falsified if the full HNC arm does not outperform molecule-only, carrier-only, random-packet and molecule-plus-random-packet controls, or if apparent DNA-damage reduction is explained by cell death, temperature, batch effects or nonspecific photobiomodulation. '
    'DNA rebuilding remains a Level 4 claim requiring targeted or single-cell sequencing evidence of restoration and persistence of a defined sequence variant.'
)
doc.add_paragraph(abstract)
p=doc.add_paragraph(); p.add_run('Keywords: ').bold=True; p.add_run('Taraxacum officinale; chlorogenic acid; chicoric acid; luteolin; spectral conversion; photobiomodulation; oxidative DNA damage; gamma-H2AX; comet assay; DepMap; cancer cell lines; falsifiable hypothesis.')

# Executive summary
h=doc.add_heading('Executive Summary: What Has Been Discovered and What Has Not', level=1)
rows = [
    ['Computationally discovered', 'Published biomolecular spectral peaks can be converted into a reproducible 13-tone HNC phenolic coherence packet. Two dense convergence bands were detected: 1367.2-1402.1 Hz and 1398.6-1439.6 Hz.'],
    ['Scientifically testable', 'A 660 nm carrier can be amplitude-modulated by this packet and tested against sham, carrier-only, random-packet and molecule-only controls in normal and cancer cell models.'],
    ['Not yet discovered', 'No wet-lab evidence has yet shown that the packet reduces DNA damage, accelerates repair or restores sequence mutations.'],
    ['Claim ceiling before experiments', 'The present claim is computational reproducibility and experimental readiness. DNA protection, repair modulation, mutation prevention and DNA rebuilding remain staged hypotheses.'],
]
add_table(doc, ['Layer', 'Finding / boundary'], rows, caption='Table 1. Discovery status and claim boundary.', font_size=8)

# Background
h=doc.add_heading('1. Background and Rationale', level=1)
doc.add_paragraph(
    'The originating biological question was whether plant resilience under synthetic signal pressure could be translated into a biomimetic framework for human-cell stress response. The formalized version does not infer human DNA effects directly from plant survival. Instead, it uses plant biomolecules as spectral templates and tests whether a physical carrier encoded with their converted spectral structure modulates measurable oxidative DNA-damage and repair markers.'
)
doc.add_paragraph(
    'Dandelion (Taraxacum officinale) is a suitable source plant because open literature describes phenolic acids, flavonoids, polysaccharides, sesquiterpene lactones, sterols and triterpenes across plant organs, with chlorogenic, caffeic, p-coumaric, sinapic, ferulic and chicoric acids reported in HPLC-based studies [1,2]. A 2025 Food & Function study further identified chicoric, caftaric, chlorogenic and caffeic acids in dandelion extracts and reported mitigation of H2O2-induced oxidative stress in HypoE22 hypothalamic cells [3].'
)
doc.add_paragraph(
    'The strongest physical-carrier bridge is red/near-infrared photobiomodulation rather than UV exposure. PBM literature commonly discusses red/NIR windows around 600-700 nm and 780-1100 nm and proposes mitochondrial, redox and transcriptional mechanisms [7]. A visible red-light study in normal human dermal fibroblasts reported enhancement of GADD45A-mediated DNA repair activity after UV-induced oxidative damage [8]. These papers motivate the carrier but do not validate the HNC conversion algorithm; that validation requires the controls defined below.'
)

# Conceptual model
h=doc.add_heading('2. Conceptual Model', level=1)
doc.add_paragraph('The HNC framework is treated here as a signal-architecture hypothesis. It becomes biologically testable only after conversion into a physical carrier and a measurable cellular endpoint.')
doc.add_picture(str(fig1), width=Inches(6.5))
p=doc.add_paragraph(); p.style='Caption'; p.add_run('Figure 1. Operational HNC pipeline from open spectral inputs to falsifiable cell-assay outcomes.')

add_code_block(doc, 'Published molecule spectrum -> molecular frequency -> octave-downconverted modulation frequency -> adjacent packet -> physical carrier -> cell stress assay -> statistical falsification or advancement of claim level')

# Conversion math
h=doc.add_heading('3. Spectral Conversion Rules', level=1)
doc.add_paragraph('For FTIR/Raman wavenumbers in cm^-1:')
add_code_block(doc, 'molecular_frequency_THz = wavenumber_cm^-1 * 0.0299792458\ninfrared_wavelength_um = 10000 / wavenumber_cm^-1')
doc.add_paragraph('For UV-visible wavelengths in nm:')
add_code_block(doc, 'molecular_frequency_THz = 299792.458 / wavelength_nm')
doc.add_paragraph('For octave downconversion into an experimentally convenient modulation band:')
add_code_block(doc, 'packet_frequency_Hz = molecular_frequency_Hz / 2^N\nSelect N so packet_frequency_Hz falls within the pre-specified target band, here 1000-2000 Hz.')
doc.add_paragraph('Adjacent packets are generated as narrow sidebands and HNC geometric sidebands:')
add_code_block(doc, 'narrow sidebands = f0 * [0.99, 1.00, 1.01]\ngeometric sidebands = f0 * [1 - phi^-9, 1.00, 1 + phi^-9]\nphi = 1.618033988749895; phi^-9 ~= 0.0132')

# Spectral basis
h=doc.add_heading('4. Open Spectral Inputs', level=1)
doc.add_paragraph(
    'The v0.2/v0.3 pipeline uses open spectral data. Chlorogenic-acid Raman/IR features at 1603, 1632, 1160 and 1444 cm^-1 are anchored to a 2025 Frontiers in Chemistry Raman/IR study [4]. Chicoric-acid UV-visible conversion uses a maximum near 330 nm and a 300 nm shoulder reported in a Frontiers review [5]. Luteolin spectral assignments use DFT/spectral literature reporting OH, carbonyl and aromatic skeletal vibration regions [6].'
)
# conversion table selected all
conv_rows=[]
for _,r in conv.iterrows():
    conv_rows.append([r['molecule'], f"{r['peak_value']:g} {r['unit']}", r['assignment'], int(r['selected_octaves']), f"{r['modulation_frequency_hz']:.1f}"])
add_table(doc, ['Molecule', 'Peak', 'Assignment', 'Octaves', 'Packet Hz'], conv_rows, caption='Table 2. Conversion table for the HNC phenolic coherence packet.', font_size=7)

doc.add_picture(str(fig2), width=Inches(6.5))
p=doc.add_paragraph(); p.style='Caption'; p.add_run('Figure 2. Converted packet frequencies and detected convergence regions.')

# Packet spec
h=doc.add_heading('5. HNC Phenolic Coherence Packet Specification', level=1)
rows=[
    ['Packet ID', base.get('packet_id','HNC-1E2C1999D7')],
    ['Plant template', 'Taraxacum officinale, leaf/root mixed extract'],
    ['Molecules', ', '.join(base.get('molecules',['chlorogenic acid','chicoric acid','luteolin']))],
    ['Carrier', '660 nm red light, amplitude modulated; carrier-only and sham controls required'],
    ['Core frequencies', ', '.join([f'{x:.1f} Hz' for x in freqs])],
    ['Duty cycle', str(base.get('duty_cycle','0.618034'))],
    ['Phase pattern', str(base.get('phase_pattern','golden_ratio'))],
    ['Claim ceiling before biological data', 'Computational packet generation and experimental readiness only'],
]
add_table(doc, ['Field', 'Value'], rows, caption='Table 3. Primary HNC packet specification.', font_size=8)

node_rows=[]
for n in nodes[:3]:
    node_rows.append([f"{n['low_hz']:.1f}-{n['high_hz']:.1f}", f"{n['center_hz']:.1f}", str(n['n_peaks']), ', '.join(n['molecules'])])
add_table(doc, ['Coherence range (Hz)', 'Center (Hz)', 'Peaks', 'Molecules'], node_rows, caption='Table 4. Highest-density coherence nodes detected by v0.3.', font_size=8)

# Hypotheses
h=doc.add_heading('6. Falsifiable Hypotheses', level=1)
hyp_rows = [
    ['H0 - null', 'The HNC packet has no specific biological effect. Arm H is indistinguishable from molecule-only, carrier-only, random-packet and molecule-plus-random-packet controls on pre-specified DNA-damage and repair endpoints.'],
    ['H1 - DNA protection', 'In stressed cells, Arm H reduces a composite DNA-damage score more than Arms C, D, E and G while preserving viability and temperature equivalence.'],
    ['H2 - repair modulation', 'Arm H accelerates resolution of gamma-H2AX/53BP1 foci and modulates OGG1, APE1/APEX1, XRCC1, PARP1, GADD45A and NRF2-associated transcripts/proteins relative to controls.'],
    ['H3 - cancer-context modulation', 'Effect size and direction differ between normal cells and transformed lines according to baseline NRF2/DNA-repair state. A549, HCT116 and MCF-7 are priority transformed models.'],
    ['H4 - DNA rebuilding candidate', 'A Level 4 claim is allowed only if targeted UMI sequencing or single-cell sequencing shows restoration of a defined sequence variant above background and persistence after clonal expansion.'],
]
add_table(doc, ['Hypothesis', 'Falsifiable statement'], hyp_rows, caption='Table 5. Hypothesis set and claim tiers.', font_size=8)

doc.add_paragraph('Primary falsification conditions:')
for item in [
    'Arm H does not outperform Arm C or Arm G on primary endpoints after correction for multiple comparisons.',
    'Random or scrambled packets produce the same effect size as the HNC packet.',
    'The apparent effect is explained by >10-15% excess cell death, thermal drift, irradiance mismatch, batch effects or differential media conditions.',
    'DNA-damage markers change but sequencing does not show restoration of a defined variant; in that case DNA rebuilding must not be claimed.'
]:
    add_bullet(doc, item)

# Experimental design
h=doc.add_heading('7. Experimental Design', level=1)
doc.add_picture(str(fig3), width=Inches(6.5))
p=doc.add_paragraph(); p.style='Caption'; p.add_run('Figure 3. Decisive experimental comparison logic.')

# control table condensed
ctrl_rows=[]
for _,r in control.iterrows():
    ctrl_rows.append([r.get('arm_id',''), r.get('description',''), r.get('purpose','')])
add_table(doc, ['Arm', 'Description', 'Purpose'], ctrl_rows, caption='Table 6. Ten-arm control matrix.', font_size=7)

doc.add_paragraph('Recommended normal-cell models: primary human dermal fibroblasts and/or human keratinocytes. Recommended first transformed models: A549, HCT116 and MCF-7. The first stressor should be H2O2 titrated per line to produce robust DNA-damage markers while preserving enough viability to interpret repair kinetics, typically by pre-test dose-response rather than a fixed universal concentration.')

# Cancer model table
h=doc.add_heading('8. Cancer Open-Data Layer', level=1)
doc.add_paragraph(
    'Cancer cells are not chosen because reduced DNA damage would be therapeutically favorable. They are chosen because their redox state, checkpoint architecture and DNA-repair wiring are often abnormal, creating a stringent mechanistic test of signal specificity. Public DepMap/CCLE/Sanger resources provide baseline mutation, expression, dependency and lineage annotation for model selection [10-13].'
)
doc.add_page_break()
cell_rows=[]
for _,r in cell.iterrows():
    if r['model'] in ['A549','HCT116','MCF7','HeLa']:
        cell_rows.append([r['model'], r['depmap_id'], r['ccle_name'], r['biological_rationale'], r['baseline_hypothesis']])
add_table(doc, ['Model', 'DepMap ID', 'CCLE name', 'Rationale', 'Baseline hypothesis'], cell_rows, caption='Table 7. Cancer-cell model selection matrix.', font_size=6.8)

doc.add_paragraph('Model-specific interpretation controls:')
for item in [
    'A549 tests KEAP1/NRF2-high redox adaptation; high baseline NRF2 may blunt further antioxidant-response induction [14].',
    'HCT116 separates mismatch-repair deficiency from p53-competent DNA-damage/cell-cycle behavior [15].',
    'MCF-7 requires apoptosis readouts beyond caspase-3 because CASP3 is deficient in this line [16].',
    'HeLa is a reserve HPV-transformed model in which E6/E7 biology can distort p53/Rb pathway interpretation [17].'
]:
    add_bullet(doc, item)

# Endpoints and methods
h=doc.add_heading('9. Primary Endpoints and Assay Readout', level=1)
endpoint_rows=[
    ['Redox', 'ROS/DCFDA, mitochondrial ROS, GSH/GSSG, NFE2L2, KEAP1, HMOX1/HO-1, NQO1', 'Determines whether packet changes redox stress before DNA markers shift.'],
    ['DNA damage', '8-oxodG, alkaline comet tail moment, hOGG1/Fpg-modified comet, gamma-H2AX and 53BP1 foci', 'Tracks oxidative base damage, strand breaks and double-strand-break signaling.'],
    ['DNA repair', 'OGG1, APE1/APEX1, XRCC1, PARP1, GADD45A, RAD51, BRCA1, TP53, CDKN1A', 'Determines whether lesion clearance and repair-associated signaling change over time.'],
    ['Cell fate', 'Viability, apoptosis/annexin V-PI, PARP cleavage, cell-cycle, senescence', 'Rules out false marker reduction due to cell death or growth arrest.'],
    ['Sequence restoration', 'Targeted UMI sequencing, single-cell sequencing, clonal persistence', 'Only route to a DNA rebuilding candidate claim.'],
]
add_table(doc, ['Endpoint family', 'Markers / assays', 'Interpretation role'], endpoint_rows, caption='Table 8. Endpoint families and interpretation rules.', font_size=7.4)
doc.add_paragraph(
    'Base excision repair is the primary pathway for many oxidative base lesions, including 8-oxoguanine; OGG1, APE1, PARP1 and XRCC1 are therefore central readouts [18-20]. Gamma-H2AX/53BP1 foci are used as DNA double-strand-break and repair-kinetic markers [21,22]. OECD AOP 296 links oxidative DNA damage to chromosomal aberrations and mutations and supports oxidative-lesion and comet-style endpoints as regulatory-relevant evidence streams [23].'
)

# Stats
h=doc.add_heading('10. Statistical Analysis Plan', level=1)
doc.add_paragraph('Pre-specify a primary composite DNA-damage score to prevent endpoint shopping:')
add_code_block(doc, 'Composite_DNA_Damage_Z = mean(z(8-oxodG), z(comet_tail_moment), z(gamma-H2AX_foci), z(53BP1_foci))')
doc.add_paragraph('Recommended model:')
add_code_block(doc, 'endpoint ~ arm * timepoint * cell_line + batch + baseline_damage + viability + temperature + (1 | experiment_day)')
for item in [
    'Primary comparison: Arm H versus C, D, E and G at matched timepoints using planned contrasts with Holm or Benjamini-Hochberg correction.',
    'Minimum pilot: at least three independent biological experiments; stronger design: n=4-6 independent experiments per line with technical replicates nested within biological replicate.',
    'Effect-size gate for progression: H vs G standardized mean difference at least 0.3 on the composite score, or a pre-specified 15-20% reduction in key DNA-damage endpoints without excess viability loss.',
    'Thermal and irradiance controls: plate temperature, optical power density and duty cycle must be logged for every exposure.',
    'Blinding: waveform file labels should be blinded to the operator and image analyst.'
]:
    add_bullet(doc, item)

# Claim levels
h=doc.add_heading('11. Claim-Level Decision Tree', level=1)
claim_rows=[
    ['Level 1 - DNA protection', 'Lower 8-oxodG/comet/gamma-H2AX after stress versus controls', 'May claim DNA-damage reduction/protection in cell model only.'],
    ['Level 2 - Repair modulation', 'Faster marker resolution plus repair-gene/protein kinetics', 'May claim repair-pathway modulation.'],
    ['Level 3 - Mutation prevention', 'Lower micronucleus or mutation frequency after genotoxic stress', 'May claim mutation-prevention tendency in model.'],
    ['Level 4 - DNA rebuilding candidate', 'Sequencing-confirmed restoration of a defined variant and persistence after cell division', 'May investigate DNA rebuilding mechanism; replication required.'],
]
add_table(doc, ['Claim level', 'Evidence required', 'Allowed interpretation'], claim_rows, caption='Table 9. Evidence ladder for responsible interpretation.', font_size=8)

# Limitations
h=doc.add_heading('12. Limitations and Risk Controls', level=1)
for item in [
    'Frequency conversion is a hypothesis-generating encoding, not proof that cells recognize a molecule-derived harmonic signature.',
    'A 660 nm carrier has its own PBM biology; random and scrambled controls are mandatory to distinguish HNC structure from nonspecific photobiomodulation.',
    'Polyphenols can act as antioxidants or pro-oxidants depending on concentration, metal context, cell line and stressor dose; dose-response curves are mandatory.',
    'Cancer-cell DNA-damage reduction may be mechanistically interesting but could also protect malignant cells; no therapeutic conclusion follows from a reduced marker alone.',
    'DNA rebuilding is not inferred from reduced oxidative markers; it requires direct sequencing evidence.'
]:
    add_bullet(doc, item)

# Data package
h=doc.add_heading('13. Data and Code Package', level=1)
doc.add_paragraph('The white paper is linked to a reproducible local package generated during framework development:')
file_rows=[]
for fname, role in [
    ('hnc_biomolecule_packet_v02.py','Biomolecule packet engine with adaptive octave conversion'),
    ('hnc_biopacket_phenolic_coherence_v02.json','Primary v0.2 phenolic coherence packet'),
    ('hnc_conversion_table_v02.csv','Core v0.2 conversion table'),
    ('hnc_biomolecule_packet_v03_cancer.py','Cancer open-data layer engine'),
    ('hnc_cancer_packet_spec_v03.json','Full v0.3 cancer packet and model specification'),
    ('hnc_cancer_conversion_table_v03.csv','Cancer-layer conversion table used in this paper'),
    ('hnc_cancer_cell_model_matrix_v03.csv','Cell-line selection matrix'),
    ('hnc_cancer_control_matrix_v03.csv','Ten-arm experimental matrix'),
    ('hnc_cancer_public_data_hooks_v03.csv','DepMap/CCLE/Sanger/GEO public-data hooks'),
    ('hnc_cancer_random_frequency_control_v03.json','Random control waveform specification'),
    ('hnc_cancer_scrambled_phase_control_v03.json','Scrambled phase control waveform specification'),
    ('hnc_cancer_validation_report_v03.json','Structural validation report'),
]:
    file_rows.append([fname, role])
add_table(doc, ['File', 'Role'], file_rows, caption='Table 10. Reproducibility package manifest.', font_size=7.2)

# Ethics and no clinical claims
h=doc.add_heading('14. Ethics, Biosafety and Non-Clinical Status', level=1)
doc.add_paragraph(
    'The proposed work is in-vitro and pre-clinical. It does not involve human subjects unless primary cells are newly collected, in which case institutional review and consent requirements apply. Cell lines require authentication, mycoplasma testing, passage-number control and biosafety compliance. Light exposure requires optical safety procedures and thermal monitoring. Nothing in this white paper should be interpreted as a recommendation for patient treatment, vaccine alteration, cancer therapy or home experimentation.'
)

# Conclusion
h=doc.add_heading('15. Conclusion', level=1)
doc.add_paragraph(
    'The HNC BioMolecule -> Adjacent Frequency Packet framework has reached a testable stage. The computational contribution is a reproducible transformation from open spectral biomolecule peaks to a structured 13-tone phenolic coherence packet, plus an open-data cancer-cell model layer and a pre-specified 10-arm falsification design. The next scientific step is not stronger assertion; it is blinded in-vitro testing against random, scrambled, carrier-only and molecule-only controls. The framework advances only if Arm H shows reproducible endpoint-specific effects not explained by nonspecific photobiomodulation, phytochemistry, cell death, heating or batch artifacts. DNA rebuilding remains a separate and higher claim requiring direct sequence restoration evidence.'
)

# References
h=doc.add_heading('References', level=1)
refs = [
    'Rhayem L, et al. Bioactive Compounds from Dandelion (Taraxacum officinale). Foods. 2026;15(4):782. https://www.mdpi.com/2304-8158/15/4/782',
    'Tanasa MV, et al. Bioactive Compounds from Vegetal Organs of Taraxacum officinale. International Journal of Molecular Sciences. 2025;26(2):450. https://www.mdpi.com/1422-0067/26/2/450',
    'Masciulli F, et al. Phytochemical composition and bioactivity of edible Taraxacum officinale: potential as an ingredient in brain health-oriented functional foods. Food & Function. 2025. https://pubs.rsc.org/en/content/articlehtml/2025/fo/d5fo02646f',
    'Vershinina Y, et al. Raman and IR spectroscopy as a promising approach to rapid and non-destructive monitoring of chlorogenic acid in protein matrices. Frontiers in Chemistry. 2025;13:1543663. doi:10.3389/fchem.2025.1543663.',
    'Lee J, Scagel CF. Chicoric acid: chemistry, distribution, and production. Frontiers in Chemistry. 2013;1:40. doi:10.3389/fchem.2013.00040.',
    'Zheng Y, et al. Density Functional Theory Analysis of Luteolin Molecular Structure and Spectral Properties. 2026. https://pmc.ncbi.nlm.nih.gov/articles/PMC12878360/',
    'de Freitas LF, Hamblin MR. Proposed mechanisms of photobiomodulation or low-level light therapy. IEEE Journal of Selected Topics in Quantum Electronics. 2016;22(3). https://pmc.ncbi.nlm.nih.gov/articles/PMC5215870/',
    'Kim YJ, et al. A protective mechanism of visible red light in normal human dermal fibroblasts: enhancement of GADD45A-mediated DNA repair activity. Journal of Investigative Dermatology. 2017. https://pubmed.ncbi.nlm.nih.gov/27729279/',
    'Feng Y, et al. Photobiomodulation inhibits ischemia-induced brain endothelial senescence via endothelial nitric oxide synthase. Antioxidants. 2024;13:633. https://www.mdpi.com/2076-3921/13/6/633',
    'Broad Institute. DepMap Portal. Open access cancer dependency and cell-line characterization resource. https://depmap.org/',
    'Bioconductor. depmap: Cancer Dependency Map Data Package. Version 1.26.0, July 2026. https://www.bioconductor.org/packages/release/data/experiment/html/depmap.html',
    'AWS Open Data Registry. DepMap Cancer Cell Line Encyclopedia Omics Dataset. https://registry.opendata.aws/depmap-omics-ccle/',
    'Wellcome Sanger Institute. Cancer Dependency Map and Cell Model Passports datasets. https://depmap.sanger.ac.uk/documentation/datasets/',
    'Gong M, et al. Loss-of-function mutations in KEAP1 drive lung cancer progression via KEAP1/NRF2 pathway activation. Cell Communication and Signaling. 2020. https://pmc.ncbi.nlm.nih.gov/articles/PMC7310414/',
    'Vikhanskaya F, et al. Cooperation between p53 and hMLH1 in a human colon cancer cell line HCT116. Clinical Cancer Research. 1999. https://pubmed.ncbi.nlm.nih.gov/10213232/',
    'Tian T, et al. MCF-7 cells lack the expression of caspase-3. 2023. https://pubmed.ncbi.nlm.nih.gov/36690238/',
    'Goodwin EC, DiMaio D. Repression of human papillomavirus oncogenes in HeLa cervical carcinoma cells. Proceedings of the National Academy of Sciences. 2000. https://pmc.ncbi.nlm.nih.gov/articles/PMC18795/',
    'Whitaker AM, Schaich MA, Smith MR, Flynn TS, Freudenthal BD. Base excision repair of oxidative DNA damage. DNA Repair. 2017. https://pmc.ncbi.nlm.nih.gov/articles/PMC5567671/',
    'David SS, OShea VL, Kundu S. Base-excision repair of oxidative DNA damage. Nature. 2007. https://pmc.ncbi.nlm.nih.gov/articles/PMC2896554/',
    'Kim YJ, Wilson DM. Overview of base excision repair biochemistry. Current Molecular Pharmacology. 2012. https://pmc.ncbi.nlm.nih.gov/articles/PMC3459583/',
    'Kinner A, Wu W, Staudt C, Iliakis G. gamma-H2AX in recognition and signaling of DNA double-strand breaks. Nucleic Acids Research. 2008;36(17):5678-5694.',
    'Oizumi T, et al. Repair kinetics of DNA double-strand breaks induced by radiation in cancer and normal cells. 2020. https://pmc.ncbi.nlm.nih.gov/articles/PMC7763067/',
    'Cho E, Allemang A, Audebert M, et al. OECD Series on Adverse Outcome Pathways No. 29: Oxidative DNA damage leading to chromosomal aberrations and mutations. OECD. 2023. https://www.oecd.org/en/publications/oxidative-dna-damage-leading-to-chromosomal-aberrations-and-mutations_399d2c34-en.html',
    'Smith CC, ODonovan MR, Martin EA. hOGG1 recognizes oxidative damage using the comet assay with greater specificity than FPG or ENDOIII. Mutagenesis. 2006;21(3):185-190.',
    'Tsherniak A, et al. Defining a cancer dependency map. Cell. 2017;170(3):564-576.',
    'Ghandi M, et al. Next-generation characterization of the Cancer Cell Line Encyclopedia. Nature. 2019;569:503-508.'
]
for i, ref in enumerate(refs, start=1):
    p=doc.add_paragraph()
    p.paragraph_format.first_line_indent = Inches(-0.25)
    p.paragraph_format.left_indent = Inches(0.25)
    p.paragraph_format.space_after = Pt(1.5)
    p.add_run(f'[{i}] {ref}')

# Appendices
h=doc.add_heading('Appendix A. Minimal Preregistration Template', level=1)
for item in [
    'Primary hypothesis: Arm H reduces the composite DNA-damage score more than C, D, E and G under H2O2 stress.',
    'Primary endpoint: composite DNA-damage z-score at 1, 3, 6 and 24 h.',
    'Key exclusion: any well with contamination, temperature drift outside pre-specified tolerance or viability below the analysis floor.',
    'Primary models: one normal line and two transformed lines selected before packet exposure.',
    'Blinding: waveform identity blinded until image quantification and initial statistics are complete.',
    'Progression gate: H vs G passes effect-size and adjusted-p-value thresholds in two independent biological replicates before expansion.'
]:
    add_bullet(doc, item)

# metadata core properties
props = doc.core_properties
props.title = 'A Falsifiable HNC Biomolecule-to-Frequency Packet Hypothesis'
props.subject = 'HNC BioMolecule Adjacent Frequency Packet White Paper'
props.author = 'R&A Consulting and Brokerage Services Ltd / Aureon Institute'
props.keywords = 'HNC, dandelion, Taraxacum officinale, chlorogenic acid, chicoric acid, luteolin, DNA damage, photobiomodulation, DepMap'
props.comments = 'Generated as a peer-review-style white paper; pre-experimental, non-clinical.'

# Save
docx_path = OUT/'HNC_BioMolecule_Adjacent_Frequency_Packet_White_Paper_v1.docx'
doc.save(docx_path)

# Also save a markdown source version
md_path = OUT/'HNC_BioMolecule_Adjacent_Frequency_Packet_White_Paper_v1.md'
with open(md_path,'w') as f:
    f.write('# A Falsifiable HNC Biomolecule-to-Frequency Packet Hypothesis\n\n')
    f.write('This Markdown source mirrors the DOCX white paper at a high level. See DOCX/PDF for formatted tables and figures.\n\n')
    f.write('## Core packet frequencies\n\n')
    f.write(', '.join([f'{x:.1f} Hz' for x in freqs])+'\n\n')
    f.write('## Primary hypothesis\n\nArm H must outperform molecule-only, carrier-only, random-packet and molecule-plus-random-packet controls on pre-specified DNA-damage endpoints without being explained by cell death, heating or batch artifacts.\n\n')
    f.write('## References\n\n')
    for i, ref in enumerate(refs,1): f.write(f'[{i}] {ref}\n')

# Create ZIP package of source artifacts + white paper (PDF added later by caller)
print(docx_path)
