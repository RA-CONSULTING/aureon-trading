# HNC BioMolecule → Adjacent Frequency Packet Blueprint v0.3 Cancer Layer

## Scientific boundary

This design is for **in-vitro hypothesis testing** using public cancer-cell data as the model-selection and baseline layer. It does not make a clinical claim, and it does not prove DNA rebuilding. In cancer-cell models, reduced DNA-damage markers can indicate redox protection of transformed cells, altered DNA-damage response, or assay/viability effects; it is not automatically beneficial.

## Base HNC packet

- Packet ID: `HNC-1E2C1999D7`
- Carrier: `red_nir_light` at `660.0 nm`
- Duty cycle: `0.618034`
- Phase pattern: `golden_ratio`
- Claim ceiling at this stage: `dna_protection`

### Modulation frequencies

1012.1 Hz, 1259.9 Hz, 1367.2 Hz, 1380.3 Hz, 1390.8 Hz, 1398.6 Hz, 1402.1 Hz, 1417.0 Hz, 1423.9 Hz, 1439.6 Hz, 1577.1 Hz, 1652.5 Hz, 1817.7 Hz

### Detected coherence nodes

- `1380.3–1423.9 Hz`, center `1402.1 Hz`, peaks `6`, molecules: chlorogenic acid, luteolin
- `1367.2–1402.1 Hz`, center `1387.8 Hz`, peaks `5`, molecules: chlorogenic acid, luteolin
- `1398.6–1439.6 Hz`, center `1416.3 Hz`, peaks `5`, molecules: chicoric acid, chlorogenic acid, luteolin

## Priority cancer cell lines

### A549 — priority_1_nrf2_high_redox_model
- DepMap ID: `ACH-000681`; CCLE name: `A549_LUNG`
- Context: lung adenocarcinoma / NSCLC
- Rationale: KEAP1-mutant/NRF2-active context tests whether the HNC phenolic packet adds signal over an already redox-adapted cancer state.
- Baseline hypothesis: NRF2/HO-1/NQO1 may already be high; incremental NRF2 induction may be blunted while ROS and gamma-H2AX kinetics may still shift.
- Primary stressor: `hydrogen_peroxide_oxidative_stress`
- Timepoints: 0, 0.5, 1, 3, 6, 24 h
- Endpoints: ROS, GSH/GSSG, NFE2L2, HMOX1, NQO1, gamma-H2AX, 53BP1, comet_tail_moment, 8-oxodG, viability
- Cautions: High baseline NRF2 can mask antioxidant-response effects.; Reduced DNA damage in cancer cells is mechanistic, not automatically therapeutic.

### HCT116 — priority_1_dna_repair_rewired_luteolin_chicoric_model
- DepMap ID: `ACH-000971`; CCLE name: `HCT116_LARGE_INTESTINE`
- Context: colorectal carcinoma
- Rationale: Mismatch-repair-deficient but p53-competent colon model; strong literature connection to luteolin and chicoric acid effects.
- Baseline hypothesis: MMR deficiency and p53 responsiveness may separate DNA-damage marker reduction from apoptosis/cell-cycle effects.
- Primary stressor: `hydrogen_peroxide_oxidative_stress`
- Timepoints: 0, 0.5, 1, 3, 6, 24, 48 h
- Endpoints: gamma-H2AX, 53BP1, comet_tail_moment, 8-oxodG, TP53, CDKN1A, OGG1, APE1, XRCC1, RAD51, apoptosis, cell_cycle
- Cautions: Cell-fate endpoints can dominate over repair endpoints at high phytochemical doses.; Separate protection/repair from selective cancer cytotoxicity.

### MCF7 — priority_2_breast_polyphenol_cell_fate_model
- DepMap ID: `ACH-000019`; CCLE name: `MCF7_BREAST`
- Context: ER-positive breast carcinoma
- Rationale: Common breast cancer model for polyphenol response; useful for comparing redox/DNA damage endpoints against altered apoptosis execution.
- Baseline hypothesis: Caspase-3 deficiency means apoptosis interpretation requires PARP1, caspase-7, annexin V/PI, mitochondrial and cell-cycle readouts rather than CASP3 alone.
- Primary stressor: `hydrogen_peroxide_oxidative_stress`
- Timepoints: 0, 0.5, 1, 3, 6, 24 h
- Endpoints: ROS, 8-oxodG, gamma-H2AX, 53BP1, comet_tail_moment, PARP1, CASP7, BAX, BCL2, annexin_v_pi, cell_cycle
- Cautions: Do not use CASP3 alone as an apoptosis marker.; Estrogen-receptor context can affect polyphenol response.

## Reserve line

- **HeLa** (`ACH-001086`, `HELA_CERVIX`): HPV E6/E7 transformed context tests p53-impaired DNA-damage response under a viral-oncoprotein rewiring regime.

## 10-arm cancer-adapted experimental design

| Arm | Description | Purpose | Interpretation rule |
|---|---|---|---|
| A | No stressor, no molecule, no signal | baseline | Sets basal ROS/DNA-damage level per cancer line. |
| B | Stressor only | damage_control | Quantifies stressor-induced damage against baseline. |
| C | Stressor + standardized dandelion extract | chemical_biomolecule | Measures chemical phytomolecule effect without signal packet. |
| D | Stressor + 660 nm carrier only | carrier_effect | Measures carrier/PBM effect without HNC modulation. |
| E | Stressor + random-frequency packet | random_frequency_control | Tests nonspecific modulation without biomolecule-derived structure. |
| F | Stressor + HNC packet only | signal_only_hnc | Tests whether signal structure has effect without molecules. |
| G | Stressor + dandelion extract + random packet | molecule_plus_nonspecific_signal | Controls for molecule plus generic modulated light. |
| H | Stressor + dandelion extract + HNC packet | full_hypothesis | Primary hypothesis arm; must outperform C, D, E and G. |
| I | Stressor + purified luteolin/chlorogenic/chicoric acids + HNC packet | molecule_specific_validation | Deconvolves extract complexity. |
| J | Stressor + known assay-positive repair/protection control | assay_validation | Confirms the assay detects known modulation. |

## Decisive comparison

Arm **H** is the full hypothesis arm. It must outperform Arm C, Arm D, Arm E and Arm G on primary DNA-damage endpoints while not being explainable by viability loss alone. If H is not better than C or G, the HNC packet is not adding specificity beyond phytochemistry or nonspecific modulated-light effects.

## Public data hooks

- **DepMap Public / CCLE processed data**: Baseline mutation, copy-number, expression and dependency context for candidate cell lines. Access: Downloads -> All Data; use Model.csv plus OmicsExpressionProteinCodingGenesTPMLogp1*.csv, OmicsSomaticMutations.csv, OmicsCNGene.csv, CRISPRGeneEffect.csv where available.. Source: https://depmap.org/
- **Bioconductor depmap package**: Programmatic R/ExperimentHub access to current release; useful for reproducible public baseline tables. Access: R: library(depmap); use depmap_* functions for expression, mutation, copy number, CRISPR and metadata where supported.. Source: https://www.bioconductor.org/packages/release/data/experiment/html/depmap.html
- **AWS Open Data DepMap Omics CCLE raw files**: Raw RNA-seq/WES/WGS access when processed data are insufficient or exact sequence-level baselines are needed. Access: AWS CLI: aws s3 ls --no-sign-request s3://depmap-omics-ccle/. Source: https://registry.opendata.aws/depmap-omics-ccle/
- **Sanger Cell Model Passports / DepMap datasets**: Cross-check cell-line identity, lineage, mutation, expression, methylation, drug-sensitivity and CRISPR datasets. Access: Use Cell Model Passports or processed downloads/API by SIDM/Broad DepMap ID.. Source: https://depmap.sanger.ac.uk/documentation/datasets/
- **GEO line-specific oxidative/genotoxic stress studies**: Historical stress-response expression data for H2O2, UV, doxorubicin or etoposide exposure; use after priority line is fixed. Access: GEO search terms: '<cell line> H2O2 gamma H2AX', '<cell line> oxidative stress RNA-seq', '<cell line> doxorubicin DNA damage'. Validate manually before meta-analysis.. Source: https://www.ncbi.nlm.nih.gov/geo/

## Endpoint families

- **redox**: ROS/DCFDA, GSH/GSSG, mitochondrial membrane potential, NFE2L2, KEAP1, HMOX1, NQO1
- **dna_damage**: gamma-H2AX, 53BP1 foci, alkaline comet tail moment, Fpg/hOGG1-modified comet, 8-oxodG, micronucleus assay
- **dna_repair**: OGG1, APEX1/APE1, XRCC1, PARP1, RAD51, BRCA1, TP53, CDKN1A/p21
- **cell_fate**: viability, annexin V/PI, caspase activity as line-appropriate, PARP cleavage, cell cycle, senescence markers
- **sequencing**: targeted deep sequencing, amplicon UMI sequencing, single-cell sequencing optional, clonal persistence after expansion

## Claim boundary

- `lower_ROS_only` → redox modulation, not DNA repair
- `lower_8oxodG_or_comet_or_gammaH2AX` → DNA-damage reduction/protection claim
- `faster_gammaH2AX_53BP1_resolution_with_repair_gene_kinetics` → DNA-repair-pathway modulation claim
- `lower_micronucleus_or_mutation_frequency` → mutation-prevention claim
- `targeted_sequencing_restores_defined_variant_and_persists` → DNA rebuilding candidate claim
- `no_sequence_restoration` → do not claim DNA rebuilding

## Source URLs embedded in this spec

- `chlorogenic_frontiers_2025`: https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2025.1543663/full — Raman/FTIR monitoring of chlorogenic acid; includes 1603, 1632, 1160, and 1444 cm^-1 features.
- `chicoric_frontiers_2013`: https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2013.00040/full — Chicoric acid review; reports UV-visible maximum near 330 nm with 300 nm shoulder.
- `luteolin_acs_omega_2026`: https://pmc.ncbi.nlm.nih.gov/articles/PMC12878360/ — DFT/spectral analysis of luteolin; includes OH stretch, carbonyl, and aromatic skeletal vibrations.
- `depmap_portal`: https://depmap.org/ — Broad DepMap portal: open access cancer dependency and cell-line characterization resource.
- `ccle_datasets`: https://sites.broadinstitute.org/ccle/datasets — CCLE datasets page; points to DepMap as the current processed-data portal and lists RNA-seq, mutation and related data.
- `bioconductor_depmap_2026`: https://www.bioconductor.org/packages/release/data/experiment/html/depmap.html — Bioconductor depmap package for current DepMap data via ExperimentHub.
- `aws_depmap_omics_ccle`: https://registry.opendata.aws/depmap-omics-ccle/ — AWS Open Data registry: WGS/WES/RNA-seq files for roughly 1000 CCLE cancer cell lines.
- `sanger_depmap_datasets`: https://depmap.sanger.ac.uk/documentation/datasets/ — Sanger DepMap processed datasets: mutation, copy number, expression, methylation, proteomics, CRISPR dependencies and drug sensitivity.
- `gammah2ax_comet_2017`: https://www.sciencedirect.com/science/article/abs/pii/S138357181730092X — Comparison of gamma-H2AX foci and comet assays after genotoxicants including H2O2.
- `a549_keap1_nrf2`: https://www.sciencedirect.com/science/article/pii/S0891584923006275 — A549 model with loss-of-function KEAP1 context and constitutive NRF2 activation framing.
- `hct116_mlh1_p53`: https://link.springer.com/article/10.1186/1476-4598-3-11 — HCT116 is described with wild-type TP53 and DNA mismatch-repair deficiency due to lack of hMLH1 expression.
- `mcf7_caspase3`: https://pubmed.ncbi.nlm.nih.gov/36690238/ — MCF-7 cells lack caspase-3 due to a 47-bp deletion in CASP3 exon 3.
- `hela_hpv_p53`: https://www.nature.com/articles/s41467-024-45920-w — HPV16 E6/E6AP promotes degradation of p53; relevant to HPV-transformed cervical-line interpretation.
- `luteolin_anticancer_2022`: https://link.springer.com/article/10.1186/s12935-022-02808-3 — Luteolin review: antioxidant and pro-oxidant cancer-cell effects, including ROS-linked apoptosis.
- `chicoric_hct116_2025`: https://journals.sagepub.com/doi/10.1177/09731296241291625 — Chicoric acid HCT116 study reporting dose-dependent growth suppression, ROS generation, apoptosis and cell-cycle arrest.
