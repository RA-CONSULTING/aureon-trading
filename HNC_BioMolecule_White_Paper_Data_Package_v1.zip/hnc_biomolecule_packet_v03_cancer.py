#!/usr/bin/env python3
"""
HNC BioMolecule -> Adjacent Frequency Packet Blueprint v0.3 Cancer Layer
========================================================================
Extends v0.2 from plant biomolecule spectral signatures into cancer-cell
model selection, public data hooks, and cancer-specific experimental design.

Scientific boundary:
- This code builds signal hypotheses and experiment metadata.
- It does not prove biological efficacy, clinical utility, or DNA rebuilding.
- In cancer cells, reduced DNA-damage markers can mean altered stress response
  or protection of transformed cells; it is not automatically beneficial.
- DNA rebuilding claims require sequencing-confirmed restoration of a defined locus
  and persistence through cell division.

Author: R&A CONSULTING AND BROKERAGE SERVICES LTD
HNC Certificate: HNC-VER-2025-0407-001
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import random
from dataclasses import dataclass, asdict
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

# ============================================
# HNC MODEL CONSTANTS
# ============================================

PHI = 1.618033988749895
INV_PHI = 1.0 / PHI
PHI_INV_9 = PHI ** (-9)
SCHUMANN_BASE_HZ = 7.83
THZ_TO_HZ = 1.0e12
CM1_TO_THZ = 0.0299792458
NM_TO_THZ_NUMERATOR = 299_792.458
DEFAULT_TARGET_BAND_HZ = (1000.0, 2000.0)
DEFAULT_VALIDATION_BAND_HZ = (100.0, 5000.0)

# ============================================
# ENUMS
# ============================================

class CarrierType(Enum):
    RED_NIR_LIGHT = "red_nir_light"
    EM_FIELD = "em_field"
    ACOUSTIC = "acoustic"
    CHEMICAL = "chemical"


class PlantPart(Enum):
    FLOWER = "flower"
    STEM = "stem"
    ROOT = "root"
    LEAF = "leaf"
    MIXED = "mixed"


class ClaimLevel(Enum):
    LEVEL_1_PROTECTION = "dna_protection"
    LEVEL_2_REPAIR_ACCEL = "repair_acceleration"
    LEVEL_3_MUTATION_PREVENTION = "mutation_prevention"
    LEVEL_4_DNA_REBUILDING = "dna_rebuilding"


class SpectralMethod(Enum):
    FTIR = "ftir"
    RAMAN = "raman"
    UV_VIS = "uv_vis"
    NMR = "nmr"
    LC_MS = "lc_ms"
    DFT = "dft"


class CancerCellModel(Enum):
    A549 = "A549"
    HCT116 = "HCT116"
    MCF7 = "MCF7"
    HELA = "HeLa"


class StressorType(Enum):
    H2O2 = "hydrogen_peroxide_oxidative_stress"
    UV = "uv_damage"
    DOXORUBICIN = "doxorubicin_topoisomerase_dsb_stress"
    ETOPOSIDE = "etoposide_topoisomerase_dsb_stress"
    CYTOKINE_MIX = "inflammatory_cytokine_mix"


class EndpointFamily(Enum):
    REDOX = "redox"
    DNA_DAMAGE = "dna_damage"
    DNA_REPAIR = "dna_repair"
    CELL_FATE = "cell_fate"
    SEQUENCING = "sequencing"


# ============================================
# SOURCE REFERENCES
# ============================================

@dataclass(frozen=True)
class SourceRef:
    key: str
    url: str
    note: str


SOURCE_REFS: Dict[str, SourceRef] = {
    "chlorogenic_frontiers_2025": SourceRef(
        key="chlorogenic_frontiers_2025",
        url="https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2025.1543663/full",
        note="Raman/FTIR monitoring of chlorogenic acid; includes 1603, 1632, 1160, and 1444 cm^-1 features."
    ),
    "chicoric_frontiers_2013": SourceRef(
        key="chicoric_frontiers_2013",
        url="https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2013.00040/full",
        note="Chicoric acid review; reports UV-visible maximum near 330 nm with 300 nm shoulder."
    ),
    "luteolin_acs_omega_2026": SourceRef(
        key="luteolin_acs_omega_2026",
        url="https://pmc.ncbi.nlm.nih.gov/articles/PMC12878360/",
        note="DFT/spectral analysis of luteolin; includes OH stretch, carbonyl, and aromatic skeletal vibrations."
    ),
    "depmap_portal": SourceRef(
        key="depmap_portal",
        url="https://depmap.org/",
        note="Broad DepMap portal: open access cancer dependency and cell-line characterization resource."
    ),
    "ccle_datasets": SourceRef(
        key="ccle_datasets",
        url="https://sites.broadinstitute.org/ccle/datasets",
        note="CCLE datasets page; points to DepMap as the current processed-data portal and lists RNA-seq, mutation and related data."
    ),
    "bioconductor_depmap_2026": SourceRef(
        key="bioconductor_depmap_2026",
        url="https://www.bioconductor.org/packages/release/data/experiment/html/depmap.html",
        note="Bioconductor depmap package for current DepMap data via ExperimentHub."
    ),
    "aws_depmap_omics_ccle": SourceRef(
        key="aws_depmap_omics_ccle",
        url="https://registry.opendata.aws/depmap-omics-ccle/",
        note="AWS Open Data registry: WGS/WES/RNA-seq files for roughly 1000 CCLE cancer cell lines."
    ),
    "sanger_depmap_datasets": SourceRef(
        key="sanger_depmap_datasets",
        url="https://depmap.sanger.ac.uk/documentation/datasets/",
        note="Sanger DepMap processed datasets: mutation, copy number, expression, methylation, proteomics, CRISPR dependencies and drug sensitivity."
    ),
    "gammah2ax_comet_2017": SourceRef(
        key="gammah2ax_comet_2017",
        url="https://www.sciencedirect.com/science/article/abs/pii/S138357181730092X",
        note="Comparison of gamma-H2AX foci and comet assays after genotoxicants including H2O2."
    ),
    "a549_keap1_nrf2": SourceRef(
        key="a549_keap1_nrf2",
        url="https://www.sciencedirect.com/science/article/pii/S0891584923006275",
        note="A549 model with loss-of-function KEAP1 context and constitutive NRF2 activation framing."
    ),
    "hct116_mlh1_p53": SourceRef(
        key="hct116_mlh1_p53",
        url="https://link.springer.com/article/10.1186/1476-4598-3-11",
        note="HCT116 is described with wild-type TP53 and DNA mismatch-repair deficiency due to lack of hMLH1 expression."
    ),
    "mcf7_caspase3": SourceRef(
        key="mcf7_caspase3",
        url="https://pubmed.ncbi.nlm.nih.gov/36690238/",
        note="MCF-7 cells lack caspase-3 due to a 47-bp deletion in CASP3 exon 3."
    ),
    "hela_hpv_p53": SourceRef(
        key="hela_hpv_p53",
        url="https://www.nature.com/articles/s41467-024-45920-w",
        note="HPV16 E6/E6AP promotes degradation of p53; relevant to HPV-transformed cervical-line interpretation."
    ),
    "luteolin_anticancer_2022": SourceRef(
        key="luteolin_anticancer_2022",
        url="https://link.springer.com/article/10.1186/s12935-022-02808-3",
        note="Luteolin review: antioxidant and pro-oxidant cancer-cell effects, including ROS-linked apoptosis."
    ),
    "chicoric_hct116_2025": SourceRef(
        key="chicoric_hct116_2025",
        url="https://journals.sagepub.com/doi/10.1177/09731296241291625",
        note="Chicoric acid HCT116 study reporting dose-dependent growth suppression, ROS generation, apoptosis and cell-cycle arrest."
    ),
}

# ============================================
# BIOMOLECULE CLASSES
# ============================================

@dataclass(frozen=True)
class SpectralPeak:
    molecule: str
    peak_value: float
    unit: str
    assignment: str
    spectral_method: SpectralMethod
    source_key: str
    preferred_octaves: Optional[int] = None

    def molecular_frequency_thz(self) -> float:
        if self.unit == "cm^-1":
            return self.peak_value * CM1_TO_THZ
        if self.unit == "nm":
            return NM_TO_THZ_NUMERATOR / self.peak_value
        raise ValueError(f"Unsupported unit {self.unit!r}; expected 'cm^-1' or 'nm'.")

    def molecular_frequency_hz(self) -> float:
        return self.molecular_frequency_thz() * THZ_TO_HZ

    def infrared_wavelength_um(self) -> Optional[float]:
        if self.unit == "cm^-1":
            return 10_000.0 / self.peak_value
        return None

    def select_octaves(
        self,
        target_band_hz: Tuple[float, float] = DEFAULT_TARGET_BAND_HZ,
        search_range: Tuple[int, int] = (20, 60),
    ) -> int:
        if self.preferred_octaves is not None:
            return self.preferred_octaves

        low, high = target_band_hz
        if low <= 0 or high <= low:
            raise ValueError("target_band_hz must be positive and ordered as (low, high).")

        center = math.sqrt(low * high)
        best_n = search_range[0]
        best_score = float("inf")
        for n in range(search_range[0], search_range[1] + 1):
            f_mod = self.molecular_frequency_hz() / (2 ** n)
            if low <= f_mod <= high:
                score = abs(math.log(f_mod / center))
            else:
                score = 10.0 + min(abs(math.log(f_mod / low)), abs(math.log(f_mod / high)))
            if score < best_score:
                best_n = n
                best_score = score
        return best_n

    def modulation_frequency_hz(
        self,
        target_band_hz: Tuple[float, float] = DEFAULT_TARGET_BAND_HZ,
    ) -> float:
        n = self.select_octaves(target_band_hz)
        return self.molecular_frequency_hz() / (2 ** n)

    def conversion_record(
        self,
        target_band_hz: Tuple[float, float] = DEFAULT_TARGET_BAND_HZ,
    ) -> Dict[str, Any]:
        n = self.select_octaves(target_band_hz)
        f_mod = self.molecular_frequency_hz() / (2 ** n)
        return {
            "molecule": self.molecule,
            "peak_value": self.peak_value,
            "unit": self.unit,
            "assignment": self.assignment,
            "method": self.spectral_method.value,
            "source_key": self.source_key,
            "molecular_frequency_thz": round(self.molecular_frequency_thz(), 6),
            "selected_octaves": n,
            "downconversion": f"/2^{n}",
            "modulation_frequency_hz": round(f_mod, 4),
            "infrared_wavelength_um": None if self.infrared_wavelength_um() is None else round(self.infrared_wavelength_um(), 6),
        }


@dataclass(frozen=True)
class MoleculePacket:
    molecule_name: str
    plant_source: str
    plant_part: PlantPart
    spectral_peaks: List[SpectralPeak]

    def modulation_frequencies(self, target_band_hz: Tuple[float, float] = DEFAULT_TARGET_BAND_HZ) -> List[float]:
        return [p.modulation_frequency_hz(target_band_hz) for p in self.spectral_peaks]


DANDELION_MOLECULES: Dict[str, MoleculePacket] = {
    "chlorogenic_acid": MoleculePacket(
        molecule_name="chlorogenic acid",
        plant_source="Taraxacum officinale",
        plant_part=PlantPart.LEAF,
        spectral_peaks=[
            SpectralPeak("chlorogenic acid", 1603, "cm^-1", "C=C catechol / ethylene vibration", SpectralMethod.RAMAN, "chlorogenic_frontiers_2025"),
            SpectralPeak("chlorogenic acid", 1632, "cm^-1", "C=C vibration", SpectralMethod.RAMAN, "chlorogenic_frontiers_2025"),
            SpectralPeak("chlorogenic acid", 1160, "cm^-1", "ester C-O deformation", SpectralMethod.RAMAN, "chlorogenic_frontiers_2025"),
            SpectralPeak("chlorogenic acid", 1444, "cm^-1", "IR analytical peak", SpectralMethod.FTIR, "chlorogenic_frontiers_2025"),
        ],
    ),
    "luteolin": MoleculePacket(
        molecule_name="luteolin",
        plant_source="Taraxacum officinale",
        plant_part=PlantPart.LEAF,
        spectral_peaks=[
            SpectralPeak("luteolin", 1624, "cm^-1", "carbonyl stretch", SpectralMethod.RAMAN, "luteolin_acs_omega_2026"),
            SpectralPeak("luteolin", 3615, "cm^-1", "OH stretching", SpectralMethod.FTIR, "luteolin_acs_omega_2026"),
            SpectralPeak("luteolin", 1607, "cm^-1", "aromatic skeletal vibration", SpectralMethod.RAMAN, "luteolin_acs_omega_2026"),
            SpectralPeak("luteolin", 1594, "cm^-1", "aromatic skeletal vibration", SpectralMethod.RAMAN, "luteolin_acs_omega_2026"),
            SpectralPeak("luteolin", 1582, "cm^-1", "aromatic skeletal vibration", SpectralMethod.RAMAN, "luteolin_acs_omega_2026"),
            SpectralPeak("luteolin", 1567, "cm^-1", "aromatic skeletal vibration", SpectralMethod.RAMAN, "luteolin_acs_omega_2026"),
        ],
    ),
    "chicoric_acid": MoleculePacket(
        molecule_name="chicoric acid",
        plant_source="Taraxacum officinale",
        plant_part=PlantPart.ROOT,
        spectral_peaks=[
            SpectralPeak("chicoric acid", 330, "nm", "UV-visible maximum", SpectralMethod.UV_VIS, "chicoric_frontiers_2013"),
            SpectralPeak("chicoric acid", 300, "nm", "UV-visible shoulder", SpectralMethod.UV_VIS, "chicoric_frontiers_2013"),
            SpectralPeak("chicoric acid", 1650, "cm^-1", "carbonyl vibration", SpectralMethod.FTIR, "chicoric_frontiers_2013"),
        ],
    ),
}

# ============================================
# PACKET CLASSES
# ============================================

@dataclass(frozen=True)
class HNCBioPacket:
    packet_id: str
    version: str
    plant: str
    plant_part: str
    molecules: List[str]
    carrier_type: CarrierType
    carrier_wavelength_nm: Optional[float]
    target_band_hz: Tuple[float, float]
    spectral_inputs: List[Dict[str, Any]]
    modulation_frequencies_hz: List[float]
    sideband_frequencies_hz: List[Dict[str, Any]]
    coherence_nodes_hz: List[Dict[str, Any]]
    biological_targets: List[str]
    claim_level: ClaimLevel
    exposure_duration_min: float = 60.0
    duty_cycle: float = INV_PHI
    phase_pattern: str = "golden_ratio"
    hnc_certificate: str = "HNC-VER-2025-0407-001"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "packet_id": self.packet_id,
            "version": self.version,
            "plant": self.plant,
            "plant_part": self.plant_part,
            "molecules": self.molecules,
            "carrier": {
                "type": self.carrier_type.value,
                "wavelength_nm": self.carrier_wavelength_nm,
                "mode": "amplitude_modulated" if self.carrier_type == CarrierType.RED_NIR_LIGHT else "carrier_specific",
            },
            "target_band_hz": list(self.target_band_hz),
            "spectral_inputs": self.spectral_inputs,
            "modulation_frequencies_hz": self.modulation_frequencies_hz,
            "sideband_frequencies_hz": self.sideband_frequencies_hz,
            "coherence_nodes_hz": self.coherence_nodes_hz,
            "biological_targets": self.biological_targets,
            "claim_level": self.claim_level.value,
            "exposure_duration_min": self.exposure_duration_min,
            "duty_cycle": self.duty_cycle,
            "phase_pattern": self.phase_pattern,
            "hnc_certificate": self.hnc_certificate,
        }


@dataclass(frozen=True)
class CancerCellProfile:
    model: CancerCellModel
    depmap_id: str
    ccle_name: str
    lineage: str
    subtype: str
    recommended_priority: str
    biological_rationale: str
    baseline_hypothesis: str
    primary_stressor: StressorType
    stressor_notes: str
    recommended_timepoints_hr: List[float]
    preferred_endpoints: List[str]
    public_data_keys: List[str]
    cautions: List[str]

    def to_dict(self) -> Dict[str, Any]:
        out = asdict(self)
        out["model"] = self.model.value
        out["primary_stressor"] = self.primary_stressor.value
        return out


@dataclass(frozen=True)
class PublicDataHook:
    source_key: str
    dataset_name: str
    recommended_use: str
    file_or_access_hint: str
    genes_or_features: List[str]
    source_url: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ExperimentalArm:
    arm_id: str
    description: str
    purpose: str
    stressor: bool
    molecule: str
    signal: str
    interpretation_rule: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class CancerExperimentSpec:
    spec_id: str
    version: str
    base_packet: HNCBioPacket
    priority_cell_lines: List[CancerCellProfile]
    reserve_cell_lines: List[CancerCellProfile]
    experimental_arms: List[ExperimentalArm]
    decisive_comparisons: Dict[str, Any]
    public_data_hooks: List[PublicDataHook]
    endpoint_families: Dict[str, List[str]]
    analysis_plan: Dict[str, Any]
    claim_boundary: Dict[str, str]
    source_references: Dict[str, Dict[str, str]]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "spec_id": self.spec_id,
            "version": self.version,
            "base_packet": self.base_packet.to_dict(),
            "priority_cell_lines": [p.to_dict() for p in self.priority_cell_lines],
            "reserve_cell_lines": [p.to_dict() for p in self.reserve_cell_lines],
            "experimental_arms": [a.to_dict() for a in self.experimental_arms],
            "decisive_comparisons": self.decisive_comparisons,
            "public_data_hooks": [h.to_dict() for h in self.public_data_hooks],
            "endpoint_families": self.endpoint_families,
            "analysis_plan": self.analysis_plan,
            "claim_boundary": self.claim_boundary,
            "source_references": self.source_references,
        }

# ============================================
# FACTORIES
# ============================================

class HNCBioPacketFactory:
    @staticmethod
    def create_phenolic_coherence_packet(
        plant: str = "Taraxacum officinale",
        plant_part: str = "leaf/root mixed extract",
        molecules: Optional[List[str]] = None,
        carrier_type: CarrierType = CarrierType.RED_NIR_LIGHT,
        carrier_wavelength_nm: float = 660.0,
        target_band_hz: Tuple[float, float] = DEFAULT_TARGET_BAND_HZ,
    ) -> HNCBioPacket:
        if molecules is None:
            molecules = ["chlorogenic acid", "chicoric acid", "luteolin"]

        all_peaks: List[SpectralPeak] = []
        spectral_inputs: List[Dict[str, Any]] = []
        for mol_name in molecules:
            key = mol_name.replace(" ", "_").replace("-", "_")
            if key not in DANDELION_MOLECULES:
                raise ValueError(f"Unknown molecule: {mol_name}")
            mol = DANDELION_MOLECULES[key]
            for peak in mol.spectral_peaks:
                all_peaks.append(peak)
                spectral_inputs.append(peak.conversion_record(target_band_hz))

        freqs = sorted(round(p.modulation_frequency_hz(target_band_hz), 4) for p in all_peaks)
        sidebands = []
        for p in all_peaks:
            f0 = p.modulation_frequency_hz(target_band_hz)
            sidebands.append({
                "molecule": p.molecule,
                "peak": p.peak_value,
                "unit": p.unit,
                "center": round(f0, 4),
                "narrow_low": round(f0 * 0.99, 4),
                "narrow_high": round(f0 * 1.01, 4),
                "geometric_low": round(f0 * (1 - PHI_INV_9), 4),
                "geometric_high": round(f0 * (1 + PHI_INV_9), 4),
            })

        nodes = HNCBioPacketFactory.detect_coherence_nodes(all_peaks, target_band_hz)
        packet_id = HNCBioPacketFactory.generate_packet_id(plant, molecules, carrier_type.value, "cancer-v03")

        return HNCBioPacket(
            packet_id=packet_id,
            version="0.3-cancer",
            plant=plant,
            plant_part=plant_part,
            molecules=molecules,
            carrier_type=carrier_type,
            carrier_wavelength_nm=carrier_wavelength_nm,
            target_band_hz=target_band_hz,
            spectral_inputs=spectral_inputs,
            modulation_frequencies_hz=freqs,
            sideband_frequencies_hz=sidebands,
            coherence_nodes_hz=nodes,
            biological_targets=[
                "ROS", "GSH/GSSG", "8-oxodG", "gamma-H2AX", "53BP1", "comet_tail_moment",
                "NFE2L2/NRF2", "KEAP1", "HMOX1/HO-1", "NQO1", "OGG1", "APE1/APEX1",
                "XRCC1", "RAD51", "BRCA1", "TP53", "CDKN1A/p21", "PARP1", "CASP3", "BAX/BCL2"
            ],
            claim_level=ClaimLevel.LEVEL_1_PROTECTION,
        )

    @staticmethod
    def detect_coherence_nodes(
        peaks: Sequence[SpectralPeak],
        target_band_hz: Tuple[float, float],
        max_span_hz: float = 45.0,
        min_peaks: int = 3,
    ) -> List[Dict[str, Any]]:
        records = sorted(
            [(p.modulation_frequency_hz(target_band_hz), p.molecule, p.peak_value, p.unit) for p in peaks],
            key=lambda x: x[0],
        )
        nodes: List[Dict[str, Any]] = []
        for i in range(len(records)):
            cluster = [records[i]]
            for j in range(i + 1, len(records)):
                if records[j][0] - records[i][0] <= max_span_hz:
                    cluster.append(records[j])
            if len(cluster) >= min_peaks:
                molecules = sorted({x[1] for x in cluster})
                if len(molecules) < 2:
                    continue
                lo = min(x[0] for x in cluster)
                hi = max(x[0] for x in cluster)
                center = sum(x[0] for x in cluster) / len(cluster)
                node = {
                    "low_hz": round(lo, 4),
                    "center_hz": round(center, 4),
                    "high_hz": round(hi, 4),
                    "span_hz": round(hi - lo, 4),
                    "n_peaks": len(cluster),
                    "molecules": molecules,
                    "members": [
                        {"frequency_hz": round(x[0], 4), "molecule": x[1], "peak": x[2], "unit": x[3]}
                        for x in cluster
                    ],
                }
                if node not in nodes:
                    nodes.append(node)
        # Remove contained duplicates by keeping broadest/highest n_peaks first.
        nodes = sorted(nodes, key=lambda n: (-n["n_peaks"], n["span_hz"]))
        deduped: List[Dict[str, Any]] = []
        for node in nodes:
            overlaps = any(
                node["low_hz"] >= kept["low_hz"] and node["high_hz"] <= kept["high_hz"]
                for kept in deduped
            )
            if not overlaps:
                deduped.append(node)
        return deduped

    @staticmethod
    def generate_packet_id(*parts: Any) -> str:
        normalized: List[str] = []
        for part in parts:
            if isinstance(part, (list, tuple, set)):
                normalized.append(",".join(str(x) for x in part))
            else:
                normalized.append(str(part))
        data = ":".join(normalized)
        return f"HNC-{hashlib.sha256(data.encode()).hexdigest()[:10].upper()}"


class CancerProfileLibrary:
    @staticmethod
    def all_profiles() -> Dict[CancerCellModel, CancerCellProfile]:
        return {
            CancerCellModel.A549: CancerCellProfile(
                model=CancerCellModel.A549,
                depmap_id="ACH-000681",
                ccle_name="A549_LUNG",
                lineage="lung",
                subtype="lung adenocarcinoma / NSCLC",
                recommended_priority="priority_1_nrf2_high_redox_model",
                biological_rationale="KEAP1-mutant/NRF2-active context tests whether the HNC phenolic packet adds signal over an already redox-adapted cancer state.",
                baseline_hypothesis="NRF2/HO-1/NQO1 may already be high; incremental NRF2 induction may be blunted while ROS and gamma-H2AX kinetics may still shift.",
                primary_stressor=StressorType.H2O2,
                stressor_notes="Run a pilot nonlethal dose-response and choose a dose that gives measurable gamma-H2AX/comet signal with >=70% short-term viability.",
                recommended_timepoints_hr=[0, 0.5, 1, 3, 6, 24],
                preferred_endpoints=["ROS", "GSH/GSSG", "NFE2L2", "HMOX1", "NQO1", "gamma-H2AX", "53BP1", "comet_tail_moment", "8-oxodG", "viability"],
                public_data_keys=["depmap_portal", "ccle_datasets", "aws_depmap_omics_ccle", "sanger_depmap_datasets", "a549_keap1_nrf2"],
                cautions=["High baseline NRF2 can mask antioxidant-response effects.", "Reduced DNA damage in cancer cells is mechanistic, not automatically therapeutic."],
            ),
            CancerCellModel.HCT116: CancerCellProfile(
                model=CancerCellModel.HCT116,
                depmap_id="ACH-000971",
                ccle_name="HCT116_LARGE_INTESTINE",
                lineage="large_intestine",
                subtype="colorectal carcinoma",
                recommended_priority="priority_1_dna_repair_rewired_luteolin_chicoric_model",
                biological_rationale="Mismatch-repair-deficient but p53-competent colon model; strong literature connection to luteolin and chicoric acid effects.",
                baseline_hypothesis="MMR deficiency and p53 responsiveness may separate DNA-damage marker reduction from apoptosis/cell-cycle effects.",
                primary_stressor=StressorType.H2O2,
                stressor_notes="Use oxidative stress first; add doxorubicin/etoposide as a DSB stressor after viability window is established.",
                recommended_timepoints_hr=[0, 0.5, 1, 3, 6, 24, 48],
                preferred_endpoints=["gamma-H2AX", "53BP1", "comet_tail_moment", "8-oxodG", "TP53", "CDKN1A", "OGG1", "APE1", "XRCC1", "RAD51", "apoptosis", "cell_cycle"],
                public_data_keys=["depmap_portal", "ccle_datasets", "hct116_mlh1_p53", "luteolin_anticancer_2022", "chicoric_hct116_2025"],
                cautions=["Cell-fate endpoints can dominate over repair endpoints at high phytochemical doses.", "Separate protection/repair from selective cancer cytotoxicity."],
            ),
            CancerCellModel.MCF7: CancerCellProfile(
                model=CancerCellModel.MCF7,
                depmap_id="ACH-000019",
                ccle_name="MCF7_BREAST",
                lineage="breast",
                subtype="ER-positive breast carcinoma",
                recommended_priority="priority_2_breast_polyphenol_cell_fate_model",
                biological_rationale="Common breast cancer model for polyphenol response; useful for comparing redox/DNA damage endpoints against altered apoptosis execution.",
                baseline_hypothesis="Caspase-3 deficiency means apoptosis interpretation requires PARP1, caspase-7, annexin V/PI, mitochondrial and cell-cycle readouts rather than CASP3 alone.",
                primary_stressor=StressorType.H2O2,
                stressor_notes="Begin with oxidative stress and low phytochemical doses; include viability gating because cell death pathway may differ from caspase-3-proficient lines.",
                recommended_timepoints_hr=[0, 0.5, 1, 3, 6, 24],
                preferred_endpoints=["ROS", "8-oxodG", "gamma-H2AX", "53BP1", "comet_tail_moment", "PARP1", "CASP7", "BAX", "BCL2", "annexin_v_pi", "cell_cycle"],
                public_data_keys=["depmap_portal", "ccle_datasets", "mcf7_caspase3", "luteolin_anticancer_2022"],
                cautions=["Do not use CASP3 alone as an apoptosis marker.", "Estrogen-receptor context can affect polyphenol response."],
            ),
            CancerCellModel.HELA: CancerCellProfile(
                model=CancerCellModel.HELA,
                depmap_id="ACH-001086",
                ccle_name="HELA_CERVIX",
                lineage="cervix",
                subtype="HPV-transformed cervical adenocarcinoma model",
                recommended_priority="reserve_hpv_p53_context_model",
                biological_rationale="HPV E6/E7 transformed context tests p53-impaired DNA-damage response under a viral-oncoprotein rewiring regime.",
                baseline_hypothesis="p53-dependent repair/apoptosis signaling may be distorted by HPV oncoprotein activity; gamma-H2AX/comet endpoints are still useful.",
                primary_stressor=StressorType.H2O2,
                stressor_notes="Use as a reserve line after HCT116/A549/MCF7 because public dependency coverage can be weaker for canonical HeLa in DepMap.",
                recommended_timepoints_hr=[0, 0.5, 1, 3, 6, 24],
                preferred_endpoints=["gamma-H2AX", "53BP1", "comet_tail_moment", "8-oxodG", "TP53_pathway", "p21", "apoptosis", "cell_cycle"],
                public_data_keys=["sanger_depmap_datasets", "hela_hpv_p53", "luteolin_anticancer_2022"],
                cautions=["HeLa derivative identity and source must be documented.", "p53 pathway interpretation differs from p53-wild-type models."],
            ),
        }

    @staticmethod
    def priority_profiles() -> List[CancerCellProfile]:
        profiles = CancerProfileLibrary.all_profiles()
        return [profiles[CancerCellModel.A549], profiles[CancerCellModel.HCT116], profiles[CancerCellModel.MCF7]]

    @staticmethod
    def reserve_profiles() -> List[CancerCellProfile]:
        profiles = CancerProfileLibrary.all_profiles()
        return [profiles[CancerCellModel.HELA]]


class CancerDesignFactory:
    @staticmethod
    def experimental_arms() -> List[ExperimentalArm]:
        return [
            ExperimentalArm("A", "No stressor, no molecule, no signal", "baseline", False, "none", "none", "Sets basal ROS/DNA-damage level per cancer line."),
            ExperimentalArm("B", "Stressor only", "damage_control", True, "none", "none", "Quantifies stressor-induced damage against baseline."),
            ExperimentalArm("C", "Stressor + standardized dandelion extract", "chemical_biomolecule", True, "dandelion_extract", "none", "Measures chemical phytomolecule effect without signal packet."),
            ExperimentalArm("D", "Stressor + 660 nm carrier only", "carrier_effect", True, "none", "unmodulated_660nm", "Measures carrier/PBM effect without HNC modulation."),
            ExperimentalArm("E", "Stressor + random-frequency packet", "random_frequency_control", True, "none", "random_packet", "Tests nonspecific modulation without biomolecule-derived structure."),
            ExperimentalArm("F", "Stressor + HNC packet only", "signal_only_hnc", True, "none", "hnc_packet", "Tests whether signal structure has effect without molecules."),
            ExperimentalArm("G", "Stressor + dandelion extract + random packet", "molecule_plus_nonspecific_signal", True, "dandelion_extract", "random_packet", "Controls for molecule plus generic modulated light."),
            ExperimentalArm("H", "Stressor + dandelion extract + HNC packet", "full_hypothesis", True, "dandelion_extract", "hnc_packet", "Primary hypothesis arm; must outperform C, D, E and G."),
            ExperimentalArm("I", "Stressor + purified luteolin/chlorogenic/chicoric acids + HNC packet", "molecule_specific_validation", True, "purified_phenolic_mix", "hnc_packet", "Deconvolves extract complexity."),
            ExperimentalArm("J", "Stressor + known assay-positive repair/protection control", "assay_validation", True, "positive_control", "none", "Confirms the assay detects known modulation."),
        ]

    @staticmethod
    def public_data_hooks() -> List[PublicDataHook]:
        genes = [
            "NFE2L2", "KEAP1", "HMOX1", "NQO1", "GCLC", "GCLM", "SOD1", "SOD2", "CAT", "GPX1",
            "OGG1", "APEX1", "XRCC1", "PARP1", "RAD51", "BRCA1", "TP53", "CDKN1A", "H2AFX", "TP53BP1",
            "CASP3", "CASP7", "BAX", "BCL2", "MLH1", "MSH2", "MSH6", "PMS2"
        ]
        return [
            PublicDataHook(
                source_key="depmap_portal",
                dataset_name="DepMap Public / CCLE processed data",
                recommended_use="Baseline mutation, copy-number, expression and dependency context for candidate cell lines.",
                file_or_access_hint="Downloads -> All Data; use Model.csv plus OmicsExpressionProteinCodingGenesTPMLogp1*.csv, OmicsSomaticMutations.csv, OmicsCNGene.csv, CRISPRGeneEffect.csv where available.",
                genes_or_features=genes,
                source_url=SOURCE_REFS["depmap_portal"].url,
            ),
            PublicDataHook(
                source_key="bioconductor_depmap_2026",
                dataset_name="Bioconductor depmap package",
                recommended_use="Programmatic R/ExperimentHub access to current release; useful for reproducible public baseline tables.",
                file_or_access_hint="R: library(depmap); use depmap_* functions for expression, mutation, copy number, CRISPR and metadata where supported.",
                genes_or_features=genes,
                source_url=SOURCE_REFS["bioconductor_depmap_2026"].url,
            ),
            PublicDataHook(
                source_key="aws_depmap_omics_ccle",
                dataset_name="AWS Open Data DepMap Omics CCLE raw files",
                recommended_use="Raw RNA-seq/WES/WGS access when processed data are insufficient or exact sequence-level baselines are needed.",
                file_or_access_hint="AWS CLI: aws s3 ls --no-sign-request s3://depmap-omics-ccle/",
                genes_or_features=genes,
                source_url=SOURCE_REFS["aws_depmap_omics_ccle"].url,
            ),
            PublicDataHook(
                source_key="sanger_depmap_datasets",
                dataset_name="Sanger Cell Model Passports / DepMap datasets",
                recommended_use="Cross-check cell-line identity, lineage, mutation, expression, methylation, drug-sensitivity and CRISPR datasets.",
                file_or_access_hint="Use Cell Model Passports or processed downloads/API by SIDM/Broad DepMap ID.",
                genes_or_features=genes,
                source_url=SOURCE_REFS["sanger_depmap_datasets"].url,
            ),
            PublicDataHook(
                source_key="geo_line_specific_stress",
                dataset_name="GEO line-specific oxidative/genotoxic stress studies",
                recommended_use="Historical stress-response expression data for H2O2, UV, doxorubicin or etoposide exposure; use after priority line is fixed.",
                file_or_access_hint="GEO search terms: '<cell line> H2O2 gamma H2AX', '<cell line> oxidative stress RNA-seq', '<cell line> doxorubicin DNA damage'. Validate manually before meta-analysis.",
                genes_or_features=genes,
                source_url="https://www.ncbi.nlm.nih.gov/geo/",
            ),
        ]

    @staticmethod
    def endpoint_families() -> Dict[str, List[str]]:
        return {
            EndpointFamily.REDOX.value: ["ROS/DCFDA", "GSH/GSSG", "mitochondrial membrane potential", "NFE2L2", "KEAP1", "HMOX1", "NQO1"],
            EndpointFamily.DNA_DAMAGE.value: ["gamma-H2AX", "53BP1 foci", "alkaline comet tail moment", "Fpg/hOGG1-modified comet", "8-oxodG", "micronucleus assay"],
            EndpointFamily.DNA_REPAIR.value: ["OGG1", "APEX1/APE1", "XRCC1", "PARP1", "RAD51", "BRCA1", "TP53", "CDKN1A/p21"],
            EndpointFamily.CELL_FATE.value: ["viability", "annexin V/PI", "caspase activity as line-appropriate", "PARP cleavage", "cell cycle", "senescence markers"],
            EndpointFamily.SEQUENCING.value: ["targeted deep sequencing", "amplicon UMI sequencing", "single-cell sequencing optional", "clonal persistence after expansion"],
        }

    @staticmethod
    def analysis_plan() -> Dict[str, Any]:
        return {
            "primary_comparison": "Arm H versus C, D, E and G within each cancer cell line.",
            "secondary_comparison": "Effect-size contrast across A549, HCT116 and MCF7 to test NRF2-high, DNA-repair-rewired and breast/polyphenol-response contexts.",
            "normal_cell_anchor": "Compare cancer-cell effect sizes against normal fibroblast/keratinocyte arms from v0.2/v0.3 normal-cell layer.",
            "dose_rule": "Run line-specific pilot stressor and phytochemical dose-response; choose nonlethal stress where DNA-damage signal is measurable and short-term viability remains adequate.",
            "statistics": {
                "minimum_design": "n >= 3 independent biological replicates per arm per line; blinded image/assay quantification where possible.",
                "preferred_model": "linear mixed model or two-way ANOVA with factors: arm, cell_line, timepoint, and interaction terms.",
                "primary_effect_size": "difference in normalized gamma-H2AX, comet tail moment, or 8-oxodG versus stressor-only and versus molecule+random packet.",
                "multiple_testing": "Control false discovery rate for gene-panel or multi-endpoint analysis.",
            },
            "failure_rule": "If H is not better than C and G, the result supports phytochemistry/carrier effects, not HNC packet specificity.",
            "dna_rebuilding_rule": "Only claim DNA rebuilding if sequencing shows restoration of a pre-defined damaged/mutant locus above background and persistence after clonal expansion.",
        }

    @staticmethod
    def claim_boundary() -> Dict[str, str]:
        return {
            "lower_ROS_only": "redox modulation, not DNA repair",
            "lower_8oxodG_or_comet_or_gammaH2AX": "DNA-damage reduction/protection claim",
            "faster_gammaH2AX_53BP1_resolution_with_repair_gene_kinetics": "DNA-repair-pathway modulation claim",
            "lower_micronucleus_or_mutation_frequency": "mutation-prevention claim",
            "targeted_sequencing_restores_defined_variant_and_persists": "DNA rebuilding candidate claim",
            "no_sequence_restoration": "do not claim DNA rebuilding",
        }

    @staticmethod
    def decisive_comparisons() -> Dict[str, Any]:
        return {
            "full_hypothesis_arm": "H",
            "must_outperform": {
                "C": "molecule-only phytochemical effect",
                "D": "carrier-only PBM/660 nm effect",
                "E": "random-frequency nonspecific signal effect",
                "G": "molecule plus random-frequency packet effect",
            },
            "minimum_success_pattern": "H shows statistically and biologically meaningful improvement over G and C on primary DNA-damage endpoint without being explainable by viability loss alone.",
            "cancer_specific_interpretation": "In transformed cells, reduced DNA damage is mechanistic modulation. It is not automatically therapeutic because protecting cancer cells can be undesirable in oncology contexts.",
        }

    @staticmethod
    def create_spec() -> CancerExperimentSpec:
        base_packet = HNCBioPacketFactory.create_phenolic_coherence_packet()
        spec_id = HNCBioPacketFactory.generate_packet_id(base_packet.packet_id, "cancer-experiment-spec", "v03")
        return CancerExperimentSpec(
            spec_id=spec_id,
            version="0.3-cancer",
            base_packet=base_packet,
            priority_cell_lines=CancerProfileLibrary.priority_profiles(),
            reserve_cell_lines=CancerProfileLibrary.reserve_profiles(),
            experimental_arms=CancerDesignFactory.experimental_arms(),
            decisive_comparisons=CancerDesignFactory.decisive_comparisons(),
            public_data_hooks=CancerDesignFactory.public_data_hooks(),
            endpoint_families=CancerDesignFactory.endpoint_families(),
            analysis_plan=CancerDesignFactory.analysis_plan(),
            claim_boundary=CancerDesignFactory.claim_boundary(),
            source_references={k: asdict(v) for k, v in SOURCE_REFS.items()},
        )

# ============================================
# EXPORT HELPERS
# ============================================

def write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: _csv_safe(row.get(k)) for k in fieldnames})


def _csv_safe(value: Any) -> Any:
    if isinstance(value, (list, dict, tuple)):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, Enum):
        return value.value
    return value


def generate_cell_model_matrix(spec: CancerExperimentSpec) -> List[Dict[str, Any]]:
    rows = []
    for profile in spec.priority_cell_lines + spec.reserve_cell_lines:
        rows.append({
            "model": profile.model.value,
            "priority": profile.recommended_priority,
            "depmap_id": profile.depmap_id,
            "ccle_name": profile.ccle_name,
            "lineage": profile.lineage,
            "subtype": profile.subtype,
            "biological_rationale": profile.biological_rationale,
            "baseline_hypothesis": profile.baseline_hypothesis,
            "primary_stressor": profile.primary_stressor.value,
            "timepoints_hr": profile.recommended_timepoints_hr,
            "preferred_endpoints": profile.preferred_endpoints,
            "public_data_keys": profile.public_data_keys,
            "cautions": profile.cautions,
        })
    return rows


def generate_control_matrix(spec: CancerExperimentSpec) -> List[Dict[str, Any]]:
    return [arm.to_dict() for arm in spec.experimental_arms]


def generate_public_data_table(spec: CancerExperimentSpec) -> List[Dict[str, Any]]:
    return [hook.to_dict() for hook in spec.public_data_hooks]


def generate_conversion_table(packet: HNCBioPacket) -> List[Dict[str, Any]]:
    rows = []
    for rec in packet.spectral_inputs:
        rows.append({
            "molecule": rec["molecule"],
            "peak_value": rec["peak_value"],
            "unit": rec["unit"],
            "assignment": rec["assignment"],
            "method": rec["method"],
            "source_key": rec["source_key"],
            "molecular_frequency_thz": rec["molecular_frequency_thz"],
            "selected_octaves": rec["selected_octaves"],
            "downconversion": rec["downconversion"],
            "modulation_frequency_hz": rec["modulation_frequency_hz"],
        })
    return rows


def make_random_frequency_control(
    packet: HNCBioPacket,
    seed: int = 407001,
    min_hz: float = DEFAULT_TARGET_BAND_HZ[0],
    max_hz: float = DEFAULT_TARGET_BAND_HZ[1],
) -> Dict[str, Any]:
    rng = random.Random(seed)
    freqs = sorted(round(rng.uniform(min_hz, max_hz), 4) for _ in packet.modulation_frequencies_hz)
    return {
        "control_id": f"{packet.packet_id}-RANDOM-CONTROL",
        "control_type": "random_frequency_matched_count",
        "seed": seed,
        "carrier": packet.to_dict()["carrier"],
        "frequency_count": len(freqs),
        "frequencies_hz": freqs,
        "purpose": "Controls for nonspecific modulation count and target band without biomolecule-derived spectral structure.",
    }


def make_scrambled_phase_control(packet: HNCBioPacket, seed: int = 407002) -> Dict[str, Any]:
    rng = random.Random(seed)
    phase_map = [
        {"frequency_hz": f, "phase_rad": round(rng.uniform(0, 2 * math.pi), 6)}
        for f in packet.modulation_frequencies_hz
    ]
    return {
        "control_id": f"{packet.packet_id}-SCRAMBLED-PHASE-CONTROL",
        "control_type": "same_frequencies_random_phase",
        "seed": seed,
        "carrier": packet.to_dict()["carrier"],
        "frequency_phase_map": phase_map,
        "purpose": "Controls whether golden-ratio/structured phase relation matters beyond frequency membership.",
    }


def render_markdown_design(spec: CancerExperimentSpec) -> str:
    p = spec.base_packet
    src = spec.source_references
    lines: List[str] = []
    lines.append("# HNC BioMolecule → Adjacent Frequency Packet Blueprint v0.3 Cancer Layer")
    lines.append("")
    lines.append("## Scientific boundary")
    lines.append("")
    lines.append("This design is for **in-vitro hypothesis testing** using public cancer-cell data as the model-selection and baseline layer. It does not make a clinical claim, and it does not prove DNA rebuilding. In cancer-cell models, reduced DNA-damage markers can indicate redox protection of transformed cells, altered DNA-damage response, or assay/viability effects; it is not automatically beneficial.")
    lines.append("")
    lines.append("## Base HNC packet")
    lines.append("")
    lines.append(f"- Packet ID: `{p.packet_id}`")
    lines.append(f"- Carrier: `{p.carrier_type.value}` at `{p.carrier_wavelength_nm} nm`")
    lines.append(f"- Duty cycle: `{p.duty_cycle:.6f}`")
    lines.append(f"- Phase pattern: `{p.phase_pattern}`")
    lines.append(f"- Claim ceiling at this stage: `{p.claim_level.value}`")
    lines.append("")
    lines.append("### Modulation frequencies")
    lines.append("")
    lines.append(", ".join(f"{f:.1f} Hz" for f in p.modulation_frequencies_hz))
    lines.append("")
    lines.append("### Detected coherence nodes")
    lines.append("")
    for node in p.coherence_nodes_hz:
        lines.append(f"- `{node['low_hz']:.1f}–{node['high_hz']:.1f} Hz`, center `{node['center_hz']:.1f} Hz`, peaks `{node['n_peaks']}`, molecules: {', '.join(node['molecules'])}")
    lines.append("")
    lines.append("## Priority cancer cell lines")
    lines.append("")
    for profile in spec.priority_cell_lines:
        lines.append(f"### {profile.model.value} — {profile.recommended_priority}")
        lines.append(f"- DepMap ID: `{profile.depmap_id}`; CCLE name: `{profile.ccle_name}`")
        lines.append(f"- Context: {profile.subtype}")
        lines.append(f"- Rationale: {profile.biological_rationale}")
        lines.append(f"- Baseline hypothesis: {profile.baseline_hypothesis}")
        lines.append(f"- Primary stressor: `{profile.primary_stressor.value}`")
        lines.append(f"- Timepoints: {', '.join(str(t) for t in profile.recommended_timepoints_hr)} h")
        lines.append(f"- Endpoints: {', '.join(profile.preferred_endpoints)}")
        lines.append(f"- Cautions: {'; '.join(profile.cautions)}")
        lines.append("")
    lines.append("## Reserve line")
    lines.append("")
    for profile in spec.reserve_cell_lines:
        lines.append(f"- **{profile.model.value}** (`{profile.depmap_id}`, `{profile.ccle_name}`): {profile.biological_rationale}")
    lines.append("")
    lines.append("## 10-arm cancer-adapted experimental design")
    lines.append("")
    lines.append("| Arm | Description | Purpose | Interpretation rule |")
    lines.append("|---|---|---|---|")
    for arm in spec.experimental_arms:
        lines.append(f"| {arm.arm_id} | {arm.description} | {arm.purpose} | {arm.interpretation_rule} |")
    lines.append("")
    lines.append("## Decisive comparison")
    lines.append("")
    lines.append("Arm **H** is the full hypothesis arm. It must outperform Arm C, Arm D, Arm E and Arm G on primary DNA-damage endpoints while not being explainable by viability loss alone. If H is not better than C or G, the HNC packet is not adding specificity beyond phytochemistry or nonspecific modulated-light effects.")
    lines.append("")
    lines.append("## Public data hooks")
    lines.append("")
    for hook in spec.public_data_hooks:
        lines.append(f"- **{hook.dataset_name}**: {hook.recommended_use} Access: {hook.file_or_access_hint}. Source: {hook.source_url}")
    lines.append("")
    lines.append("## Endpoint families")
    lines.append("")
    for family, endpoints in spec.endpoint_families.items():
        lines.append(f"- **{family}**: {', '.join(endpoints)}")
    lines.append("")
    lines.append("## Claim boundary")
    lines.append("")
    for event, claim in spec.claim_boundary.items():
        lines.append(f"- `{event}` → {claim}")
    lines.append("")
    lines.append("## Source URLs embedded in this spec")
    lines.append("")
    for key, source in src.items():
        lines.append(f"- `{key}`: {source['url']} — {source['note']}")
    lines.append("")
    return "\n".join(lines)


def validate_spec(spec: CancerExperimentSpec) -> List[str]:
    warnings: List[str] = []
    p = spec.base_packet
    low, high = DEFAULT_VALIDATION_BAND_HZ
    for f in p.modulation_frequencies_hz:
        if not (low <= f <= high):
            warnings.append(f"Frequency {f} Hz is outside validation band {low}-{high} Hz.")
    if p.claim_level == ClaimLevel.LEVEL_4_DNA_REBUILDING:
        warnings.append("Base packet should not be initialized at DNA rebuilding claim level without sequencing proof.")
    for profile in spec.priority_cell_lines:
        if not profile.depmap_id.startswith("ACH-"):
            warnings.append(f"Profile {profile.model.value} has nonstandard DepMap ID {profile.depmap_id}.")
    if not any(a.arm_id == "H" for a in spec.experimental_arms):
        warnings.append("Experimental arm H is missing.")
    return warnings


def export_all(output_dir: Path = Path("/mnt/data")) -> Dict[str, str]:
    spec = CancerDesignFactory.create_spec()
    warnings = validate_spec(spec)

    files = {
        "script": output_dir / "hnc_biomolecule_packet_v03_cancer.py",
        "spec_json": output_dir / "hnc_cancer_packet_spec_v03.json",
        "cell_matrix_csv": output_dir / "hnc_cancer_cell_model_matrix_v03.csv",
        "control_matrix_csv": output_dir / "hnc_cancer_control_matrix_v03.csv",
        "public_data_hooks_csv": output_dir / "hnc_cancer_public_data_hooks_v03.csv",
        "conversion_table_csv": output_dir / "hnc_cancer_conversion_table_v03.csv",
        "random_control_json": output_dir / "hnc_cancer_random_frequency_control_v03.json",
        "scrambled_phase_json": output_dir / "hnc_cancer_scrambled_phase_control_v03.json",
        "design_markdown": output_dir / "hnc_cancer_design_document_v03.md",
        "validation_json": output_dir / "hnc_cancer_validation_report_v03.json",
    }

    write_json(files["spec_json"], spec.to_dict())
    write_csv(files["cell_matrix_csv"], generate_cell_model_matrix(spec))
    write_csv(files["control_matrix_csv"], generate_control_matrix(spec))
    write_csv(files["public_data_hooks_csv"], generate_public_data_table(spec))
    write_csv(files["conversion_table_csv"], generate_conversion_table(spec.base_packet))
    write_json(files["random_control_json"], make_random_frequency_control(spec.base_packet))
    write_json(files["scrambled_phase_json"], make_scrambled_phase_control(spec.base_packet))
    files["design_markdown"].write_text(render_markdown_design(spec), encoding="utf-8")
    write_json(files["validation_json"], {"version": spec.version, "warnings": warnings, "is_valid": len(warnings) == 0})

    return {k: str(v) for k, v in files.items() if k != "script"}


if __name__ == "__main__":
    paths = export_all(Path("/mnt/data"))
    spec = CancerDesignFactory.create_spec()
    warnings = validate_spec(spec)
    print("=" * 76)
    print("HNC BIOMOLECULE -> ADJACENT FREQUENCY PACKET BLUEPRINT v0.3 CANCER")
    print("=" * 76)
    print(f"Spec ID: {spec.spec_id}")
    print(f"Base packet: {spec.base_packet.packet_id}")
    print("Priority lines:", ", ".join(p.model.value for p in spec.priority_cell_lines))
    print("Reserve lines:", ", ".join(p.model.value for p in spec.reserve_cell_lines))
    print("Core frequencies:", ", ".join(f"{f:.1f}" for f in spec.base_packet.modulation_frequencies_hz), "Hz")
    print("Coherence nodes:")
    for node in spec.base_packet.coherence_nodes_hz:
        print(f"  - {node['low_hz']:.1f}-{node['high_hz']:.1f} Hz | n={node['n_peaks']} | {', '.join(node['molecules'])}")
    print("Validation:", "no structural warnings" if not warnings else warnings)
    print("Exported files:")
    for label, path in paths.items():
        print(f"  {label}: {path}")
