#!/usr/bin/env python3
"""
HNC BioMolecule -> Adjacent Frequency Packet Blueprint v0.2
===========================================================
A reproducible conversion pipeline from plant biomolecule spectral
signatures to testable HNC-style modulation packets.

Scientific boundary:
- This code builds signal hypotheses and experimental metadata.
- It does not prove biological efficacy or DNA rebuilding.
- DNA rebuilding claims require sequencing-confirmed restoration of a defined locus.

Author: R&A CONSULTING AND BROKERAGE SERVICES LTD
HNC Certificate: HNC-VER-2025-0407-001
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import random
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

# ============================================
# HNC MODEL CONSTANTS
# ============================================

PHI = 1.618033988749895
INV_PHI = 1.0 / PHI
PHI_INV_9 = PHI ** (-9)          # approximately 0.0132
SCHUMANN_BASE_HZ = 7.83          # optional reference anchor, not used by default
THZ_TO_HZ = 1.0e12
CM1_TO_THZ = 0.0299792458        # cm^-1 * this = THz
NM_TO_THZ_NUMERATOR = 299_792.458  # THz = 299792.458 / nm

DEFAULT_TARGET_BAND_HZ = (1000.0, 2000.0)
DEFAULT_VALIDATION_BAND_HZ = (100.0, 5000.0)

# ============================================
# ENUMS
# ============================================

class CarrierType(Enum):
    RED_NIR_LIGHT = "red_nir_light"
    EM_FIELD = "em_field"
    ACOUSTIC = "acoustic"
    CHEMICAL = "chemical"


class PlantPart(Enum):
    FLOWER = "flower"
    STEM = "stem"
    ROOT = "root"
    LEAF = "leaf"
    MIXED = "mixed"


class ClaimLevel(Enum):
    LEVEL_1_PROTECTION = "dna_protection"
    LEVEL_2_REPAIR_ACCEL = "repair_acceleration"
    LEVEL_3_MUTATION_PREVENTION = "mutation_prevention"
    LEVEL_4_DNA_REBUILDING = "dna_rebuilding"


class SpectralMethod(Enum):
    FTIR = "ftir"
    RAMAN = "raman"
    UV_VIS = "uv_vis"
    NMR = "nmr"
    LC_MS = "lc_ms"
    DFT = "dft"


# ============================================
# SOURCE REFERENCES
# ============================================

@dataclass(frozen=True)
class SourceRef:
    key: str
    url: str
    note: str


SOURCE_REFS: Dict[str, SourceRef] = {
    "chlorogenic_frontiers_2025": SourceRef(
        key="chlorogenic_frontiers_2025",
        url="https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2025.1543663/full",
        note="Raman/FTIR monitoring of chlorogenic acid; includes 1603, 1632, 1160, and 1444 cm^-1 features."
    ),
    "chicoric_frontiers_2013": SourceRef(
        key="chicoric_frontiers_2013",
        url="https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2013.00040/full",
        note="Chicoric acid review; reports UV-visible maximum near 330 nm with 300 nm shoulder."
    ),
    "luteolin_acs_omega_2026": SourceRef(
        key="luteolin_acs_omega_2026",
        url="https://pmc.ncbi.nlm.nih.gov/articles/PMC12878360/",
        note="DFT/spectral analysis of luteolin; includes OH stretch, carbonyl, and aromatic skeletal vibrations."
    ),
    "luteolin_chemistry_2023": SourceRef(
        key="luteolin_chemistry_2023",
        url="https://www.mdpi.com/2227-9040/11/2/104",
        note="Raman/SERS study of luteolin; emphasizes characteristic 1660-1500 cm^-1 region."
    ),
}


# ============================================
# DATA CLASSES
# ============================================

@dataclass(frozen=True)
class SpectralPeak:
    molecule: str
    peak_value: float
    unit: str                      # "cm^-1" or "nm"
    assignment: str
    spectral_method: SpectralMethod
    source_key: str
    preferred_octaves: Optional[int] = None

    def molecular_frequency_thz(self) -> float:
        """Convert spectral peak to molecular/electromagnetic frequency in THz."""
        if self.unit == "cm^-1":
            return self.peak_value * CM1_TO_THZ
        if self.unit == "nm":
            return NM_TO_THZ_NUMERATOR / self.peak_value
        raise ValueError(f"Unsupported unit {self.unit!r}; expected 'cm^-1' or 'nm'.")

    def molecular_frequency_hz(self) -> float:
        return self.molecular_frequency_thz() * THZ_TO_HZ

    def infrared_wavelength_um(self) -> Optional[float]:
        """Return wavelength in micrometres for wavenumber peaks."""
        if self.unit == "cm^-1":
            return 10_000.0 / self.peak_value
        return None

    def select_octaves(
        self,
        target_band_hz: Tuple[float, float] = DEFAULT_TARGET_BAND_HZ,
        search_range: Tuple[int, int] = (20, 60),
    ) -> int:
        """
        Select an octave divisor that places the modulation frequency into the target band.
        If no integer octave lands inside the band, choose the nearest to the geometric center.
        """
        if self.preferred_octaves is not None:
            return self.preferred_octaves

        low, high = target_band_hz
        if low <= 0 or high <= low:
            raise ValueError("target_band_hz must be positive and ordered as (low, high).")

        center = math.sqrt(low * high)
        best_n = search_range[0]
        best_score = float("inf")

        for n in range(search_range[0], search_range[1] + 1):
            f_mod = self.molecular_frequency_hz() / (2 ** n)
            if low <= f_mod <= high:
                # Prefer frequencies closest to geometric center of target band.
                score = abs(math.log(f_mod / center))
            else:
                # Penalize out-of-band candidates.
                distance = min(abs(math.log(f_mod / low)), abs(math.log(f_mod / high)))
                score = 10.0 + distance
            if score < best_score:
                best_n = n
                best_score = score
        return best_n

    def modulation_frequency_hz(
        self,
        target_band_hz: Tuple[float, float] = DEFAULT_TARGET_BAND_HZ,
    ) -> float:
        n = self.select_octaves(target_band_hz)
        return self.molecular_frequency_hz() / (2 ** n)

    def conversion_record(
        self,
        target_band_hz: Tuple[float, float] = DEFAULT_TARGET_BAND_HZ,
    ) -> Dict[str, Any]:
        n = self.select_octaves(target_band_hz)
        f_mod = self.molecular_frequency_hz() / (2 ** n)
        return {
            "molecule": self.molecule,
            "peak_value": self.peak_value,
            "unit": self.unit,
            "assignment": self.assignment,
            "method": self.spectral_method.value,
            "source_key": self.source_key,
            "molecular_frequency_thz": round(self.molecular_frequency_thz(), 6),
            "selected_octaves": n,
            "downconversion": f"/2^{n}",
            "modulation_frequency_hz": round(f_mod, 4),
            "infrared_wavelength_um": None if self.infrared_wavelength_um() is None else round(self.infrared_wavelength_um(), 6),
        }


@dataclass(frozen=True)
class MoleculePacket:
    molecule_name: str
    plant_source: str
    plant_part: PlantPart
    spectral_peaks: List[SpectralPeak]

    def modulation_frequencies(
        self,
        target_band_hz: Tuple[float, float] = DEFAULT_TARGET_BAND_HZ,
    ) -> List[float]:
        return [p.modulation_frequency_hz(target_band_hz) for p in self.spectral_peaks]


@dataclass(frozen=True)
class HNCBioPacket:
    packet_id: str
    version: str
    plant: str
    plant_part: str
    molecules: List[str]
    carrier_type: CarrierType
    carrier_wavelength_nm: Optional[float]
    target_band_hz: Tuple[float, float]
    spectral_inputs: List[Dict[str, Any]]
    modulation_frequencies_hz: List[float]
    sideband_frequencies_hz: List[Dict[str, Any]]
    coherence_nodes_hz: List[Dict[str, Any]]
    biological_targets: List[str]
    claim_level: ClaimLevel
    exposure_duration_min: float = 60.0
    duty_cycle: float = INV_PHI
    phase_pattern: str = "golden_ratio"
    hnc_certificate: str = "HNC-VER-2025-0407-001"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "packet_id": self.packet_id,
            "version": self.version,
            "plant": self.plant,
            "plant_part": self.plant_part,
            "molecules": self.molecules,
            "carrier": {
                "type": self.carrier_type.value,
                "wavelength_nm": self.carrier_wavelength_nm,
                "mode": "amplitude_modulated",
            },
            "target_band_hz": list(self.target_band_hz),
            "spectral_inputs": self.spectral_inputs,
            "modulation_frequencies_hz": self.modulation_frequencies_hz,
            "sideband_frequencies_hz": self.sideband_frequencies_hz,
            "coherence_nodes_hz": self.coherence_nodes_hz,
            "biological_targets": self.biological_targets,
            "claim_level": self.claim_level.value,
            "exposure_duration_min": self.exposure_duration_min,
            "duty_cycle": self.duty_cycle,
            "phase_pattern": self.phase_pattern,
            "hnc_certificate": self.hnc_certificate,
            "scientific_boundary": (
                "Computational signal blueprint only; DNA rebuilding requires sequencing-confirmed "
                "restoration of a defined locus and clonal persistence."
            ),
            "source_references": {k: ref.__dict__ for k, ref in SOURCE_REFS.items()},
        }

    def to_json(self, filepath: str | Path) -> None:
        path = Path(filepath)
        path.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")

    def to_conversion_csv(self, filepath: str | Path) -> None:
        path = Path(filepath)
        fieldnames = [
            "molecule", "peak_value", "unit", "assignment", "method", "source_key",
            "molecular_frequency_thz", "selected_octaves", "downconversion",
            "modulation_frequency_hz", "infrared_wavelength_um",
        ]
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in self.spectral_inputs:
                writer.writerow({field: row.get(field) for field in fieldnames})

    def validate(self, validation_band_hz: Tuple[float, float] = DEFAULT_VALIDATION_BAND_HZ) -> List[str]:
        warnings: List[str] = []
        low, high = validation_band_hz
        if not (0.0 < self.duty_cycle <= 1.0):
            warnings.append("Duty cycle must be in the interval (0, 1].")
        if self.carrier_type == CarrierType.RED_NIR_LIGHT:
            if self.carrier_wavelength_nm is None:
                warnings.append("RED_NIR_LIGHT carrier requires carrier_wavelength_nm.")
            elif not (600.0 <= self.carrier_wavelength_nm <= 1100.0):
                warnings.append("RED_NIR_LIGHT carrier wavelength should be within 600-1100 nm for PBM-style testing.")
        out_of_range = [f for f in self.modulation_frequencies_hz if not (low <= f <= high)]
        if out_of_range:
            warnings.append(f"{len(out_of_range)} modulation frequencies outside validation band {validation_band_hz}: {out_of_range}")
        if self.claim_level == ClaimLevel.LEVEL_4_DNA_REBUILDING:
            required = {"targeted_deep_sequencing", "clonal_persistence"}
            if not required.issubset(set(self.biological_targets)):
                warnings.append("LEVEL_4_DNA_REBUILDING requires sequencing and clonal-persistence endpoints.")
        return warnings

    def signal_description(self) -> str:
        tones = ", ".join(f"{f:.1f}" for f in self.modulation_frequencies_hz[:8])
        if len(self.modulation_frequencies_hz) > 8:
            tones += ", ..."
        return (
            f"HNC BioPacket {self.version}: {self.packet_id}\n"
            f"Plant: {self.plant} ({self.plant_part})\n"
            f"Molecules: {', '.join(self.molecules)}\n"
            f"Carrier: {self.carrier_type.value} @ {self.carrier_wavelength_nm} nm\n"
            f"Target modulation band: {self.target_band_hz[0]:.0f}-{self.target_band_hz[1]:.0f} Hz\n"
            f"Tones: {len(self.modulation_frequencies_hz)} [{tones}]\n"
            f"Duty cycle: {self.duty_cycle:.6f}\n"
            f"Claim level: {self.claim_level.value}"
        )


# ============================================
# DANDELION MOLECULAR LIBRARY
# ============================================

DANDELION_MOLECULES: Dict[str, MoleculePacket] = {
    "chlorogenic_acid": MoleculePacket(
        molecule_name="chlorogenic acid",
        plant_source="Taraxacum officinale",
        plant_part=PlantPart.LEAF,
        spectral_peaks=[
            SpectralPeak("chlorogenic acid", 1603, "cm^-1", "C=C catechol / ethylene vibration", SpectralMethod.RAMAN, "chlorogenic_frontiers_2025"),
            SpectralPeak("chlorogenic acid", 1632, "cm^-1", "C=C vibration", SpectralMethod.RAMAN, "chlorogenic_frontiers_2025"),
            SpectralPeak("chlorogenic acid", 1160, "cm^-1", "ester C-O deformation", SpectralMethod.RAMAN, "chlorogenic_frontiers_2025"),
            SpectralPeak("chlorogenic acid", 1444, "cm^-1", "IR analytical peak", SpectralMethod.FTIR, "chlorogenic_frontiers_2025"),
        ],
    ),
    "luteolin": MoleculePacket(
        molecule_name="luteolin",
        plant_source="Taraxacum officinale",
        plant_part=PlantPart.LEAF,
        spectral_peaks=[
            SpectralPeak("luteolin", 1624, "cm^-1", "carbonyl stretch", SpectralMethod.FTIR, "luteolin_acs_omega_2026"),
            SpectralPeak("luteolin", 3615, "cm^-1", "hydrogen-bonded O-H stretch", SpectralMethod.FTIR, "luteolin_acs_omega_2026"),
            SpectralPeak("luteolin", 1607, "cm^-1", "aromatic skeletal vibration", SpectralMethod.FTIR, "luteolin_acs_omega_2026"),
            SpectralPeak("luteolin", 1594, "cm^-1", "aromatic skeletal vibration", SpectralMethod.FTIR, "luteolin_acs_omega_2026"),
            SpectralPeak("luteolin", 1582, "cm^-1", "aromatic skeletal vibration", SpectralMethod.FTIR, "luteolin_acs_omega_2026"),
            SpectralPeak("luteolin", 1567, "cm^-1", "aromatic skeletal vibration", SpectralMethod.FTIR, "luteolin_acs_omega_2026"),
        ],
    ),
    "chicoric_acid": MoleculePacket(
        molecule_name="chicoric acid",
        plant_source="Taraxacum officinale",
        plant_part=PlantPart.ROOT,
        spectral_peaks=[
            SpectralPeak("chicoric acid", 330, "nm", "UV-visible maximum", SpectralMethod.UV_VIS, "chicoric_frontiers_2013"),
            SpectralPeak("chicoric acid", 300, "nm", "UV-visible shoulder", SpectralMethod.UV_VIS, "chicoric_frontiers_2013"),
            # This carbonyl feature should be treated as a provisional/secondary seed unless confirmed against a standard.
            SpectralPeak("chicoric acid", 1650, "cm^-1", "provisional carbonyl-region vibration", SpectralMethod.FTIR, "chicoric_frontiers_2013"),
        ],
    ),
}


# ============================================
# FACTORY + UTILITIES
# ============================================

def molecule_key(name: str) -> str:
    return name.strip().lower().replace("-", "_").replace(" ", "_")


def sideband_record(
    center_hz: float,
    narrow_pct: float = 0.01,
    geometric_delta: float = PHI_INV_9,
) -> Dict[str, Any]:
    return {
        "center": round(center_hz, 4),
        "narrow_pct": narrow_pct,
        "narrow_low": round(center_hz * (1.0 - narrow_pct), 4),
        "narrow_high": round(center_hz * (1.0 + narrow_pct), 4),
        "geometric_delta": round(geometric_delta, 8),
        "geometric_low": round(center_hz * (1.0 - geometric_delta), 4),
        "geometric_high": round(center_hz * (1.0 + geometric_delta), 4),
    }


def cluster_coherence_nodes(
    records: Sequence[Dict[str, Any]],
    tolerance_hz: float = 25.0,
) -> List[Dict[str, Any]]:
    """Cluster close modulation frequencies into candidate coherence nodes."""
    if not records:
        return []

    sorted_records = sorted(records, key=lambda r: r["modulation_frequency_hz"])
    clusters: List[List[Dict[str, Any]]] = []
    current: List[Dict[str, Any]] = [sorted_records[0]]

    for rec in sorted_records[1:]:
        current_center = sum(r["modulation_frequency_hz"] for r in current) / len(current)
        if abs(rec["modulation_frequency_hz"] - current_center) <= tolerance_hz:
            current.append(rec)
        else:
            clusters.append(current)
            current = [rec]
    clusters.append(current)

    nodes: List[Dict[str, Any]] = []
    for idx, cluster in enumerate(clusters, start=1):
        freqs = [float(r["modulation_frequency_hz"]) for r in cluster]
        molecules = sorted({r["molecule"] for r in cluster})
        nodes.append({
            "node_id": f"CN-{idx:03d}",
            "center_hz": round(sum(freqs) / len(freqs), 4),
            "min_hz": round(min(freqs), 4),
            "max_hz": round(max(freqs), 4),
            "spread_hz": round(max(freqs) - min(freqs), 4),
            "n_peaks": len(cluster),
            "molecules": molecules,
        })
    return nodes


class HNCBioPacketFactory:
    @staticmethod
    def create_phenolic_coherence_packet(
        plant: str = "Taraxacum officinale",
        plant_part: str = "leaf/root mixed extract",
        molecules: Optional[List[str]] = None,
        carrier_type: CarrierType = CarrierType.RED_NIR_LIGHT,
        carrier_wavelength_nm: float = 660.0,
        target_band_hz: Tuple[float, float] = DEFAULT_TARGET_BAND_HZ,
        sideband_pct: float = 0.01,
        coherence_tolerance_hz: float = 25.0,
    ) -> HNCBioPacket:
        if molecules is None:
            molecules = ["chlorogenic acid", "chicoric acid", "luteolin"]

        conversion_records: List[Dict[str, Any]] = []
        molecule_labels: List[str] = []

        for name in molecules:
            key = molecule_key(name)
            if key not in DANDELION_MOLECULES:
                valid = ", ".join(sorted(DANDELION_MOLECULES))
                raise ValueError(f"Unknown molecule {name!r}. Valid keys: {valid}")
            packet = DANDELION_MOLECULES[key]
            molecule_labels.append(packet.molecule_name)
            conversion_records.extend(p.conversion_record(target_band_hz) for p in packet.spectral_peaks)

        freqs = sorted(round(float(r["modulation_frequency_hz"]), 4) for r in conversion_records)
        sidebands = [sideband_record(f, sideband_pct) for f in freqs]
        nodes = cluster_coherence_nodes(conversion_records, tolerance_hz=coherence_tolerance_hz)
        packet_id = HNCBioPacketFactory._packet_id(plant, molecule_labels, carrier_type.value, target_band_hz, freqs)

        return HNCBioPacket(
            packet_id=packet_id,
            version="v0.2",
            plant=plant,
            plant_part=plant_part,
            molecules=molecule_labels,
            carrier_type=carrier_type,
            carrier_wavelength_nm=carrier_wavelength_nm,
            target_band_hz=target_band_hz,
            spectral_inputs=conversion_records,
            modulation_frequencies_hz=freqs,
            sideband_frequencies_hz=sidebands,
            coherence_nodes_hz=nodes,
            biological_targets=[
                "ROS", "8-oxodG", "comet_tail_moment", "gamma-H2AX", "53BP1",
                "OGG1", "APE1", "XRCC1", "GADD45A", "NRF2", "HO-1", "NQO1",
            ],
            claim_level=ClaimLevel.LEVEL_1_PROTECTION,
            exposure_duration_min=60.0,
            duty_cycle=INV_PHI,
            phase_pattern="golden_ratio",
        )

    @staticmethod
    def _packet_id(
        plant: str,
        molecules: Sequence[str],
        carrier: str,
        target_band_hz: Tuple[float, float],
        freqs: Sequence[float],
    ) -> str:
        payload = json.dumps({
            "plant": plant,
            "molecules": list(molecules),
            "carrier": carrier,
            "target_band_hz": list(target_band_hz),
            "freqs": list(freqs),
        }, sort_keys=True)
        return f"HNC-{hashlib.sha256(payload.encode('utf-8')).hexdigest()[:10].upper()}"


class HNCControlPacketFactory:
    @staticmethod
    def random_frequency_control_like(packet: HNCBioPacket, seed: int = 407001) -> Dict[str, Any]:
        """Create a randomized control packet with the same tone count and frequency envelope."""
        rng = random.Random(seed)
        low = min(packet.modulation_frequencies_hz)
        high = max(packet.modulation_frequencies_hz)
        freqs = sorted(round(rng.uniform(low, high), 4) for _ in packet.modulation_frequencies_hz)
        payload = {
            "control_id": f"CTRL-RAND-{seed}",
            "matched_to_packet_id": packet.packet_id,
            "seed": seed,
            "purpose": "random-frequency control with same tone count and envelope",
            "carrier": packet.to_dict()["carrier"],
            "modulation_frequencies_hz": freqs,
            "duty_cycle": packet.duty_cycle,
            "phase_pattern": "randomized",
        }
        return payload

    @staticmethod
    def scrambled_phase_control_like(packet: HNCBioPacket, seed: int = 407002) -> Dict[str, Any]:
        """Keep HNC frequencies but randomize phases for a phase-specific control."""
        rng = random.Random(seed)
        phases = {f"{f:.4f}": round(rng.uniform(0.0, 2.0 * math.pi), 6) for f in packet.modulation_frequencies_hz}
        return {
            "control_id": f"CTRL-PHASE-{seed}",
            "matched_to_packet_id": packet.packet_id,
            "seed": seed,
            "purpose": "scrambled-phase control with same HNC tone set",
            "carrier": packet.to_dict()["carrier"],
            "modulation_frequencies_hz": packet.modulation_frequencies_hz,
            "phase_radians_by_frequency": phases,
            "duty_cycle": packet.duty_cycle,
            "phase_pattern": "scrambled",
        }


def write_json(filepath: str | Path, payload: Dict[str, Any]) -> None:
    Path(filepath).write_text(json.dumps(payload, indent=2), encoding="utf-8")


def print_conversion_table(packet: HNCBioPacket) -> None:
    print("HNC BioPacket Conversion Table v0.2")
    print("=" * 118)
    print(f"{'Molecule':<20} {'Peak':>8} {'Unit':<7} {'THz':>10} {'Oct':>5} {'Hz':>10}  Assignment")
    print("-" * 118)
    for row in packet.spectral_inputs:
        print(
            f"{row['molecule']:<20} "
            f"{row['peak_value']:>8} "
            f"{row['unit']:<7} "
            f"{row['molecular_frequency_thz']:>10.3f} "
            f"{row['selected_octaves']:>5} "
            f"{row['modulation_frequency_hz']:>10.1f}  "
            f"{row['assignment']}"
        )
    print()


def print_experimental_arms() -> None:
    arms = [
        ("A", "No stressor, no molecule, no signal", "baseline"),
        ("B", "Stressor only", "damage control"),
        ("C", "Stressor + dandelion extract", "chemical biomolecule effect"),
        ("D", "Stressor + red/NIR carrier only", "carrier effect"),
        ("E", "Stressor + random packet", "random-frequency control"),
        ("F", "Stressor + HNC packet only", "signal-only HNC effect"),
        ("G", "Stressor + dandelion extract + random packet", "molecule + nonspecific signal"),
        ("H", "Stressor + dandelion extract + HNC packet", "full hypothesis"),
        ("I", "Stressor + purified chlorogenic/chicoric/luteolin + HNC packet", "molecule-specific validation"),
        ("J", "Stressor + known positive repair/protection control", "assay validation"),
    ]
    print("10-arm experimental matrix")
    print("=" * 80)
    for arm, description, purpose in arms:
        print(f"{arm}: {description:<62} [{purpose}]")
    print("\nDecisive comparison: H must outperform C, D, E, and G.\n")


if __name__ == "__main__":
    out_dir = Path(".")
    packet = HNCBioPacketFactory.create_phenolic_coherence_packet()
    random_ctrl = HNCControlPacketFactory.random_frequency_control_like(packet)
    phase_ctrl = HNCControlPacketFactory.scrambled_phase_control_like(packet)

    print(packet.signal_description())
    print()
    print_conversion_table(packet)
    print_experimental_arms()

    warnings = packet.validate()
    if warnings:
        print("Validation warnings:")
        for warning in warnings:
            print(f"- {warning}")
    else:
        print("Validation: no structural warnings.")

    packet.to_json(out_dir / "hnc_biopacket_phenolic_coherence_v02.json")
    packet.to_conversion_csv(out_dir / "hnc_conversion_table_v02.csv")
    write_json(out_dir / "hnc_random_frequency_control_v02.json", random_ctrl)
    write_json(out_dir / "hnc_scrambled_phase_control_v02.json", phase_ctrl)

    print("\nExported:")
    print("- hnc_biopacket_phenolic_coherence_v02.json")
    print("- hnc_conversion_table_v02.csv")
    print("- hnc_random_frequency_control_v02.json")
    print("- hnc_scrambled_phase_control_v02.json")
