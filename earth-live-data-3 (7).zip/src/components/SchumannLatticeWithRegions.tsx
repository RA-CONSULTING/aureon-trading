import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { User, Calendar, Play, Pause, RotateCcw, Zap } from 'lucide-react';
import { aurisEngine } from '@/lib/auris-harmonic-engine';

interface EmotionalState {
  name: string;
  freq: number;
  color: string;
  band: string;
  symbol: string;
  branches: string[];
  range: string;
}

interface ObserverData {
  fullName: string;
  dateOfBirth: string;
  personalFrequency: number;
  biorhythm: {
    emotional: number;
    physical: number;
    intellectual: number;
  };
}

const SchumannLatticeWithRegions: React.FC = () => {
  const [currentEmotion, setCurrentEmotion] = useState<any>(null);
  const [detectedFreq, setDetectedFreq] = useState<number>(7.83);
  const [isActive, setIsActive] = useState(false);
  const [resonanceStrength, setResonanceStrength] = useState(0);
  const [coherenceScore, setCoherenceScore] = useState(0);
  const [sentinelIdentity, setSentinelIdentity] = useState<any>(null);
  const [availableEmotions, setAvailableEmotions] = useState<string[]>([]);
  const [emotionFrequencies, setEmotionFrequencies] = useState<Record<string, any>>({});
  const [userProfile, setUserProfile] = useState({
    fullName: '',
    dateOfBirth: '',
    isPhased: false,
    personalFreq: 0,
    biorhythm: 0
  });
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number | null>(null);

  // Initialize Auris Engine
  useEffect(() => {
    const initEngine = async () => {
      await aurisEngine.initialize();
      const identity = aurisEngine.getIdentity();
      setSentinelIdentity(identity);
      
      const emotions = aurisEngine.getAvailableEmotions();
      setAvailableEmotions(emotions);
      
      // Pre-calculate all emotion frequencies
      const frequencies: Record<string, any> = {};
      emotions.forEach(emotion => {
        frequencies[emotion] = aurisEngine.calculateEmotionFrequency(emotion);
      });
      setEmotionFrequencies(frequencies);
    };
    
    initEngine();
  }, []);
  useEffect(() => {
    const loadEmotionalData = async () => {
      try {
        const [baseResponse, completeResponse] = await Promise.all([
          fetch('/emotional_frequency_codex.json'),
          fetch('/emotional_frequency_codex_complete.json')
        ]);
        
        const baseData = await baseResponse.json();
        const completeData = await completeResponse.json();
        
        // Merge emotions from both files
        const allEmotions = [
          ...baseData.emotions,
          ...completeData.emotions_continued
        ];
        
        // Convert to band structure for compatibility
        const bandStructure: Record<string, EmotionalBand> = {};
        
        allEmotions.forEach(emotion => {
          const level = emotion.level;
          if (!bandStructure[level]) {
            bandStructure[level] = {
              name: level.charAt(0).toUpperCase() + level.slice(1) + ' Band',
              range: `${emotion.frequency}-${emotion.frequency + 50} Hz`,
              symbol: emotion.symbol,
              color_base: emotion.color_name,
              emotions: []
            };
          }
          
          bandStructure[level].emotions.push({
            name: emotion.name,
            freq: emotion.frequency,
            range: emotion.frequency.toString(),
            branches: [emotion.description],
            color: emotion.color,
            band: level,
            symbol: emotion.symbol
          });
        });
        
        setEmotionalBands(bandStructure);
      } catch (error) {
        console.error('Failed to load emotional frequency codex:', error);
      }
    };
    
    loadEmotionalData();
  }, []);

  // Calculate personal frequency from user data
  const calculatePersonalFrequency = (name: string, dob: string) => {
    if (!name || !dob) return 0;
    
    // Convert name to numerical value using character codes
    const nameValue = name.toLowerCase().split('').reduce((sum, char) => sum + char.charCodeAt(0), 0);
    
    // Calculate days since birth for biorhythm
    const birthDate = new Date(dob);
    const today = new Date();
    const daysSinceBirth = Math.floor((today.getTime() - birthDate.getTime()) / (1000 * 60 * 60 * 24));
    
    // Personal base frequency (20-1000 Hz range)
    const personalBase = 100 + (nameValue % 800); // Base frequency from name
    
    // Biorhythm cycles (emotional: 28 days, physical: 23 days, intellectual: 33 days)
    const emotionalCycle = Math.sin((daysSinceBirth % 28) * 2 * Math.PI / 28);
    const physicalCycle = Math.sin((daysSinceBirth % 23) * 2 * Math.PI / 23);
    const intellectualCycle = Math.sin((daysSinceBirth % 33) * 2 * Math.PI / 33);
    
    const biorhythmInfluence = (emotionalCycle + physicalCycle + intellectualCycle) / 3;
    
    return {
      personalFreq: personalBase,
      biorhythm: biorhythmInfluence,
      daysSinceBirth
    };
  };

  // Phase the system to the user
  const phaseToUser = () => {
    if (!userProfile.fullName || !userProfile.dateOfBirth) return;
    
    const { personalFreq, biorhythm, daysSinceBirth } = calculatePersonalFrequency(
      userProfile.fullName, 
      userProfile.dateOfBirth
    );
    
    setUserProfile(prev => ({
      ...prev,
      isPhased: true,
      personalFreq,
      biorhythm
    }));
  };

  // Enhanced real-time emotional detection using Auris Engine
  useEffect(() => {
    if (!isActive || availableEmotions.length === 0) return;
    
    const detectEmotion = () => {
      // Simulate emotional state detection
      const randomEmotion = availableEmotions[Math.floor(Math.random() * availableEmotions.length)];
      const emotionData = emotionFrequencies[randomEmotion];
      
      if (emotionData) {
        setDetectedFreq(emotionData.frequency);
        setCurrentEmotion({
          name: randomEmotion,
          freq: emotionData.frequency,
          color: emotionData.color,
          components: emotionData.components,
          symbol: randomEmotion.charAt(0).toUpperCase(),
          band: 'auris',
          branches: [`Harmonic recipe with ${emotionData.components.length} components`],
          range: `${emotionData.frequency.toFixed(1)} Hz`
        });
        
        // Calculate 10-9-1 coherence score
        const frequencies = emotionData.components.map((c: any) => c.frequency);
        const coherence = aurisEngine.calculate10_9_1_Coherence(frequencies);
        setCoherenceScore(coherence);
        setResonanceStrength(85 + Math.random() * 15); // High resonance for Auris system
      }
    };
    
    const interval = setInterval(detectEmotion, userProfile.isPhased ? 2000 : 3000);
    return () => clearInterval(interval);
  }, [isActive, availableEmotions, emotionFrequencies, userProfile.isPhased]);

  // Enhanced lattice visualization with emotional spectrum
  useEffect(() => {
    if (!isActive) return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    let time = 0;
    
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      
      // Draw emotional spectrum tree structure
      if (currentEmotion) {
        // Draw emotional aura field
        const gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, 150);
        gradient.addColorStop(0, `${currentEmotion.color}40`);
        gradient.addColorStop(1, `${currentEmotion.color}10`);
        
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Draw pulsing center with emotional color
        const pulseRadius = 20 + Math.sin(time * 0.05) * 10;
        ctx.beginPath();
        ctx.arc(centerX, centerY, pulseRadius, 0, Math.PI * 2);
        ctx.fillStyle = currentEmotion.color;
        ctx.fill();
        
        // Draw emotional symbol at center
        ctx.font = '24px Arial';
        ctx.fillStyle = 'white';
        ctx.textAlign = 'center';
        ctx.fillText(currentEmotion.symbol, centerX, centerY + 8);
      }
      
      // Draw lattice nodes with emotional influence
      const nodes = 12;
      for (let i = 0; i < nodes; i++) {
        const angle = (i / nodes) * Math.PI * 2;
        const radius = 100 + Math.sin(time * 0.03 + i) * 20;
        const x = centerX + Math.cos(angle) * radius;
        const y = centerY + Math.sin(angle) * radius;
        
        // Node influenced by emotional state
        const nodeSize = currentEmotion ? 8 + resonanceStrength * 0.1 : 6;
        const nodeColor = currentEmotion ? currentEmotion.color : '#4A90E2';
        
        ctx.beginPath();
        ctx.arc(x, y, nodeSize, 0, Math.PI * 2);
        ctx.fillStyle = nodeColor;
        ctx.fill();
        
        // Draw connections with emotional resonance
        if (currentEmotion) {
          ctx.beginPath();
          ctx.moveTo(centerX, centerY);
          ctx.lineTo(x, y);
          ctx.strokeStyle = `${currentEmotion.color}60`;
          ctx.lineWidth = 2;
          ctx.stroke();
        }
      }
      
      time += 1;
      animationRef.current = requestAnimationFrame(animate);
    };
    
    animate();
    
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isActive, currentEmotion, resonanceStrength]);

  const toggleLattice = () => {
    setIsActive(!isActive);
    if (!isActive) {
      setCurrentEmotion(null);
      setDetectedFreq(0);
      setResonanceStrength(0);
    }
  };

  const resetLattice = () => {
    setIsActive(false);
    setCurrentEmotion(null);
    setDetectedFreq(0);
    setResonanceStrength(0);
  };

  return (
    <div className="space-y-4">
      {/* Prime Sentinel Identity Display */}
      {sentinelIdentity && (
        <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-2 border-purple-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-purple-600" />
              Prime Sentinel Identity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <div className="font-semibold text-purple-800">{sentinelIdentity.name}</div>
                <div className="text-gray-600">Born: {sentinelIdentity.dob_iso}</div>
                <div className="text-xs text-purple-600 mt-1">{sentinelIdentity.oath}</div>
              </div>
              <div className="space-y-1">
                <div>Prime Ratio: {sentinelIdentity.prime_ratio_10_9_1.join(':')}</div>
                <div>T0 Frequency: {sentinelIdentity.t0_hz} Hz</div>
                <div>φ (Phi): {sentinelIdentity.phi.toFixed(6)}</div>
                <div className="text-xs text-gray-500 mt-2">
                  10-9-1 Coherence Score: {coherenceScore.toFixed(1)}%
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* User Profile Input */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="w-5 h-5" />
            Observer Phasing System
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name</Label>
              <Input
                id="fullName"
                placeholder="Enter your full name"
                value={userProfile.fullName}
                onChange={(e) => setUserProfile(prev => ({ ...prev, fullName: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dateOfBirth">Date of Birth</Label>
              <Input
                id="dateOfBirth"
                type="date"
                value={userProfile.dateOfBirth}
                onChange={(e) => setUserProfile(prev => ({ ...prev, dateOfBirth: e.target.value }))}
              />
            </div>
            <Button 
              onClick={phaseToUser}
              disabled={!userProfile.fullName || !userProfile.dateOfBirth}
              className="w-full"
            >
              <Calendar className="w-4 h-4 mr-2" />
              Phase to Observer
            </Button>
          </div>
          
          {userProfile.isPhased && (
            <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm font-medium text-green-800">System Phased to Observer</span>
              </div>
              <div className="text-xs text-green-700 space-y-1">
                <div>Personal Frequency: {userProfile.personalFreq.toFixed(1)} Hz</div>
                <div>Biorhythm Influence: {(userProfile.biorhythm * 100).toFixed(1)}%</div>
                <div>Reading Accuracy: Enhanced (+20%)</div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>🌈 Auris Harmonic Emotional Lattice</span>
            <div className="flex gap-2">
              <Button onClick={toggleLattice} variant={isActive ? "destructive" : "default"}>
                {isActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                {isActive ? 'Deactivate' : 'Activate'}
              </Button>
              <Button onClick={resetLattice} variant="outline">
                <RotateCcw className="w-4 h-4" />
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Lattice Visualization */}
            <div className="relative">
              <canvas
                ref={canvasRef}
                width={400}
                height={400}
                className="border rounded-lg bg-black"
              />
               {isActive && (
                 <div className="absolute top-2 left-2 bg-black/70 text-white p-2 rounded text-xs">
                   Status: {userProfile.isPhased ? 'Phased & Active' : 'Active'} • Freq: {detectedFreq.toFixed(1)} Hz
                   {userProfile.isPhased && (
                     <div className="mt-1 text-green-300">
                       Observer: {userProfile.fullName.split(' ')[0]} • Biorhythm: {(userProfile.biorhythm * 100).toFixed(0)}%
                     </div>
                   )}
                 </div>
               )}
            </div>
            
            {/* Emotional State Display */}
            <div className="space-y-4">
              {currentEmotion ? (
                <div className="p-4 rounded-lg border" style={{ backgroundColor: `${currentEmotion.color}20` }}>
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-2xl">{currentEmotion.symbol}</span>
                    <div>
                      <h3 className="font-bold text-lg capitalize">{currentEmotion.name}</h3>
                      <Badge variant="outline">AURIS HARMONIC</Badge>
                    </div>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <div>
                      <strong>Frequency:</strong> {currentEmotion.freq} Hz
                    </div>
                    <div>
                      <strong>Resonance:</strong> {resonanceStrength.toFixed(1)}%
                    </div>
                    <div>
                      <strong>10-9-1 Coherence:</strong> {coherenceScore.toFixed(1)}%
                    </div>
                    <div>
                      <strong>Components:</strong> {currentEmotion.components?.length || 0} harmonic intervals
                    </div>
                  </div>

                  {/* Show harmonic components */}
                  {currentEmotion.components && (
                    <div className="mt-3 text-xs">
                      <div className="font-medium mb-1">Harmonic Recipe:</div>
                      <div className="space-y-1">
                        {currentEmotion.components.slice(0, 3).map((comp: any, idx: number) => (
                          <div key={idx} className="flex justify-between">
                            <span>{comp.interval} ({comp.ratio.toFixed(3)})</span>
                            <span>{comp.frequency.toFixed(1)} Hz</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-4 rounded-lg border bg-gray-50 text-center">
                  <p className="text-gray-600">
                    {isActive ? 'Scanning Auris emotional field...' : 'Activate lattice to begin Auris harmonic detection'}
                  </p>
                </div>
              )}
              
              {/* Available Emotions Display */}
              {availableEmotions.length > 0 && (
                <div className="text-xs space-y-1 p-3 bg-blue-50 rounded">
                  <div className="font-semibold">🎵 Available Auris Emotions:</div>
                  <div className="grid grid-cols-2 gap-1">
                    {availableEmotions.map(emotion => (
                      <div key={emotion} className="capitalize">
                        {emotion}: {emotionFrequencies[emotion]?.frequency.toFixed(1)} Hz
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SchumannLatticeWithRegions;