import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface NexusState {
  phaseLock: boolean;
  harmonicField: number;
  quantumCoherence: number;
  temporalGate: boolean;
  fieldIntensity: number;
  dimensionalFlux: number;
  streamingData: {
    timestamp: string;
    phaseAngle: number;
    resonanceLevel: number;
    harmonicNodes: number;
    temporalSync: number;
  };
}

export function HarmonicNexusCore() {
  const [nexusState, setNexusState] = useState<NexusState>({
    phaseLock: true,
    harmonicField: 7.83,
    quantumCoherence: 0.85,
    temporalGate: true,
    fieldIntensity: 0.8,
    dimensionalFlux: 0.92,
    streamingData: {
      timestamp: new Date().toISOString(),
      phaseAngle: 0,
      resonanceLevel: 0.75,
      harmonicNodes: 8,
      temporalSync: 0.95
    }
  });
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();

  // Live data streaming simulation
  useEffect(() => {
    const updateLiveData = () => {
      setNexusState(prev => ({
        ...prev,
        harmonicField: 7.83 + Math.sin(Date.now() * 0.001) * 0.5,
        quantumCoherence: 0.75 + Math.sin(Date.now() * 0.0008) * 0.2,
        fieldIntensity: 0.6 + Math.sin(Date.now() * 0.0012) * 0.3,
        dimensionalFlux: 0.8 + Math.sin(Date.now() * 0.0015) * 0.15,
        streamingData: {
          timestamp: new Date().toISOString(),
          phaseAngle: (Date.now() * 0.01) % 360,
          resonanceLevel: 0.7 + Math.sin(Date.now() * 0.002) * 0.25,
          harmonicNodes: 8 + Math.floor(Math.sin(Date.now() * 0.0005) * 4),
          temporalSync: 0.9 + Math.sin(Date.now() * 0.0018) * 0.08
        }
      }));
    };

    const interval = setInterval(updateLiveData, 100);
    return () => clearInterval(interval);
  }, []);

  // Continuous animation
  useEffect(() => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frame = 0;
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      const time = Date.now() * 0.001;
      
      // 4D Projection Core
      for (let layer = 0; layer < 6; layer++) {
        const radius = 30 + layer * 25;
        const phaseOffset = layer * Math.PI / 3;
        
        // Multiphase geometric pattern
        for (let i = 0; i < 12; i++) {
          const angle = (i * Math.PI / 6) + (time * 0.5) + phaseOffset;
          const x = centerX + Math.cos(angle) * radius * nexusState.fieldIntensity;
          const y = centerY + Math.sin(angle) * radius * nexusState.fieldIntensity;
          
          // 4th dimension projection (color intensity)
          const fourthDim = Math.sin(time * 2 + layer + i) * 0.5 + 0.5;
          const hue = (180 + layer * 40 + fourthDim * 60) % 360;
          
          ctx.beginPath();
          ctx.arc(x, y, 3 + fourthDim * 5, 0, 2 * Math.PI);
          ctx.fillStyle = `hsla(${hue}, 80%, 60%, ${0.6 + fourthDim * 0.4})`;
          ctx.fill();
          
          // Connect nodes with harmonic lines
          if (i > 0) {
            const prevAngle = ((i-1) * Math.PI / 6) + (time * 0.5) + phaseOffset;
            const prevX = centerX + Math.cos(prevAngle) * radius * nexusState.fieldIntensity;
            const prevY = centerY + Math.sin(prevAngle) * radius * nexusState.fieldIntensity;
            
            ctx.beginPath();
            ctx.moveTo(prevX, prevY);
            ctx.lineTo(x, y);
            ctx.strokeStyle = `hsla(${hue}, 60%, 50%, 0.3)`;
            ctx.lineWidth = 1;
            ctx.stroke();
          }
        }
      }
      
      // Central nexus core
      const coreRadius = 15 + Math.sin(time * 3) * 5;
      const gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, coreRadius);
      gradient.addColorStop(0, `hsla(60, 100%, 80%, ${nexusState.quantumCoherence})`);
      gradient.addColorStop(1, `hsla(240, 80%, 60%, 0.2)`);
      
      ctx.beginPath();
      ctx.arc(centerX, centerY, coreRadius, 0, 2 * Math.PI);
      ctx.fillStyle = gradient;
      ctx.fill();
      
      frame++;
      animationRef.current = requestAnimationFrame(animate);
    };
    
    animate();
    
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [nexusState]);

  return (
    <div className="w-full space-y-6">
      <Card className="bg-gradient-to-br from-slate-900 to-purple-900 border-purple-500/30">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl font-bold text-white">
              🌌 Harmonic Nexus Core - LIVE STREAMING
            </CardTitle>
            <Badge variant="default" className="bg-green-600 animate-pulse">
              NEXUS ACTIVE
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-black/30 p-3 rounded-lg">
                  <div className="text-xs text-gray-300">Phase Lock</div>
                  <Badge variant="default" className="bg-cyan-600">
                    LOCKED
                  </Badge>
                </div>
                <div className="bg-black/30 p-3 rounded-lg">
                  <div className="text-xs text-gray-300">Temporal Gate</div>
                  <Badge variant="default" className="bg-green-600">
                    OPEN
                  </Badge>
                </div>
                <div className="bg-black/30 p-3 rounded-lg">
                  <div className="text-xs text-gray-300">Harmonic Freq</div>
                  <div className="text-lg font-mono text-cyan-400">
                    {nexusState.harmonicField.toFixed(2)} Hz
                  </div>
                </div>
                <div className="bg-black/30 p-3 rounded-lg">
                  <div className="text-xs text-gray-300">Coherence</div>
                  <div className="text-lg font-mono text-green-400">
                    {(nexusState.quantumCoherence * 100).toFixed(1)}%
                  </div>
                </div>
              </div>
              
              <div className="bg-black/30 p-3 rounded-lg">
                <div className="text-xs text-gray-300 mb-2">Live Stream Data</div>
                <div className="space-y-1 text-xs font-mono">
                  <div className="text-blue-300">Phase: {nexusState.streamingData.phaseAngle.toFixed(1)}°</div>
                  <div className="text-purple-300">Resonance: {(nexusState.streamingData.resonanceLevel * 100).toFixed(1)}%</div>
                  <div className="text-orange-300">Nodes: {nexusState.streamingData.harmonicNodes}</div>
                  <div className="text-green-300">Sync: {(nexusState.streamingData.temporalSync * 100).toFixed(1)}%</div>
                  <div className="text-yellow-300">Flux: {(nexusState.dimensionalFlux * 100).toFixed(1)}%</div>
                </div>
              </div>
            </div>
            
            <div className="flex items-center justify-center">
              <canvas 
                ref={canvasRef}
                width={350}
                height={350}
                className="border border-cyan-500 rounded-lg shadow-lg shadow-cyan-500/20 bg-black/20"
              />
            </div>
          </div>
          
          <div className="mt-4 text-xs text-gray-400 text-center">
            Last Update: {new Date(nexusState.streamingData.timestamp).toLocaleTimeString()}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}