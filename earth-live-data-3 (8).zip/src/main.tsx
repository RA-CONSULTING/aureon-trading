import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'
import { startNewsWorker } from './workers/newsWorker'
import { startHNC } from './workers/hncWorker'

// Start news worker for 24/7 emotion monitoring
startNewsWorker();

// Start HNC coherence engine
startHNC();

// Remove dark mode class addition
createRoot(document.getElementById("root")!).render(<App />);
