import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import SourceReadingPage from './SourceReadingPage';
import EnhancedAngelOracleReader from './EnhancedAngelOracleReader';
import EarthLiveMainPanel from './EarthLiveMainPanel';
import NexusLiveDashboardMain from './NexusLiveDashboardMain';
import UnifiedSystemDashboard from './UnifiedSystemDashboard';
import NewsEmotionDashboard from './NewsEmotionDashboard';
import SchumannLatticeComplete from './SchumannLatticeComplete';
import HarmonicNexusAnalytics from './HarmonicNexusAnalytics';
import SchumannAnalytics from './SchumannAnalytics';
import EarthLiveAnalytics from './EarthLiveAnalytics';
import AuraReader from './AuraReader';
import { TarotReader } from './TarotReader';
import LiveValidationDashboard from './LiveValidationDashboard';
import PAWTelemetryDisplay from './PAWTelemetryDisplay';
import AurisAnalytics from './AurisAnalytics';
import QuantumAnalytics from './QuantumAnalytics';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
function AppLayout() {
  const [activeTab, setActiveTab] = useState('source');
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="container mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">
            🌌 Unified System Analytics Dashboard
          </h1>
          <p className="text-gray-300">
            Real-time monitoring and analysis of all connected systems, patches, and data streams
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-12 bg-slate-800/50">
            <TabsTrigger value="source" className="text-xs">
              🔥 Source Reading
            </TabsTrigger>

            <TabsTrigger value="aura" className="text-xs">
              🔮 Aura Reader
            </TabsTrigger>
            <TabsTrigger value="systems" className="text-xs">
              🔧 Systems
            </TabsTrigger>
            <TabsTrigger value="harmonic" className="text-xs">
              🌌 Harmonic
            </TabsTrigger>
            <TabsTrigger value="auris" className="text-xs">
              🔮 Auris
            </TabsTrigger>
            <TabsTrigger value="quantum" className="text-xs">
              ⚛️ Quantum
            </TabsTrigger>
            <TabsTrigger value="schumann" className="text-xs">
              📡 Schumann
            </TabsTrigger>
            <TabsTrigger value="earth" className="text-xs">
              🌍 Earth Live
            </TabsTrigger>
            <TabsTrigger value="paw" className="text-xs">
              ⚡ PAW
            </TabsTrigger>
            <TabsTrigger value="validation" className="text-xs">
              ✅ Validation
            </TabsTrigger>
            <TabsTrigger value="tarot" className="text-xs">
              🃏 Tarot
            </TabsTrigger>
            <TabsTrigger value="angel" className="text-xs">
              👼 Angel Oracle
            </TabsTrigger>
          </TabsList>
          <TabsContent value="source" className="space-y-6">
            <SourceReadingPage />
          </TabsContent>

          <TabsContent value="aura" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  🔮 Multiverseal Aura Reader
                  <Badge variant="outline" className="bg-purple-500/20 text-purple-400">
                    All Systems Linked
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <AuraReader />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="systems" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  🔧 All Systems Overview
                  <Badge variant="outline" className="bg-green-500/20 text-green-400">
                    8 Systems Active
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <UnifiedSystemDashboard />
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="harmonic" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  🌌 Harmonic Nexus Core Analytics
                  <Badge variant="outline" className="bg-blue-500/20 text-blue-400">
                    Real-time
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <HarmonicNexusAnalytics />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="auris" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  🔮 Auris Symbolic Compiler Analytics
                  <Badge variant="outline" className="bg-purple-500/20 text-purple-400">
                    Processing
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <AurisAnalytics />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="quantum" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  ⚛️ Quantum Field Matrix Analytics
                  <Badge variant="outline" className="bg-cyan-500/20 text-cyan-400">
                    Entangled
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <QuantumAnalytics />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="schumann" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  📡 Schumann Resonance Analytics
                  <Badge variant="outline" className="bg-green-500/20 text-green-400">
                    Resonating
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <SchumannAnalytics />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="earth" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  🌍 Earth Live Data Analytics
                  <Badge variant="outline" className="bg-emerald-500/20 text-emerald-400">
                    Streaming
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <EarthLiveAnalytics />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="paw" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  ⚡ PAW Telemetry System
                  <Badge variant="outline" className="bg-yellow-500/20 text-yellow-400">
                    Monitoring
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <PAWTelemetryDisplay />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="validation" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  ✅ Validation & Verification Systems
                  <Badge variant="outline" className="bg-red-500/20 text-red-400">
                    Validating
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="bg-slate-700/50">
                    <CardHeader>
                      <CardTitle className="text-white text-lg">System Integrity</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-gray-300">Core Systems</span>
                          <Badge variant="outline" className="bg-green-500/20 text-green-400">
                            ✓ Validated
                          </Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-gray-300">Data Streams</span>
                          <Badge variant="outline" className="bg-green-500/20 text-green-400">
                            ✓ Active
                          </Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-gray-300">Connections</span>
                          <Badge variant="outline" className="bg-green-500/20 text-green-400">
                            ✓ Stable
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-slate-700/50">
                    <CardHeader>
                      <CardTitle className="text-white text-lg">Performance Metrics</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-gray-300">Response Time</span>
                          <span className="text-green-400 font-bold">12ms</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-gray-300">Throughput</span>
                          <span className="text-blue-400 font-bold">2.4 GB/s</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-gray-300">Error Rate</span>
                          <span className="text-yellow-400 font-bold">0.003%</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tarot" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  🃏 Tarot Engine - Deterministic Readings
                  <Badge variant="outline" className="bg-purple-500/20 text-purple-400">
                    Four Pillars
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <TarotReader />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="angel" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  👼 Angel Answers Oracle Cards
                  <Badge variant="outline" className="bg-pink-500/20 text-pink-400">
                    Divine Guidance
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <EnhancedAngelOracleReader />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AppLayout;